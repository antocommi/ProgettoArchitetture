echo " "
echo "----------------------------------------------------------------"
echo " "
ris=$(nasm  -s -f elf32 sort32gr2.nasm) 
if [ "${ris}" = "" ]; 
   then
      echo "------------------------------------------------"
      echo " "
      echo "Parametri :"
      echo "	-n <size> : numeri floating-point da ordinare 		    (default=100000)"
      echo "	-t <type> : i=inverted, r=random, n=nearly-sorted, s=sorted (default=n)"
      echo " "
      echo "------------------------------------------------"
      echo " "
      echo "--- Compilazione ---"
      echo " " 
      echo ${ris}
      gcc -O3 -m32 -msse sort32gr2.o test32.c -o test32gr2
      echo " "
      echo "--- Lancio ---"
      if [ $1 -ge 1024 ];
         then
            echo " " 
            ./test32gr2 -s -n $1 -t r > output.txt
	    echo " "
         else
            echo " " 
            ./test32gr2 -d -n $1 -t r > output.txt
	    echo " "
      fi
      echo "--- Output ---"
      cat output.txt
   elif [ -e test32gr2 ];
      then
	 echo "--- Compilazione ---"
         echo " " 
         rm test32gr2
         echo ${ris}
         echo " "
      else
	 echo "--- Compilazione ---"
         echo " " 
         echo ${ris}
         echo " "
fi
