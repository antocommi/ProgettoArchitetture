echo " "
echo "----------------------------------------------------------------"
echo " "
ris=$(nasm -s -f elf64 sort64gr2.nasm) 
if [ "${ris}" = "" ]; 
   then
      echo "------------------------------------------------"
      echo " "
      echo "Parametri :"
      echo "	-n <size> : numeri floating-point da ordinare 		    (default=100000)"
      echo "	-t <type> : i=inverted, r=random, n=nearly-sorted, s=sorted (default=n)"
      echo " "
      echo "------------------------------------------------"
      echo " "
      echo "--- Compilazione ---"
      echo " " 
      echo ${ris}
      gcc -O3 -m64 -mavx sort64gr2.o test64.c -o test64gr2
      echo " "
      echo "--- Lancio ---"
      if [ $1 -ge 1024 ];
         then
            echo " " 
            ./test64gr2 -s -n $1 -t r > output.txt
            echo " "
         else
            echo " " 
            ./test64gr2 -d -n $1 -t r > output.txt
            echo " "
      fi
      echo "--- Output ---"
      cat output.txt
   elif [ -e test64 ];
      then
	 echo "--- Compilazione ---"
         echo " " 
         rm test64gr2
         echo ${ris}
         echo " "
      else
	 echo "--- Compilazione ---"
         echo " " 
         echo ${ris}
         echo " "
fi