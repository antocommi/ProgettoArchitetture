/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2012/13
 * 
 * "Progetto di un algoritmo di ordinamento SIMD per numeri in virgola mobile
 * a precisione singola utilizzando il linguaggio assembly x86-64 + AVX"
 * 
 * Fabrizio Angiulli, 5 maggio 2013
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 sort64.nasm && gcc -O3 -m64 -mavx sort64.o test64.c -o test64 && ./test64
 
 oppure
 
 ./runtest32

*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <xmmintrin.h>

extern void sort64(float* x, int n);

void bubblesort(float* x, int n) {
	int i, j, l;
	float t;
	i = n - 1;
	while (i > 0) {
		l = 0;
		for (j = 0; j < i; j++)
			if (x[j] > x[j+1]) {
				  t = x[j];
				  x[j] = x[j+1];
				  x[j+1] = t;
				  l = j;
			}
		i = l;
	}
}

void merge(float* x, int a, int c, int b, float* y) {
	int i = a, j = c+1, k = a;
	while (i <= c && j <= b)
		if (x[i] < x[j]) 
			y[k++] = x[i++];
		else
			y[k++] = x[j++];
	while (i <= c)
		y[k++] = x[i++];
	while (j <= b)
		y[k++] = x[j++];
	for (i = a; i <= b; i++)
		x[i] = y[i];
}

void mergesortrec(float* x, int a, int b, float* y) {
	int n = b-a+1;
	float t;
	if (n == 2) {
		if (x[a] > x[b]) {
			  t = x[a];
			  x[a] = x[b];
			  x[b] = t;
		}
	} else if (n > 2) {
		int c = (a+b)/2;
		mergesortrec(x,a,c,y);
		mergesortrec(x,c+1,b,y);
		merge(x,a,c,b,y);
	}
}

void mergesort(float* x, int n) {
	float* y = calloc(n,sizeof(float));
	mergesortrec(x,0,n-1,y);
	free(y);
}

void quicksortrec(float* x, int a, int b) {
	int n = b-a+1, t;
	if (n == 2) {
		if (x[a] > x[b]) {
			  t = x[a];
			  x[a] = x[b];
			  x[b] = t;
		}
	} else if (n > 2) {
		
		int c = (a+b)/2;
		
		int i = a, j = b;
		float p = x[c];
		while (i <= j) {
			while (i <= b && x[i] < p)
				i++;
			while (j >= a && x[j] > p)
				j--;
			if (i <= j) {
				t = x[i];
				x[i++] = x[j];
				x[j--] = t;
			}
		}
		if (j > a)
			quicksortrec(x,a,j);
		if (i < b)
			quicksortrec(x,i,b);
	}
}

void quicksort(float* x, int n) {
	quicksortrec(x,0,n-1);
}

void quicksortrrec(float* x, int a, int b) {
	int n = b-a+1, t;
	if (n == 2) {
		if (x[a] > x[b]) {
			  t = x[a];
			  x[a] = x[b];
			  x[b] = t;
		}
	} else if (n > 2) {
	  
		int c = a+irand(b-a+1);
	
		int i = a, j = b;
		float p = x[c];
		while (i <= j) {
			while (i <= b && x[i] < p)
				i++;
			while (j >= a && x[j] > p)
				j--;
			if (i <= j) {
				t = x[i];
				x[i++] = x[j];
				x[j--] = t;
			}
		}
		if (j > a)
			quicksortrec(x,a,j);
		if (i < b)
			quicksortrec(x,i,b);
	}
}

void quicksortr(float* x, int n) {
	quicksortrrec(x,0,n-1);
}

float* getbuf(int n) {
	int i;
	float* buf = (float*) _mm_malloc(n*sizeof(float),32);
	return buf;      
}

float* getmemc(long n) { 
	printf("%i\n", sizeof(long));
	float* p = (float*) _mm_malloc(4*n,32); 
	return p;
}

void frememc(int* p) { _mm_free(p); }

int sorted(float* x, int n) {
	int i;
	for (i = 0; i < n-1; i++)
		if (x[i] > x[i+1])
			return 0;
	return 1;
}

int irand(int n) {
	long r = random();
	return (int) r-(r/n)*n;
}

void sequence(float* x, int n, char* seq) {
	int i, p;
	for (i = 0; i < n; i++)
		switch (seq[0]) {
		    case 'r':	x[i] = (float) irand(n);
				break;
		    case 'n':	p = irand(i+1);
				if (p <= i*0.01) {
					x[i] = x[p];
					x[p] = (float) i;
				} else
					x[i] = (float) i;
				break;
		    case 's':	x[i] = (float) i;
				break;
		    case 'i':	
		    default:	x[i] = (float) n - i - 1;
		}
}

void main(int argc, char** argv) {
	int n = 100000;
	char* alg = "sort64";
	char* seq = "n";
	int silent = 0, display = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-n") == 0) {
			par++;
			if (par < argc) {
				n = atoi(argv[par]);
				par++;
			}
		} else if (strcmp(argv[par],"-t") == 0) {
			par++;
			if (par < argc) {
				seq = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-a") == 0) {
			par++;
			if (par < argc) {
				alg = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-n <sequence_size>][-t <sequence_type>][-a <sorting_algorithm>][-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-n <sequence_size> : number of floating-point numbers to sort (default=100000)\n");
		printf("\t-t <sequence_type> : i=inverted, r=random, n=nearly-sorted, s=sorted (default=n)\n");
		printf("\t-a <sorting_algorithm> : bubblesort,mergesort,quicksort,quicksortr,sort32 (default=sort32)\n");
		printf("\t-d : displays input and output sequences\n");
		printf("\t-s : silent\n");
	
		printf("\nSorting %i single precision floating-point numbers through the %s algorithm.\n", n, alg);
	}

	if (n > 0) {
		float* x = getbuf(n);
		sequence(x,n,seq);
	
		if (!silent && display) {
			printf("\nInput sequence:\n");
			for (i = 0; i < n; i++)
				printf("%.1f ", x[i]);
			printf("\n");
		}

		clock_t t = 0;
		
		if (strcmp(alg,"bubblesort") == 0) {
			t = clock(); bubblesort(x,n); t = clock() - t;
		} else if (strcmp(alg,"mergesort") == 0) {
			t = clock(); mergesort(x,n); t = clock() - t;
		} else if (strcmp(alg,"quicksort") == 0) {
			t = clock(); quicksort(x,n); t = clock() - t;
		} else if (strcmp(alg,"quicksortr") == 0) {
			t = clock(); quicksortr(x,n); t = clock() - t;
		} else if (strcmp(alg,"sort64") == 0) {
			t = clock(); sort64(x,n); t = clock() - t;
		}
		if (!silent)
			printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
		else
			printf("%.3f", ((float)t)/CLOCKS_PER_SEC);
		
		if (!silent && display) {
			printf("\nOutput sequence:\n");
			for (i = 0; i < n; i++)
				printf("%.1f ", x[i]);
			printf("\n");
		}
		
		int check = sorted(x,n);
		if (!silent) {
			if (check)
				printf("\nThe sequence is sorted.\n");
			else
				printf("\nThe sequence is not sorted!!!\n");
		} else
			printf(" %i\n", check);
		
		free(x);
	}
	
}
