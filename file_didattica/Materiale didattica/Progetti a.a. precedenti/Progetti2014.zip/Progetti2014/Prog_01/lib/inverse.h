#include <xmmintrin.h>

float* AI(float* A, int n);
void gaussJordan(float* M, int r, int c);
void swapRows(float* M, int c, int k, int p);

void inverse(float* A, float* inv, int n)
{
	float* ai = AI(A, n);
	gaussJordan(ai,n,n*2);
	int i;
	for(i = 0; i < n; i++)
	{
		int j;
		for(j = 0; j < n; j++)
		{
			inv[i*n+j] = ai[i*2*n+n+j];
		}
	}
}

/**
 * Restituisce una matrice formata affiancando la matrice identità di grado n
 * alla matrice A da invertire. La nuova matrice avrà n righe e 2*n colonne.
 * Le prime n colonne sono uguali alla matrice A, le seconde n colonne sono
 * la matrice identità.
 */
float* AI(float* A, int n)
{
	float* ai = (float*) _mm_malloc(sizeof(float)*n*2*n, 16);
	int i;
	for(i = 0; i < n; i++)
	{
		int j;
		for(j = 0; j < n; j++)
		{
			ai[i*2*n+j] = A[i*n+j];
			if(i == j)
			{
				ai[i*2*n+n+j] = 1;
			}
		}
	}
	return ai;
}

/**
 * Effettua l'eliminazione di Gauss-Jordan sulla matrice M
 * formata da r righe e c colonne.
 */
void gaussJordan(float* M, int r, int c)
{
	int k,i,j;
	for(k = 0; k < r && k < c; k++)
	{
		if(M[k*c+k] == 0)
		{
			for(i = k+1; i < r; i++)
			{
				if(M[i*c+i] != 0)
				{
					swapRows(M,c,i,k);
					break;
				}
			}
		}

		for(i = k+1; i < c; i++)
		{
			M[k*c+i] /= M[k*c+k];
		}
		M[k*c+k] = 1.0;

		for(i = k+1; i < r; i++)
		{
			if(M[i*c+k] != 0)
			{
				int j;
				for(j = k+1; j < c; j++)
				{
					M[i*c+j] -= M[k*c+j] * M[i*c+k];
				}
				M[i*c+k] = 0;
			}
		}
	}

	for(k = 1; k < r && k < c; k++)
	{
		for(i = k - 1; i >= 0; i--)
		{
			if(M[i*c+k] != 0)
			{
				for(j = k+1; j < c; j++)
				{
					M[i*c+j] -= M[i*c+k] * M[k*c+j];
				}
			}
			M[i*c+k] = 0;
		}
	}
}

/**
 * Data la matrice M con c colonne in input, effettua lo scambio
 * delle righe k-esima e p-esima.
 */
void swapRows(float* M, int c, int i, int k)
{
	if( i == k) return;
	int j;
	for(j = 0; j <c; j++)
	{
		float temp = M[i*c+j];
		M[i*c+j] = M[k*c+j];
		M[k*c+j] = temp;
	}
}
