#define BL 8

void product0(float* A, float*B, float* C, int m, int n, int p)
{
	int i,j,k;
	for(i = 0; i < m; i++)
	{
		for(j = 0; j < p; j++)
		{
			for(k = 0; k < n; k++)
			{
				C[i*p+j] += A[i*n+k] * B[k*p+j];
			}
		}
	}
}

void product1(float* A, float*B, float* C, int m, int n, int p)
{
        int i,j,k;
	float t;
        for(i = 0; i < m; i++)
        {
                for(j = 0; j < p; j++)
                {
			t = C[i*p+j];
                        for(k = 0; k < n; k++)
                        {
                                t += A[i*n+k] * B[k*p+j];
                        }
			C[i*p+j] = t;
                }
        }
}


void product2(float* A, float*B, float* C, int m, int n, int p)
{
        int i,j,k;
        for(i = 0; i < m; i++)
        {
		//loop-interchange
                for(k = 0; k < n; k++)
                {
                        for(j = 0; j < p; j++)
                        {
                                C[i*p+j] += A[i*n+k] * B[k*p+j];
                        }
                }
        }
}

void square_sub_product0(float* A, float* B, float* C, int si, int sj, int sk, int n)
{
	int i,j,k;
	for(i = si; i < si+BL; i++)
	{
		for(j = sj; j < sj+BL; j++)
		{
			float t = C[i*n+j];
			for(k = sk; k < sk+BL; k++)
			{
				t += A[i*n+k] * B[k*n+j];
			}
			C[i*n+j] = t;
		}
	}
}

void square_sub_product1(float* A, float* B, float* C, int si, int sj, int sk, int n)
{
	int i,j,k;
	for(i = si; i < si+BL; i++)
	{
		for(k = sk; k < sk+BL; k++)
		{
			for(j = sj; j < sj+BL; j++)
			{
				C[i*n+j] += A[i*n+k] * B[k*n+j];
			}
		}
	}
}

void square_product(float* A, float* B, float* C, int n)
{
	int i,j,k;
	for(i = 0; i < n; i += BL)
	{
		for(j = 0; j < n; j += BL)
		{
			for(k = 0; k < n; k += BL)
			{
				square_sub_product0(A,B,C,i,j,k,n);
			}
		}
	}
}

void product4_tras(float* A, float* B_tras, float* C, int m, int n, int p)
{
	int i,j,k;
	for(i = 0; i < m; i++)
	{
		for(j = 0; j < p; j++)
		{
			for(k = 0; k < n; k++)
			{
				C[i*p+j] += A[i*m+k] * B_tras[j*p+k];
			}
		}
	}
}

void product5_tras(float* A, float* B_tras, float* C, int m, int n, int p)
{
        int i,j,k,in,jn,ip,ipj;
	float t;
        for(i = 0; i < m; i++)
        {
		in = i*n;
		ip = i*p;
                for(j = 0; j < p; j++)
                {
			ipj = ip+j;
			t = C[ipj];
			jn = j*n;
                        for(k = 0; k < n; k++)
                        {
                                t += A[in+k] * B_tras[jn+k];
                        }
			C[ipj] = t;
                }
        }
}

void product6(float* A, float* B, float* C, int m, int n, int p)
{
	}
