void transpose0(float* x, float* xT, int r, int c)
{
	int i,j;
	for(i = 0; i < c; i++)
	{
		for(j = 0; j < r; j++)
		{
			xT[i*r+j] = x[j*c+i];
		}
	}
}

void transpose1(float* x, float* xT, int r, int c)
{
	int i,j;
	for(i = 0; i < c; i++)
	{
		for(j = 0; j < r-3; j+= 4) //loop-unrolling 4
		{
			xT[i*r+j] = x[j*c+i];
			xT[i*r+j+1] = x[j*c+i+c];
			xT[i*r+j+2] = x[j*c+i+2*c];
			xT[i*r+j+3] = x[j*c+i+3*c];
		}
		for(;j < r; j++) //rest loop
		{
			xT[i*r+j] = x[j*c+i];
		}
	}
}

void transpose2(float* x, float* xT, int r, int c)
{
	int i,j,irj,jci;
	for(i = 0; i < c; i++)
	{
		for(j = 0; j < r-7; j+= 8) //loop-unrolling 8
		{
			irj = i*r+j;
			jci = j*c+i;
			xT[irj] = x[jci];
			xT[irj+1] = x[jci+c];
			xT[irj+2] = x[jci+2*c];
			xT[irj+3] = x[jci+3*c];
			xT[irj+4] = x[jci+4*c];
			xT[irj+5] = x[jci+5*c];
			xT[irj+6] = x[jci+6*c];
			xT[irj+7] = x[jci+7*c];

		}
		for(;j < r; j++) //rest loop
		{
			xT[i*r+j] = x[j*c+i];
		}
	}
}

void transpose3(float* x, float* xT, int r, int c)
{
	int n = r*c;
	int k;
	for(k = 0; k < n; k++)
	{
		xT[k/c+(k%c)*r] = x[k];
	}
}



