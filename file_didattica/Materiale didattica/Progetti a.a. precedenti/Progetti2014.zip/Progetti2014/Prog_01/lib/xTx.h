void xTx0(float* Xy, float* xTx, int m, int n)
{
	int i;
	for(i = 0; i < n; i++)
	{
		int j;
		for(j = 0; j < n; j++)
		{
			int k;
			for(k = 0; k < m; k++)
			{
				xTx[i*n+j] += Xy[k*(n+1)+i] * Xy[k*(n+1)+j];
			}
		}
	}
}

void xTx1(float* Xy, float* xTx, int m, int n)
{
	int i,j,k;
	float t;
	for(i = 0; i < n; i++)
	{
		for(j = i; j < n; j++)//j parte da i
		{
			for(k = 0; k < m; k++)
			{
				t = Xy[k*(n+1)+j] * Xy[k*(n+1)+i];
				xTx[i*n+j] += t;
				if(i != j)
				{
					xTx[j*n+i] += t;
				}
			}
		}
	}
}

void xTx2(float* Xy, float* xTx, int m, int n)
{
	int i,j,k;
	float t;
	for(k = 0; k < m; k++)//loop-interchange
	{
		for(i = 0; i < n; i++)
		{
			for(j = i; j < n; j++)
			{
				t = Xy[k*(n+1)+j] * Xy[k*(n+1)+i];
				xTx[i*n+j] += t;
				if(i != j)
				{
					xTx[j*n+i] += t;
				}
			}
		}
	}
}


void xTx_tras0(float* Xy_tras, float* xTx, int m, int n)
{
	int i,j,k;
	float t;
	for(k = 0; k < m; k++)
	{
		for(i = 0; i < n; i++)
		{
			for(j = i; j < n; j++)
			{
				t = Xy_tras[j*m+k] * Xy_tras[i*m+k];
				xTx[i*n+j] += t;
				if(i != j)
				{
					xTx[j*n+i] += t;
				}
			}
		}
	}
}

void xTx_tras1(float* Xy_tras, float* xTx, int m, int n)
{
	int i,j,k;
	float t;
	for(k = 0; k < m; k++)
	{
		for(i = 0; i < n; i++)
		{
			xTx[i*n+i] += Xy_tras[i*m+k] * Xy_tras[i*m+k];

			for(j = i+1; j < n; j++)
			{
				t = Xy_tras[j*m+k] * Xy_tras[i*m+k];
				xTx[i*n+j] += t;
				xTx[j*n+i] += t;
			}
		}
	}
}

