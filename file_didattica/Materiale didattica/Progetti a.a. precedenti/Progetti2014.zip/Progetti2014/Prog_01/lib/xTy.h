void xTy0(float* Xy, float* xTy, int m, int n)
{
	int i,k;
	for(i = 0; i < n; i++)
	{
		for(k = 0; k < m; k++)
		{
			xTy[i] += Xy[k*(n+1)+i] * Xy[k*(n+1)+n];
		}
	}
}

void xTy1(float* Xy, float* xTy, int m, int n)
{
	int i,k;
	for(k = 0; k < m; k++)
	{
		for(i = 0; i < n; i++)//loop-interchange
		{
			xTy[i] += Xy[k*(n+1)+i] * Xy[k*(n+1)+n];
		}
	}
}

void xTy_tras0(float* Xy_tras, float* xTy, int m, int n)
{
	int i,k;
	for(i = 0; i < n; i++)
	{
		for(k = 0; k < m; k++)
		{
			xTy[i] += Xy_tras[i*m+k] * Xy_tras[n*m+k];
		}
	}
}

void xTy_tras1(float* Xy_tras, float* xTy, int m, int n)
{
	int i,k;
	float t;
	for(k = 0; k < m; k++)
	{
		t = Xy_tras[n*m+k];
		for(i = 0; i < n; i++)
		{
			xTy[i] += Xy_tras[i*m+k] * t;
		}
	}
}
