void carica(float *matrix, int m, int n, float *M, float *y){
	register int i;
	register int j;
	int k=0;
	int n1=n+1;
	int in;
	for(i=0;i<m;i++){
		in=i*n1;
		for(j=0;j<=n;j++){
			if(j==n){
				y[i]=matrix[in+j];
			}
			else{
				M[k]=matrix[in+j];
				k++;
			}
		}
	}
}



