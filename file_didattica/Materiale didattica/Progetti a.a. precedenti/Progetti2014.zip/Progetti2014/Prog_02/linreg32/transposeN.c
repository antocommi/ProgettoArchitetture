#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define ROUND16(x) (((x)+15) & -(16))

extern void transpose4(float *A, float  *B, int N);
extern float* pad(const float *m, int rows, int cols, int n);
extern float* unpad(const float *m, int rows, int cols, int n);

void transpose_trivial(float *A, float *B, const int n) {
	register  int i;
	register  int j;
	#pragma omp parallel for
	for(i=0; i<n; i++) {
        for(j=0; j<n; j++) {
			B[j*n+i]=A[i*n+j];
		}
	}
}

void transpose_block(float *A, float *B, const int n) {
	if(n<16){
		transpose_trivial(A, B, n);
		return;
	}
	int i;
	int j;
	register  int x;
	register  int y;
	int max_x;
	int max_y;
	#pragma omp parallel for
    for(i=0; i<n; i+=16) {
        for(j=0; j<n; j+=16) {
            max_x = i+16 < n ? i + 16 : n;
            max_y = j+16 < n ? j + 16 : n;
            for(x=i; x<max_x; x+=4) {
                for(y=j; y<max_y; y+=4) {
                    transpose4(&A[x*n +y], &B[y*n + x], n);
                }
            }
        }
    }
}

float* transposeN(float *A, int r, int c){
	int roundRow = ROUND16(r);
    int roundCols = ROUND16(c);
    register  int i;
    register  int j;
    float *RESULT;
    if ( roundRow > c || roundRow > r || roundCols > c || roundCols > r ) { 
		 int max=roundRow;
		if(roundCols>max){
			max=roundCols;
		}
		float *C=pad(A,r,c,max);
		free(A);
		float *B = (float*) malloc(sizeof(float) * max * max);
		transpose_block(C,B,max);	
		free(C);
		RESULT=unpad(B,c,r,max);
	}else {
		RESULT = (float*) malloc(sizeof(float) * r * c);
		transpose_block(A,RESULT,c);
		free(A);
	}	
	return RESULT;
}

