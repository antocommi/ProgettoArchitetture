/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*

//extern void trasposta(MATRIX A,MATRIX B,int N,int M);
void trasposta(MATRIX,MATRIX,int,int);
//extern void prodotto(MATRIX xTrasposta,MATRIX c,int n,int m);
void prodotto(MATRIX,MATRIX,MATRIX,int,int);
void riempi(MATRIX,int);
//extern triangolare(MATRIX A,MATRIX B,int m);
void triangolare(MATRIX,MATRIX,int);
void prodottoVettore(MATRIX,VECTOR,VECTOR,int,int);
//extern prodottoVettore(MATRIX A,VECTOR B,VECTOR c,int n,int m);
extern sistema(MATRIX A,MATRIX B,int n);
//void sistema(MATRIX,MATRIX,int);

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}


/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX Xy, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);
	int i=0;
	int k=0;
	int j=1;    
	MATRIX x=get_block(sizeof(float),m*n);
	MATRIX id=alloc_matrix(n,n);
	VECTOR y=get_block(sizeof(float),m);
	VECTOR ris=get_block(sizeof(float),n);
	x[0]=Xy[0];
	int z=n;
	for(i=1;i<m*(n+1);i++){
		if(i!=z){
			x[j]=Xy[i];
			j++;
		}
		else{
			y[k]=Xy[i];
			k++;
			z+=(n+1);
		}
	}
	
	MATRIX xTrasposta=get_block(sizeof(float),n*m);
	
	trasposta(x,xTrasposta,m,n);

	MATRIX prod=get_block(sizeof(float),n*n);
	for(i=0;i<n*n;i++)
		prod[i]=0;
	
	prodotto(xTrasposta,x,prod,n,m);
	
	riempi(id,n);
	
	triangolare(prod,id,n);

	sistema(prod,id,n);

	prodottoVettore(xTrasposta,y,ris,n,m);

	printf("prodotto\n");
	for(i=0; i<n*m;i++)
		printf("%f\n",xTrasposta[i]);	

	prodottoVettore(id,ris,beta,n,n);

    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------
    
   // linreg32(Xy, beta, m, n); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------

    return beta;
}

void trasposta(MATRIX a,MATRIX t,int n,int m){
	int i=0;
	int j=0;
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
			t[j*n+i]=a[i*m+j];
}

void prodotto(MATRIX a,MATRIX b,MATRIX c,int n,int m){
	int i=0;
	int j=0;	
	int k=0;
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			for(k=0;k<m;k++){
				c[i*n+j]+=a[i*m+k]*b[k*n+j];
			}
}


void riempi(MATRIX id,int m){
	int i=0;
	int k=0;
	for(i=0;i<m*m;i++){
		if(i==k){
			id[i]=(float)1;
			k+=(m+1);
		}
		else
			id[i]=0;
	}
}

/*
void sistema(MATRIX a,MATRIX I,int m){
	int i=0;
	int j=0;
	int k=0;
	for(i=m-1;i>=0;i--)
		for(j=m-1;j>=0;j--){
			for(k=i+1;k<m;k++){
				I[i*m+j]-=I[k*m+j]*a[i*m+k];
			}
			I[i*m+j]/=a[i*m+i];
		}
}
*/
void triangolare(MATRIX a,MATRIX I,int m){
	int i=0;
	int j=0;
	int k=0;
	for(j=0;j<m;j++)
		for(i=j+1;i<m;i++){
			float x=a[i*m+j]/a[j*m+j];
			for(k=j;k<m;k++)
				a[i*m+k]-=a[j*m+k]*x;
			for(k=0;k<m;k++)
				I[i*m+k]-=I[j*m+k]*x;
		}
}


	void prodottoVettore(MATRIX a,VECTOR b,VECTOR c,int n,int m){
		int i=0;
		int j=0;
		for(i=0;i<n;i++)
			for(j=0;j<m;j++)
				c[i]+=a[i*m+j]*b[j];	
	}
	
/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}



void main(int argc, char** argv) {
	int m = 10;
	int n = 2;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");

		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
