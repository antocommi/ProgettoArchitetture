/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 30 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 linreg64.nasm && gcc -O3 -m64 -mavx linreg64.o linreg64c.c -o linreg64c && ./linreg64c
 
 oppure
 
 ./runlinreg64

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*

float gauss(int n, MATRIX c, MATRIX inversa);
void prodottoMatriciC(MATRIX a, MATRIX b, MATRIX c, int righeA, int colonneB, int colonneA);
void trasposta(MATRIX A, MATRIX At, int righe, int colonne);
void stampaMatrice(MATRIX A, int righe, int colonne);
void stampaVettoreRisultato(VECTOR A, int righe);

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}


/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX Xy, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);
    
    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------

	MATRIX X = alloc_matrix(m, n);
	int i, j;
	for (i=0; i<m; i++)
		for (j=0; j<n; j++)
	    		X[i*(n)+j] = Xy[i*(n+1)+j];

	printf("\n\nMatrice X:\n\n");
	stampaMatrice(X, m, n);

	VECTOR y = get_block(sizeof(float),m);
	for (i=0; i<m; i++)
		y[i] = Xy[i*(n+1)+n];

	printf("Vettore y:\n\n");
	stampaMatrice(y, m, 1);

//	1. Calcolo matrice trasposta
	int righeXt = n;
	int colonneXt = m;

	MATRIX Xt = alloc_matrix(righeXt, colonneXt);
	//trasposta(X, Xt, m, n);
	trasposta64(X, Xt, m, n);
	printf("Matrice trasposta:\n\n");
	stampaMatrice(Xt, righeXt, colonneXt);

//	2. Calcolo prodotto matrice
	int righeC = righeXt;
	int colonneC = n;

	MATRIX XXt = alloc_matrix(righeC, colonneC);

	prodottoMatriciC(Xt, X, XXt, righeXt, n, colonneXt);
	printf("Prodotto matrice C:\n\n");
	stampaMatrice(XXt, righeC, colonneC);

/*	XXt = alloc_matrix(righeC, colonneC);
	linreg64(Xt, X, XXt, righeXt, n, colonneXt); //chiamata funzione assembly
	printf("Prodotto matrice Nasm:\n\n");
*/	stampaMatrice(XXt, righeC, colonneC);

//	3. Calcolo matrice inversa
	MATRIX inversa = alloc_matrix(righeC, colonneC);
	
	float det;
	det = gauss(righeC, XXt, inversa);
	if(det!=0){
		printf("\nDeterminante matrice inversa: %0.2f: \n", det);
		printf("\nMatrice inversa:\n");
		stampaMatrice(inversa, righeC, colonneC);

		//4. Prodotto Xt * Y
		MATRIX XtY = alloc_matrix(righeXt, 1);

		//Xt*y
		prodottoMatriciC(Xt, y, XtY, righeXt, 1, colonneXt);
		//linreg64(Xt, y, XtY, righeXt, 1, colonneXt); //chiamata funzione assembly

		//Xt*y
		prodottoMatriciC(inversa, XtY, beta, righeC, 1, colonneC);
		//linreg64(inversa, XtY, beta, righeC, 1, colonneC); //chiamata funzione assembly

		printf("Beta:\n\n");
		stampaMatrice(beta, righeC, 1);

	}
	else{
		printf("Determinante = 0 -> non esiste la matrice inversa -> FAIL!\n");
	}

    // -------------------------------------------------

    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_08.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/


void main(int argc, char** argv) {
	int m = 20;
	int n = 4;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}

// Mie funzioni


/*
	Calcola l'inversa di una matrice attraverso il metodo di Gauss
	senza pivot (= fattorizzazione LU).
	Restituisce il valore del determinante, e se questo e' nonzero
	l'inversa in b.
*/
float gauss(int n, MATRIX c, MATRIX inversa)
{

    float m, pivot, det;
    int i, j, k;

    /* Uso una matrice di appoggio `a'		*/
    /* b e' inizializzata all'identita'		*/
    MATRIX a = alloc_matrix(n, n);
	

    for (i=0; i<n; i++) {
	for (j=0; j<n; j++) {
	    a[i*n+j] = c[i*n+j];
	    inversa[i*n+j] = 0.0;
	}
	inversa[i*n+i] = 1.0;
    }

    /* Ax = b  ->  LUx = b  ->  Ux = inv(L)b		*/
    /* Fase I: moltiplica per l'inversa di L	*/

    for (k=0; k<n; k++) {
	pivot = a[k*n+k];
	if ( fabs(pivot)<5e-16 ) return 0.0;

	for (i=k+1; i<n; i++) {
	    m = a[i*n+k] / pivot ;
	    for (j=0; j<n; j++)       /* Ottimizzare: come? */
		inversa[i*n+j] -= m*inversa[k*n+j] ;
	    for (j=k; j<n; j++)
		a[i*n+j] -= m*a[k*n+j] ;
	}
    }

    /* Ux = inv(L)b  ->  x = inv(U)(inv(L)b)	*/
    /* Fase II: moltiplica per inv(U)		*/
    /*          = sostituzione all'indietro    	*/
    /* Il det. e` dato dal prodotto degli U_ii	*/
    
    det = 1.0;
    for (i=n-1; i>=0; i--) {
	pivot = a[i*n+i];
	if ( fabs(pivot)<5e-16 ) return 0.0;
	det *= pivot;
	for (k=0; k<n; k++) {
	    m = inversa[i*n+k];
	    for (j=i+1; j<n; j++)
		m -= a[i*n+j]*inversa[j*n+k];
	    inversa[i*n+k] = m / pivot;
	}
    }
    
    //libera_matrice(n,a);
    return det;
}

void prodottoMatriciC(MATRIX a, MATRIX b, MATRIX c, int righeA, int colonneB, int colonneA)
{
	int i, j, t;
	float sum;
	
	for(i=0; i<righeA; i++)
		for(j=0; j<colonneB; j++){
			sum = 0;
			for(t=0; t<colonneA; t++)
				sum+=a[i*colonneA+t]*b[t*colonneB+j];
			c[i*colonneB+j]=sum;
		}

}

void trasposta(MATRIX A, MATRIX At, int righe, int colonne)
{
	int i, j;
	for(i=0; i<righe; i++)
		for(j=0; j<colonne; j++)
			At[j*(righe)+i] = A[i*(colonne)+j];

}

void stampaMatrice(MATRIX A, int righe, int colonne){

	int i, j;
	for(i=0; i<righe; i++){
		for(j=0; j<colonne; j++){
			printf("%f ", A[i*(colonne)+j]);
		}
		printf("\n");
	}
	printf("\n");
}

void stampaVettoreRisultato(VECTOR A, int righe){

	int i, j;
	for(i=0; i<righe; i++){
		for(j=0; j<1; j++){
			printf("Beta%d %f \t", i, A[i+j]);
		}
		printf("\n");
	}
	printf("\n");
}
