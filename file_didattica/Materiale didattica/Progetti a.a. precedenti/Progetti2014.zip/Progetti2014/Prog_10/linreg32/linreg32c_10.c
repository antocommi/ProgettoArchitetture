/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>
//#include /home/francesco/Documenti/FunzioniAssembly.nasm
//#include </home/francesco/Documenti/FunzioniAssembly.o>
//#include "/home/francesco/Documenti/sseutils.nasm"
//#include </home/francesco/Documenti/sseutils.o>
/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e; 
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y;
//*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 *//*
MATRIX load_input(char* filename, int *m, int *n, MATRIX *X, VECTOR *y) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);

	MATRIX X0 = alloc_matrix(rows,cols-1);
	VECTOR y0 = 
	//for per leggere le righe
	//a ogni riga leggo cols-1 elementi e li copio in X e un solo elemento lo
	//copio in y
		status = fread(//&X0[i*(cols-1)] Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;

	*X = X0;
	*y = y0;

	return Xy;
}*/


MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;

	return Xy;
}

extern void prodotto(MATRIX A,MATRIX B,MATRIX C,int i,int j, int k, int m, int n);

void prodBL(MATRIX A,MATRIX B,MATRIX C,int m,int n){
	int i,j,k;
	int bl=32;

	for(i=0;i<m;i+=bl){
		for(j=0;j<m;j+=bl){
		for(k=0;k<n;k+=bl){

		 prodotto(A,B,C,i,j,k,m,n);

}}}}
extern void prodotto(MATRIX A,MATRIX B,MATRIX C,int i,int j, int k, int m, int n);

void prodBL2(MATRIX A,MATRIX B,MATRIX C,int m,int n){
	int i,j,k;
	int bl=32;

	for(i=0;i<n;i+=bl){//c'era m
		for(j=0;j<m;j+=bl){
		for(k=0;k<n;k+=bl){

		 prodotto(A,B,C,i,j,k,m,n);

}}}}
/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	
	fclose(fp);

}


/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */





void Scompatta(MATRIX Xy, MATRIX X,VECTOR v,int m, int n){
int i,j;
for(i=0;i<m;i++){
	for(j=0;j<n+1;j++){
		if(j<n){
			X[i*n+j]=Xy[i*(n+1)+j];
		}else if(j==n){
			v[i]=Xy[i*(n+1)+j];
			}
}}}



extern scambio(MATRIX X,VECTOR y,int imax,int k,int m);

scambioRighe(MATRIX X,int imax,int k,int m){
VECTOR y=get_block(sizeof(float),m);

scambio(X,y,imax,k,m);

}



extern fatt8(MATRIX X,int m,int i,int k,int s);
extern fatt2(MATRIX X,int m,int i,int k,int s);
extern void sum16(MATRIX X,VECTOR y,float* sum,int m,int bloc,int i);
extern void sumn(MATRIX X,VECTOR y,float* sum,int m,int bloc,int i,int bloc2);
MATRIX inverse(MATRIX X, int m,int n){
	
int i,j;
int fv,fg;
int l,z;

MATRIX x2=alloc_matrix(m,n);
MATRIX b2=alloc_matrix(m,n);
int bl;
int bl2;

float v;
int r;
int q;
int tmp;

int k;
int p;
int imax;
float max;
float mul;
int t,g,s;


for(q=0;q<m;q++){
for(r=0;r<m;r++){
if(r==q){
b2[q*m+r]=1;
}else{
b2[q*m+r]=0;
}}}

for( k=0;k<m;k++){

max=X[k+k*m];
imax=k;
MATRIX C=alloc_matrix(m,m);
for(i=k+1;i<m;i++){
	if(fabs(X[k+i*m])> fabs(max)){
	max=fabs(X[k+i*m]);
	imax=i;
}       }

if(imax!=k){

	for(g=0;g<m;g++){
		if(b2[k*m+g]==1){
			s=g;
	}else if(b2[imax*m+g]==1){
		t=g;
		}
	}

	for(g=0;g<m;g++){
	if(g==s){
	b2[imax*m+g]=1;
	b2[k*m+g]=0;
	}else if(g==t){

	b2[k*m+g]=1;
	b2[imax*m+g]=0;
	}else{
	b2[k*m+g]=0;
	b2[imax*m+g]=0;
	}
	}

	scambioRighe(X,imax,k,m);
	}

if(X[k*m+k]==0){
return;
}
v=(1/(X[k*m+k]));

for(i=k+1;i<m;i++){
X[i*m+k]=X[i*m+k]*v;

}


bl=m-(k+1);
bl2=0;

while(bl%24!=0){
bl--;
bl2++;
}


for(i=k+1;i<m;i++){

if(bl>0&&bl2>0){
	fatt8(X,m,i,k,bl);
	fatt2(X,m,i,k,bl2);
}else if(bl>0){
	fatt8(X,m,i,k,bl);
}else if(bl2>0){
	fatt2(X,m,i,k,bl2);
}



}


}
int bloc;
int bloc2;


int h;
for(h=0;h<m;h++){
float y[m];
for(i=0;i<m;++i){
float sum=0;

bloc=i;
bloc2=0;
while(bloc%12!=0){
bloc--;
bloc2++;
}


if(bloc>0&&bloc2>0){

sum16(X,y,&sum,m,bloc,i);
sumn(X,y,&sum,m,bloc,i,bloc2);
}else if(bloc>0){
sum16(X,y,&sum,m,bloc,i);
}else if(bloc2>0){
sumn(X,y,&sum,m,bloc,i,bloc2);
}

y[i]=(b2[h+i*m]-sum);

}


for(i=m-1;i>=0;--i){
float sum=0;

for(k=i+1;k<m;++k){
sum+=X[i*m+k]*x2[h+k*m];}

x2[h+i*m]=(y[i]-sum)/X[i*m+i];
}

}


return x2;
}

extern void trasposta(MATRIX A,MATRIX B,int i,int j, int m, int n);

void traspostaBL(MATRIX A,MATRIX B,int m,int n){
int i,j;
int bl=4;

for (i=0;i<m;i+=bl){
	for(j=0;j<n;j+=bl){
	
	trasposta(A,B,i,j,m,n);
}}

}


extern prodottoMV(MATRIX X, VECTOR y,VECTOR b,int m,int n); 
VECTOR linreg(MATRIX Xy, int m, int n) {
     
     //VECTOR beta = get_block(sizeof(float),n);	
VECTOR  beta;
     MATRIX X=alloc_matrix(m,n);
     MATRIX B=alloc_matrix(n,m);	
     MATRIX T=alloc_matrix(n,n);
     VECTOR y=get_block(sizeof(float),m);
     VECTOR y1=get_block(sizeof(float),n);
     MATRIX C=alloc_matrix(n,n);
    beta = get_block(sizeof(float),n);

	Scompatta(Xy,X,y,m,n);
	traspostaBL(X,B,m,n);
	prodBL(B,X,C,n,m);
	
	T= inverse(C,n,n);
	
	prodottoMV(B,y,y1,n,m);
  	
	prodottoMV(T,y1,beta,n,n);
	

    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return (err/(m*n));
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_10.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/

void main(int argc, char** argv) {
	int m;//RIGHE
	int n;//COLONNE
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	
	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);

	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);


}
