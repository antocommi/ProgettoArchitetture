nasm -f elf32 sum16.nasm && nasm -f elf32 sumn.nasm && nasm -f elf32 inversan.nasm && nasm -f elf32 inversa24.nasm && nasm -f elf32 scambio.nasm && nasm -f elf32 traspostan.nasm && nasm -f elf32 FunzioniAssemblyF4.nasm && nasm -f elf32 prodottoMV.nasm && nasm -f elf32 linreg32.nasm

gcc -m32 -msse -O0 scambio.o inversan.o inversa24.o sumn.o sum16.o traspostan.o prodottoMV.o FunzioniAssemblyF4.o  linreg32.o linreg32c_10.c -o linreg32c_10

./linreg32c_10 $1 $2 $3 $4 $5 $6 $7 $8 $9 $10

