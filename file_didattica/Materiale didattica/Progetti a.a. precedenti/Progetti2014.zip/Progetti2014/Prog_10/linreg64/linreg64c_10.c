/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 30 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 linreg64.nasm && gcc -O3 -m64 -mavx linreg64.o linreg64c.c -o linreg64c && ./linreg64c
 
 oppure
 
 ./runlinreg64

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,32); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}

void niente(){
printf("\nSTRINGA:\n");
}


extern void prodotto64(MATRIX A,MATRIX B,MATRIX C,int i,int j, int k, int m, int n);



void prodBL(MATRIX A,MATRIX B,MATRIX C,int m,int n){
	int i,j,k;
	int bl=64;

	for(i=0;i<m;i+=bl){
		for(j=0;j<m;j+=bl){
		for(k=0;k<n;k+=bl){

		 prodotto64(A,B,C,i,j,k,m,n);
//}
}}}}


extern void trasposta64(MATRIX A,MATRIX B,int si,int sj, int m, int n);

void trasposeBL(MATRIX A,MATRIX B,int m,int n){
	int i,j;
	int bl=4;

	for(i=0;i<m;i+=bl){
		for(j=0;j<n;j+=bl){
		

		trasposta64(A,B,i,j,m,n);

}}
}

extern scambio64(MATRIX X,VECTOR y,int imax,int k,int m);

scambioRighe(MATRIX X,int imax,int k,int m){
VECTOR y=get_block(sizeof(float),m);

scambio64(X,y,imax,k,m);

}


extern fatt8(MATRIX X,int m,int i,int k,int s);
extern fatt2(MATRIX X,int m,int i,int k,int s);
extern sum1664(MATRIX X,VECTOR y,float* sum,int m,int bloc,int i);
extern sumn64(MATRIX X,VECTOR y,float* sum,int m,int bloc,int i,int bloc2);
MATRIX inverse(MATRIX X, int m,int n){
niente();
//printf("\n INIZIO \n");	
int i,j;
int fv,fg;
int l,z;
/*
for (fv = 0; fv < m; fv++) {
		for(fg=0;fg<m;fg++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", X[fv*m+fg]);
		}
		printf("\n");
	}
printf("\n");
*/

	MATRIX x2=alloc_matrix(m,n);
	MATRIX b2=alloc_matrix(m,n);
int bl;
int bl2;

float v;
int r;
int q;
int tmp;

int k;
int p;
int imax;
float max;
float mul;
int t,g,s;
//MATRIX b3=alloc_matrix(m,m);

for(q=0;q<m;q++){
for(r=0;r<m;r++){
if(r==q){
b2[q*m+r]=1;
}else{
b2[q*m+r]=0;
}}}

for( k=0;k<m;k++){
/*
printf("\n ITERAZIONE \n");


printf("\n prima del pivoting %d \n",k);
for (l = 0; l < m; l++) {
		for(z=0;z<m;z++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", X[l*m+z]);
		}
		printf("\n");
	}
printf("\n");
*/
max=X[k+k*m];
imax=k;
MATRIX C=alloc_matrix(m,m);
for(i=k+1;i<m;i++){
	if(fabs(X[k+i*m])> fabs(max)){
	max=fabs(X[k+i*m]);
	imax=i;
}       }

if(imax!=k){

	for(g=0;g<m;g++){
	if(b2[k*m+g]==1){
	s=g;
	}else if(b2[imax*m+g]==1){
	t=g;}
	}

	for(g=0;g<m;g++){
	if(g==s){
	b2[imax*m+g]=1;
	b2[k*m+g]=0;
	}else if(g==t){

	b2[k*m+g]=1;
	b2[imax*m+g]=0;
	}else{
	b2[k*m+g]=0;
	b2[imax*m+g]=0;
	}
	}
/*
	for(q=0;q<m;q++){
	for(r=0;r<m;r++){
	if(q==k && r==imax){
	b3[q*m+r]=1;
	}else if(q==imax&&r==k){
	b3[q*m+r]=1;
	}else if(r==q && ((q!=k&&r!=imax)||(q!=imax&&r!=k))){
	b3[q*m+r]=1;
	}else{
	b3[q*m+r]=0;
	}}}
*/
	//printf("\n prodotto %d ",k);
	scambioRighe(X,imax,k,m);
	//prodotto2(b3,X,C,m,n);
	//prodBL(b3,X,C,m,m);

	//dealloc_matrix(b3);
	/*for(q=0;q<m;q++){
	for(r=0;r<m;r++){
	X[q*m+r]=C[q*m+r];
	}}

	dealloc_matrix(C);*/
}//IF

/*
printf("\n");
printf("\n PIVOTING \n");
for (l = 0; l < m; l++) {
		for(z=0;z<m;z++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", X[l*m+z]);
		}
		printf("\n");
	}
//printf("\n");
printf("\n prima di fatt \n");
printf("%f",X[k*m+k]);
*/

if(X[k*m+k]==0){
return;
}
v=(1/(X[k*m+k]));

for(i=k+1;i<m;i++){
X[i*m+k]=X[i*m+k]*v;
//printf("%d",i);
}

/*
printf("\n modifica 1/v \n");
for (l = 0; l < m; l++) {
		for(z=0;z<m;z++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", X[l*m+z]);
		}
		printf("\n");
	}
printf("\n");
*/

bl=m-(k+1);
bl2=0;

while(bl%48!=0){
bl--;
bl2++;
}
/*
printf("\n BL \n");
printf("%d",bl);
printf("\n BL \n");
*/
//printf("%d",bl2);


for(i=k+1;i<m;i++){


//printf("%d",bl);
//printf("%d",bl2);

/*
for(j=k+1;j<m;j++){
mul=X[i*m+k]*X[k*m+j];
X[i*m+j]=(X[i*m+j]-mul);
}

*/
//printf("\n fatt \n");




if(bl>0&&bl2>0){
//printf("\n");
//printf("%d",bl);
fatt8(X,m,i,k,bl);
fatt2(X,m,i,k,bl2);
}else if(bl>0){
fatt8(X,m,i,k,bl);
}else if(bl2>0){
fatt2(X,m,i,k,bl2);
}
//printf("\n");
/*
for (i = 0; i < m; i++) {
		for(j=0;j<m;j++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", X[i*m+j]);
		}
		printf("\n");
	}
*/
//fatt2(X,m,i,k,bl);



}//forI




//}
/*
printf("\n matrice permutazione %d \n",k);
for (l = 0; l < m; l++) {
		for(z=0;z<m;z++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", b2[l*m+z]);
		}
		printf("\n");
	}
printf("\n");
printf("\n matrice permutazione %d \n",k);
for (l = 0; l < m; l++) {
		for(z=0;z<m;z++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", b2[l*m+z]);
		}
		printf("\n");
	}


printf("\n");*/
//printf("%d",k);
/*
printf("\n");
for (i = 0; i < m; i++) {
		for(j=0;j<m;j++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", X[i*m+j]);
		}
		printf("\n");
	}
*/

}
/*
printf("\n matrice permutazione %d \n",k);
for (l = 0; l < m; l++) {
		for(z=0;z<m;z++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", b2[l*m+z]);
		}
		printf("\n");
	}
*/
/*
printf("\n");
printf("\n FATTORIZZAZIONE \n");
for (l = 0; l < m; l++) {
		for(z=0;z<m;z++){
			//if (i % (m) == 0)
				//printf("\n");
			printf("%f ", X[l*m+z]);
		}
		printf("\n");
	}
printf("\n");
*/

int bloc;
int bloc2;

printf("\n FATTORIZZAZIONE FINITA \n");
int h;
for(h=0;h<m;h++){
float y[m];
for(i=0;i<m;++i){
float sum=0;




bloc=i;
bloc2=0;
while(bloc%56!=0){
bloc--;
bloc2++;
}

/*
printf("\n BLOC \n");
printf("%d",bloc);
printf("%d",bloc2);
printf("\n fine BLOC \n");
*/


if(bloc>0&&bloc2>0){
//printf("\n");
//printf("%d",bloc);
sum1664(X,y,&sum,m,bloc,i);
//printf("\n SOMMA %f \n",sum);
sumn64(X,y,&sum,m,bloc,i,bloc2);
//printf("\n SOMMA %f \n",sum);
}else if(bloc>0){
sum1664(X,y,&sum,m,bloc,i);
}else if(bloc2>0){
sumn64(X,y,&sum,m,bloc,i,bloc2);
}

//printf("\n SOMMA %f \n",sum);



/*

for(k=0;k<i;++k){
sum+=X[i*m+k]*y[k];
}
*/



y[i]=(b2[h+i*m]-sum);

//y[i]=(tmp[i]-sum);
}
//printf("\n");
//for(j=0;j<m;j++){
			//if (i % (m) == 0)
				//printf("\n");
//			printf("%f ", y[j]);
//		}


for(i=m-1;i>=0;--i){
float sum=0;

/*
bloc=m-(i+1);
bloc2=0;
while(bloc%16!=0){
bloc--;
bloc2++;
}
if(bloc>0&&bloc2>0){
//printf("\n");
//printf("%d",bloc);
sum162(X,y,sum,m,bloc,i);
sumn2(X,y,sum,m,bloc,i,bloc2);
}else if(bloc>0){
sum162(X,y,sum,m,bloc,i);
}else if(bloc2>0){
sumn2(X,y,sum,m,bloc,i,bloc2);
}
	


*/
for(k=i+1;k<m;++k){
sum+=X[i*m+k]*x2[h+k*m];}
x2[h+i*m]=(y[i]-sum)/X[i*m+i];
}
//printf("%d",h);
}


return x2;
}

void Scompatta(MATRIX Xy, MATRIX X,VECTOR v,int m, int n){
int i,j;
for(i=0;i<m;i++){
for(j=0;j<n+1;j++){
if(j<n){
X[i*n+j]=Xy[i*(n+1)+j];
}else if(j==n){
v[i]=Xy[i*(n+1)+j];
}
}}}

/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */

//extern void trasposta64(MATRIX A,MATRIX B,int si,int sj,int m,int n);
//extern void prodotto64(MATRIX A,MATRIX B,MATRIX C,int si,int sj,int sk,int m,int n);
extern void prodottoMV64(MATRIX A,VECTOR y,VECTOR b,int m,int n);
VECTOR linreg(MATRIX Xy, int m, int n) {

VECTOR beta;
    MATRIX X=alloc_matrix(m,n);
     MATRIX B=alloc_matrix(n,m);	
     MATRIX T=alloc_matrix(n,n);
     VECTOR y=get_block(sizeof(float),m);
     VECTOR y1=get_block(sizeof(float),n);
	//VECTOR y2=get_block(sizeof(float),n);
     // T= random_input(n,m);
     MATRIX C=alloc_matrix(n,n);
  
beta=get_block(sizeof(float),n);

  // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------
    int i,j,k;
for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
		 X[i*n+j]=0.00;
		}
//		printf("\n");
	}


for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
		 B[i*m+j]=0.00;
		}
//		printf("\n");
	}
for (i = 0; i < n; i++) {
                        for (j = 0; j < n; j++) {
                 C[i*n+j]=0.00;
                }
 //              printf("\n");
        }


for(i=0;i<n;i++){
	y1[i]=0.00;	
}


for(i=0;i<n;i++){
        beta[i]=0.00;     
}
/*
    linreg64(Xy, beta, m, n); // Esempio di chiamata di funzione assembly
*/
    // -------------------------------------------------
	Scompatta(Xy,X,y,m,n);
	
/*
printf("\n MATRICE INIZIALE \n");	 
for(i=0;i<m;i++){
		for (j=0;j<n;j++){
			//if (i % (n) == 0)
				//printf("\n");
			printf("%f ", X[i*n+j]);
		}
		printf("\n");
	}

printf("\n");
*/

	trasposeBL(X,B,m,n);
/*
for (i = 0; i < n; i++) {
		for(j=0;j<m;j++){
			//if (i % (n) == 0)
				//printf("\n");
			printf("%f ", B[i*m+j]);
		}
		printf("\n");
	}
printf("\n");
*/

	//trasposta64(X,B,0,0,m,n);
	prodBL(B,X,C,n,m);
/*
printf("\n PRODOTTO \n");
for (i = 0; i < n; i++) {
		for(j=0;j<n;j++){
			//if (i % (n) == 0)
				//printf("\n");
			printf("%f ", C[i*n+j]);
		}
		printf("\n");
	}
printf("\n");
*/
/*
printf("\n VETTORE Y \n");
for (i = 0; i < m; i++) {
		//for(j=0;j<n;j++){
			//if (i % (n) == 0)
				//printf("\n");
			printf("%f ", y[i]);
		//}
		//printf("\n");
	}
printf("\n");
*/


/*
printf("\n VETTORE Y1 \n");
printf("\n");
for (i = 0; i < n; i++) {
		//for(j=0;j<n;j++){
			//if (i % (n) == 0)
				//printf("\n");
			printf("%f ", y1[i]);
		//}
		//printf("\n");
	}
printf("\n");
/*
for(i=0;i<m;i+=bl){
		for(j=0;j<m;j+=bl){
		for(k=0;k<n;k+=bl){
	prodotto64(X,B1,C,i,j,k,m,n);
}
}
}
*/


 T=inverse(C,n,n);

/*
printf("\n INVERSA \n");
for (i = 0; i < n; i++) {
		for(j=0;j<n;j++){
			//if (i % (n) == 0)
				//printf("\n");
			printf("%f ", T[i*n+j]);
		}
		printf("\n");
	}
printf("\n");
*/

prodottoMV64(B,y,y1,n,m);


/*
for(i=0;i<n;i++){
	y1[i]=1;
	
}
*/
/*
printf("\n matrice inversa \n");
for (i = 0; i < m; i++) {
			for (j = 0; j < m; j++) {
			printf("%f ", C[i*m+j]);
		}
		printf("\n");
	
	}
*/


prodottoMV64(T,y1,beta,n,n);
/*
printf("\n BETA \n");
for (i = 0; i < n; i++) {
		//for(j=0;j<n;j++){
			//if (i % (n) == 0)
				//printf("\n");
			printf("%f ", beta[i]);
		//}
		//printf("\n");
	}
printf("\n");
*/
/*
for (i = 0; i < m; i++) {
			printf("%f ", b[i]);
}


//void niente();
*/

    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return (err/(m*n));
}



void main(int argc, char** argv) {
	int m = 1024;
	int n = 512;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");

		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;
	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
