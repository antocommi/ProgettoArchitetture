/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>

#define swap(x,y) { typeof(x) tmp = x; x=y; y=tmp; }
/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*

extern void matr_tr_B(MATRIX A, MATRIX Atr, int si, int sj, int N, int M);
extern void matr_I_B(MATRIX Atr, int N, int si, int sj);
extern void matr_zero_B(MATRIX A, int N, int si, int sj);
extern void matr_prod_B(MATRIX A, MATRIX B, MATRIX C, int  i, int j, int k, int Ma, int Mb);
extern void swap_row_B(MATRIX A, MATRIX Ainv, int i, int max_j, int N);
extern void LU_Ap_prod_B(MATRIX Ap, MATRIX LU, int i, int j, int k, int N);
extern void LU_Ap_store_B(MATRIX Ap, MATRIX LU, int k, int j, int N);
extern void matr_prod_tr_B(MATRIX A, MATRIX B, MATRIX C, int  i, int j, int k, int Ma, int Mb);
extern void matr_col_order_B(MATRIX A, MATRIX Acol, int i, int j, int N, int M);

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}

/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}

/**************************************/

void preleva_y(MATRIX Xy, MATRIX Xy_new, VECTOR y, int m, int n) {
  int i,j; 
  for(i=0; i<m; i++)
    for(j=0; j<n; j++)
      Xy_new[i*(n-1)+j] = Xy[i*(n)+j];   

  for(i=0; i<m; i++)
    y[i*1]=Xy[i*n+(n-1)];  
}

void matr_tr(MATRIX A, MATRIX Atr, int N, int M) {
  int i,j,B;
  B=4;
  for(i=0; i<N; i+=B) {
    for(j=0; j<M; j+=B) {
       matr_tr_B(A,Atr,i,j,N,M);  
    }
  }
}

void matr_zero(MATRIX A, int N, int M) {
  int i,j,B;
  B=4;
  for(i=0; i<N; i+=B) {
    for(j=0; j<M; j+=B) {  
       matr_zero_B(A,N,i,j);  
    }
  }
}

void matr_I(MATRIX Ainv, int N) {
  int i,j,B=4;
  for(i=0; i<N; i+=B) 
    for(j=0; j<N; j+=B) { 
      matr_I_B(Ainv,N,i,j);
    }
}
/*
void read_matrix(MATRIX A, int N, int M) {
  int i,j;
  for(i=0; i<N; i++)
    for(j=0; j<M; j++) {
      printf("A[%d][%d]=",i,j);
      scanf("%f",&A[i*M+j]);
    }
}
*/
void print_matrix(MATRIX A, int N, int M) {
  int i,j;
  for(i=0; i<N; i++) {
    for(j=0; j<M; j++) {
      printf("%.1f ",A[i*M+j]);
    }
      printf("\n");
  }
}

void matr_mul(MATRIX A, MATRIX B, MATRIX C, int Na, int Ma, int Nb, int Mb) {
  int i,j,k;
  for(i=0; i<Na; i++) 
    for(j=0; j<Mb; j++) {
      float t = 0;
      for(k=0; k<Ma; k++) 
        t += A[i*Ma+k]*B[k*Mb+j];
      C[i*Mb+j] = t;
    } 
}

void matr_mul_tr(MATRIX A, MATRIX B, MATRIX C, int Na, int Ma, int Nb, int Mb) {
  int i,j,k;
  for(i=0; i<Na; i+=4) 
    for(k=0; k<Ma; k+=4) {
      for(j=0; j<Mb; j+=4) {
       matr_prod_tr_B(A,B,C,i,j,k,Ma,Mb);
    }
  }
}

MATRIX matr_copy(MATRIX A, MATRIX Acp, int N, int M) {
  int i,j;
  for(i=0; i<N; i++) 
    for(j=0; j<M; j++) 
      Acp[i*M+j] = A[i*M+j];
}

void matr_col_order(MATRIX A, MATRIX Acol, int N, int M) {
  int i,j,B;
  B=4;
  for(i=0; i<N; i+=B) {
    for(j=0; j<M; j+=B) {
       matr_col_order_B(A,Acol,i,j,N,M);  
    }
  }
}

void matr_pivot(MATRIX A, MATRIX Ainv, int N, int M) {
  int i,j,k;
  for(i=0; i<N; i++) {
    int max_j=i;
    for(j=i; j<N; j++) {
      //find_max(Yt,i,j,max_val,j_curr,N);
      if(fabs(A[j*M+i]) > fabs(A[max_j*M+i])) {
        max_j=j;
      }
    }
    if(max_j!=i) {
      swap_row_B(A,Ainv,i,max_j,N);
    }//if
  } 
}


void LU_fact(VECTOR Ap, VECTOR LU, int N, int M) {
  //Ap = P*A 
  int i,j,k,y,x;
  for(k=0; k<N; k++) {
    for(i=k+1; i<N; i++) {
      LU[i*N+k]=Ap[i*N+k]/Ap[k*N+k];
      for(j=k+1; j<N-16; j+=16) {
	LU_Ap_prod_B(Ap,LU,i,j,k,N);
	// Ap[i*N+j]-=LU[i*N+k]*Ap[k*N+j] -> LU_Ap_prod_B;
      }
      while(j<N) {
          //ciclo resto LU_Ap_prod
       	  Ap[i*N+j]-=LU[i*N+k]*Ap[k*N+j]; 
          j++;
      }
    }
    for(j=k; j<N-16; j+=16) {
      LU_Ap_store_B(Ap,LU,k,j,N);
      //LU[k*N+j]=Ap[k*N+j] -> LU_Ap_store_B
    }
    while(j<N) {
      //ciclo resto LU_Ap_prod
      LU[k*N+j]=Ap[k*N+j]; 
      j++;
    }
  }//k
}

void L_inv(VECTOR LU, int N, int M) {
  int i,j,k,x;
  float s;
  x=0;
  for(i=1; i<N; i++) {
    for(j=0; j<=x; j++) {
      if(j==i-1) 
        /* Gli elementi ljj di L della diagonale sotto 
         * la diagonale principale (lii=1) sono pari 
         * ad -ljj in L^-1 */
        LU[i*M+j] = -LU[i*M+j]; 
      else {
        s=0;
        s+=LU[i*M+j]*1.0; //se k==j
        for(k=j+1; k<=x; k++) {
          s+=LU[i*M+k]*LU[k*M+j];
        }
        /* LU[i*M+j]=-s/LUii=1 (asserzione; elemento della diagonale
         * principale di L sempre unitario) */
        LU[i*M+j]=-s; 
      }
    }
    x++;
  }
}//L_inv

void U_inv(VECTOR LU, int N, int M) {
  int i,j,k,x;
  float s;
  x=0;
  for(i=N-1; i>=0; i--) {
    for(j=N-1; j>=N-x-1; j--) {
      s=0;
      if(i+1<N) {
        for(k=i+1; k<=j; k++)
          s+=LU[i*M+k]*LU[k*M+j];
      }
      LU[i*M+j] = (((i==j)?1:0)-s) / LU[i*M+i];
    }
    x++;
  }
}//U_inv

void matr_mulLU(MATRIX LU, MATRIX C, int N) {
  int i,j,k,x;
  x=0;
  for(i=0; i<N; i++) { 
    for(j=0; j<N; j++) {
      float t=0; 
      for(k=j; k<N; k++) {
        if(k>=x) {
          if(k==j) {
            t+=LU[i*N+k]*1.0;
          }
          else { 
            t+=LU[i*N+k]*LU[k*N+j];
           } 
        }
      }
      C[i*N+j]=t;
    }//j
    x++;
  }//i
}

void inversa(MATRIX Xy, MATRIX XyI, MATRIX LU, int n) {
 
  MATRIX XyI_col;			 //utile per col_order di XyI

  matr_I(XyI,n);    			 //XyI=I (XyI=P dopo matr_pivot)
  matr_pivot(Xy,XyI,n,n);		 //pivoting su Xy e XyI
  matr_zero(LU,n,n);			 //LU(ij)=0
  LU_fact(Xy,LU,n,n);    		 //LU factorization (L ed U memorizzate in LU)
  L_inv(LU,n,n);        		 //L^-1 (lower-substitution)
  U_inv(LU,n,n);        		 //U^-1 (backward-substitution)
  matr_mulLU(LU,Xy,n); 			 //U-1*L-1-> Xy (Xy=U-1*L-1*P-1)
  matr_zero(LU,n,n);
  XyI_col = alloc_matrix(n,n);
  matr_col_order(XyI,XyI_col,n,n);       //col_order di XyI
  matr_mul_tr(Xy,XyI_col,LU,n,n,n,n);    //inversa in LU: Xy*P->LU (Xy^-1=U-1*L-1*P)
  dealloc_matrix(XyI_col);
  
}

/*************************************/

/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX Xy, int m, int n) {
  VECTOR beta = get_block(sizeof(float),n);
    
    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
  MATRIX Xycp_new;
  MATRIX Xycp_col;
  MATRIX Xyc;
  MATRIX Xytr;
  MATRIX Xytr_col;
  MATRIX XyI;
  MATRIX XyinvXtr;
  MATRIX LU;
  VECTOR y;
  
  int r=m;
  int c=n;

  printf("> start linreg\n");
  Xycp_new = alloc_matrix(r,c);			//Xycp_new = matrice senza vettore y (mxn)
  y = alloc_matrix(r,1);			//vettore y (mx1)
  preleva_y(Xy,Xycp_new,y,r,c+1);		//preleva y da Xy
  Xytr = alloc_matrix(c,r);			//X^T
  printf("> X^T\n");
  matr_tr(Xycp_new,Xytr,r,c);           	//trasposta di Xycp_new in Xytr 
  LU = alloc_matrix(c,c);
  XyI = alloc_matrix(c,c);
  Xycp_col = alloc_matrix(r,c);			//utile per col_order di Xycp_new
  matr_col_order(Xycp_new,Xycp_col,r,c);	//col_order di Xycp_new
  Xyc = alloc_matrix(c,c);			//Xyc = Xytr * Xycp_col (X^T * X) 
  printf("> X^T * X\n");
  matr_mul_tr(Xytr,Xycp_col,Xyc,c,r,r,c);	//Xyc = Xytr * Xycp_col
  dealloc_matrix(Xycp_new);
  dealloc_matrix(Xycp_col);
  printf("> (X^T * X)^-1\n");
  inversa(Xyc,XyI,LU,c);
  dealloc_matrix(Xyc);
  dealloc_matrix(XyI);				//LU = (X^T * X)^-1
  XyinvXtr = alloc_matrix(c,r);			//XyinvXtr = LU * X^T 
  matr_zero(XyinvXtr,c,r);  
  printf("> (X^T * X)^-1 * X^T \n");
  matr_mul(LU,Xytr,XyinvXtr,c,c,c,r);  		//XyinvXtr = LU * X^T
  dealloc_matrix(LU);
  dealloc_matrix(Xytr);
  dealloc_matrix(Xytr_col);
  printf("> [(X^T * X)^-1 * X^T] * y\n");
  matr_mul(XyinvXtr,y,beta,c,r,r,1);		//beta = XyinvXtr * y 
  printf("> end linreg\n");
  
  return beta;
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_11.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/

void main(int argc, char** argv) {
	int m = 1024;
	int n = 512;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock(); 

/***************************************/
/*chiamata a funzione (linreg o altre)*/
        
	beta = linreg(Xy,m,n);

/*********************************/
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
