/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>
//#include <smmintrin.h>



/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*

int ROW_PADDING = 0, COL_PADDING = 0, MATRIX_HEIGHT = 0, MATRIX_WIDTH = 0;



/*
 NASM FUNCTION
 */

//extern void matrix_transpose_nasm(MATRIX a,MATRIX c,VECTOR params);

/*
 PROTOTYPE FUNCTION
 */
VECTOR matrix_vector_product(MATRIX a, VECTOR b, int am, int abn);
VECTOR matrix_vector_product_cache_oblivious(MATRIX a, VECTOR b, int am, int abn);
void matrix_vector_product_cache_oblivious_rec(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C);
void matrix_vector_product_sse(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C);

float matrix_inverse_lu(const MATRIX c, MATRIX b, int size, int pad);
void matrix_inverse_lu_sse(const MATRIX c, MATRIX b, int size, int pad);
int matrix_inverse_find_pivot_scaled(MATRIX a, VECTOR sm, int x, int m, int pad);
int matrix_inverse_find_pivot_on_cols(MATRIX a, int x, int m, int pad);
void matrix_inverse_swap_cols(MATRIX a, MATRIX id, int dest, int sorg, int m, int pad);
MATRIX matrix_square_inverse(MATRIX mat, int m, int pad);
MATRIX getIdendityMatrix(int m, int pad);

MATRIX matrix_product(MATRIX a, MATRIX b, int am, int abn, int bp);
MATRIX matrix_product_cache_oblivious(MATRIX a, MATRIX b, int am, int abn, int bp);
void matrix_product_cache_oblivious_rec2(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C);
void matrix_product_sse(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C);

MATRIX matrix_transpose(MATRIX a, int m, int n);
MATRIX matrix_transpose_cache_oblivious(MATRIX a, int m, int n);
void matrix_transpose_cache_oblivious_rec(MATRIX a, MATRIX c, int x, int y, int dm, int dn, int m, int n);

MATRIX fromColumnToRowMajor(MATRIX a, int m, int n);
MATRIX fromRowToColumnMajor(MATRIX a, int m, int n);


void setPaddingNumberRC(int m, int n);
int getNecessaryPadding(int length);
void getPaddingNumberRC(int m, int n, int * n_rows, int * n_cols);
void getSizeWithPadding(int m, int n, int * p_m, int * p_n);

void saveMatrix(MATRIX a, VECTOR Y, int m, int n, char * filename);

float distance(VECTOR old_vector, VECTOR new_vector, int n);

/*
 END PROTOTYPE
 */


void* get_block(int size, int elements) {
    return _mm_malloc(elements*size, 16);
}

void free_block(void* p) {
    _mm_free(p);
}

VECTOR alloc_vector(int rows) {
    VECTOR A = (VECTOR) get_block(sizeof (float), rows);
    int i;
    for (i = 0; i < rows; i++) {
        A[i] = 0;
    }
    return A;
}

MATRIX alloc_matrix(int rows, int cols) {
    MATRIX A = (MATRIX) get_block(sizeof (float), rows * cols);
    int i;
    for (i = 0; i < rows * cols; i++) {
        A[i] = 0;
    }
    return A;
}

void dealloc_vector(VECTOR vec) {
    free_block(vec);
}

void dealloc_matrix(MATRIX mat) {
    free_block(mat);
}

float frand() {
    float r = (float) rand();
    return r / RAND_MAX;
}

/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n, VECTOR * Y) {
    int i, j;
    int pm, pn;
    setPaddingNumberRC(m, n);
    int size_m = m + ROW_PADDING;
    int size_n = n + COL_PADDING;
    MATRIX A = alloc_matrix(size_m, size_n);
    VECTOR Y2 = alloc_vector(size_m);
    //printf("Allocata matrice %d,%d\n", size_m, size_n);
    float x, y, e;
    float* beta = calloc(n, sizeof (float));


    for (i = 0; i < n; i++)
        beta[i] = frand();
    e = frand()*0.2;

    for (i = 0; i < m; i++) {
        y = 0;
        for (j = 0; j < n; j++) {
            if (j < n - 1)
                x = frand();
            else
                x = 1.0;
            //pos = i * (n + 1) + j;
            A[(i * (size_n)) + j] = x;
            y += x * beta[j];
        }
        /*for (j = n; j < size_n; j++) {
            A[(i * (size_n)) + j] = 0;
        }*/
        Y2[i] = y; //* (1 + frand() * e - e / 2);
        //printf("Y[%d] = %f in Y[%d]\n", i, (*Y)[i], i);
    }
    /*for (i = m; i < size_m; i++) {
        for (j = 0; j < size_n; j++) {
            A[(i * (size_n)) + j] = 0;
        }
        Y2[i] = 0;
    }*/


    *Y = Y2;
    free(beta);
    MATRIX A2 = fromRowToColumnMajor(A, size_m, size_n);
    dealloc_matrix(A);
    return A2;
}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n, VECTOR * Y) {
    FILE* fp;
    int rows, cols, status;

    fp = fopen(filename, "rb");
    status = fread(&cols, sizeof (int), 1, fp);
    status = fread(&rows, sizeof (int), 1, fp);

    setPaddingNumberRC(rows, cols - 1);
    int size_m = rows + ROW_PADDING;
    int size_n = cols - 1 + COL_PADDING;
    MATRIX Xy = alloc_matrix(size_m, size_n);

//printf("M = %d, N = %d, SIZE_M = %d, SIZE_N = %d\n",rows,cols-1,size_m,size_n);
    VECTOR Y2 = alloc_vector(size_m);
    int i, j;
    for (i = 0; i < rows; i++) {
        //printf("i=%d\n", i);
        for (j = 0; j < cols - 1; j++) {
            status = fread(&Xy[i * (size_n) + j], sizeof (float), 1, fp);

            //printf("Letto %f\n", Xy[i * (size_n) + j]);



        }
        /* for (j = cols - 1; j < size_n; j++) {
             Xy[i * (size_n) + j] = 0;
         }*/
        status = fread(&Y2[i], sizeof (float), 1, fp);
        //printf("Letto y %f in %d\n", (*Y)[i], i);
    }
    /*for (i = rows; i < size_m; i++) {
        for (j = 0; j < size_n; j++) {
            Xy[i * (size_n) + j] = 0;
        }
        Y2[i] = 0;
    }*/

    //status = fread(Xy, sizeof (float), rows*cols, fp);
    fclose(fp);

    *m = rows;
    *n = cols - 1;
    *Y = Y2;
    MATRIX Xy2 = fromRowToColumnMajor(Xy, size_m, size_n);
    dealloc_matrix(Xy);
    return Xy2;
}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n, VECTOR Y) {
    MATRIX Xy2 = fromColumnToRowMajor(Xy, m, n);

/*printf("MATRICE XY\n");
printMatrix(Xy,m,n);
printf("MATRICE XY2\n");
printMatrix(Xy2,m,n);*/

    dealloc_matrix(Xy);

    int status;
    FILE * fp;
    fp = fopen(filename, "wb");
    int size_m, size_n;
//    getSizeWithPadding(m, n, &size_m, &size_n);
size_m = m-ROW_PADDING;
size_n = n-COL_PADDING;

    int i, j;
    size_n++;
    status = fwrite(&size_n, sizeof (int), 1, fp);
    status = fwrite(&size_m, sizeof (int), 1, fp);

	//printf("M = %d, N=%d, SIZE_M = %d, SIZE_N = %d\n",m,n,size_m,size_n);
	
    for (i = 0; i < (size_m); i++) {
        for (j = 0; j < (size_n - 1); j++) {
            status = fwrite(&Xy2[i * (n) + j], sizeof (float), 1, fp);
           // printf("SCRITTO A[%d,%d]=%f\n", i, j, Xy2[i * (n) + j]);
        }

        status = fwrite(&Y[i % m], sizeof (float), 1, fp);
       // printf("SCRITTO Y[%d,%d]=%f\n", i, j, Y[i % m]);
    }
    fclose(fp);

}

float distance(VECTOR old_vector, VECTOR new_vector, int n) {
    int i;
    float s = 0;
    for (i = 0; i < n; i++) {
        s += (new_vector[i] - old_vector[i]) * (new_vector[i] - old_vector[i]);
    }
    return s;
}

VECTOR solve_gaussSeidel(MATRIX a, VECTOR y, int m, int pad) {
    MATRIX aT = matrix_transpose_cache_oblivious(a, m, m);
    //uso aT in modo da accedere gli elementi di una riga per colonne ;
    //dimensioni di aT = nxm
    VECTOR beta = alloc_vector(m);
    VECTOR tmp = alloc_vector(m);
    int MAX_ITERATION = 100;
    int iterator = 0;
    float MIN_DISTANCE = 1.0E-24;
    int i, j;
    float elem_diag, elem_y;
    float sum;
    float val;
    float dist;
    int length = m - pad;
    //printMatrix(aT,m,m);
    // printMatrix(y,m,1);
    do {
        for (i = 0; i < length; i++) {
            tmp[i] = beta[i];
        }
        for (i = 0; i < length; i++) {
            elem_diag = a[(i * m) + i];
            elem_y = y[i];
            sum = elem_y;
            // printf("%d)\n",i);
            // printf("SUM = %f\n\n",elem_y);
            for (j = 0; j < length; j++) {


                if (i != j) {
                    //  printf("\tSUM = %f - (%f * %f)\n", sum, a[(i*m)+j] , tmp[j]);
                    sum -= (a[(i * m) + j] * tmp[j]);
                    //  printf("\tSUM = %f\n",sum);
                }

            }
            // printf("\tSUM = %f / %f\n",sum , elem_diag);
            sum /= /*(elem_y - sum) / */elem_diag;
            // printf("\tBETA[%d] = SUM = %f\n",i,sum);
            beta[i] = sum;
        }


        dist = distance(tmp, beta, m);

        if (dist == MIN_DISTANCE) break;



        iterator++;
    } while (iterator < MAX_ITERATION);

    // printf("DISTANZA: %f\n", dist);
    // printf("ITERAZIONI: %d\n", iterator);

    //  printf("VETTORE BETA:\n");
    // printMatrix(beta, m, 1);
    // printf("\n=================\n");

    dealloc_vector(tmp);
    //   printf("VETTORE BETA:\n");
    // printMatrix(beta, m, 1);
    // printf("\n=================\n");
    dealloc_matrix(aT);
    //    printf("VETTORE BETA:\n");
    //  printMatrix(beta, m, 1);
    //  printf("\n=================\n");
    return beta;

}

/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX X, VECTOR Y, int m, int n) {



    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------

    //linreg32(Xy, beta, m, n); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------
   /* printf("MATRICE X:\n");
    printMatrix(X,m,n);
    printf("\n=================\n");
	printf("VETTORE Y:\n");
	printMatrix(Y,m,1);*/
    // saveMatrix(X,Y,m,n,"matriceX.txt");
    // saveMatrix(Y,Y,m,1,"Y.txt");
    MATRIX xt = matrix_transpose_cache_oblivious(X, m, n);
    /*  printf("MATRICE TRASPOSTA X:\n");
     printMatrix(xt,n,m);
     printf("\n=================\n");*/
    //  saveMatrix(xt,Y,n,m,"matriceXT.txt");
    //saveMatrix(X, Y, m, n, "matrice_X.txt");
    //  saveMatrix(xt, Y, n, m, "matrice_XT.txt");

    MATRIX prod = matrix_product_cache_oblivious(xt, X, n, m, n);
    //saveMatrix(prod,Y,n,n,"matrice_XT_X.txt");
    /* printf("MATRICE PRODOTTO Xt * X:\n");
     printMatrix(prod,n,n);
     printf("\n=================\n");*/
    // saveMatrix(prod,Y,n,n,"matriceProdottoXT_X.txt");
    dealloc_matrix(xt);
    // printMatrix(prod,n,n);

    /*MATRIX inverse = matrix_square_inverse(prod, n, COL_PADDING);
       printf("MATRICE INVERSA (Xt * X):\n");
      printMatrix(inverse/,n,n);
      //saveMatrix(inverse,Y,n,n,"matriceInversa.txt");
      printf("\n=================\n");*/
    //  saveMatrix(inverse,Y,n,n,"matriceInversa.txt");
    //dealloc_matrix(prod); già deallocata da inverse

    MATRIX inverse = alloc_matrix(n, n);
    matrix_inverse_lu_sse(prod, inverse, n, COL_PADDING);
    //saveMatrix(inverse,Y,n,n,"matrice_inv.txt");
   /* printf("MATRICE INVERSA sse(Xt * X):\n");
    printMatrix(inverse,n,n);
    printf("\n=================\n");*/ 

    /*MATRIX inverse2 = alloc_matrix(n, n);
    matrix_inverse_lu(prod, inverse2, n, COL_PADDING);
    saveMatrix(inverse2,Y,n,n,"matrice_inv2.txt");*/
    /*printf("MATRICE INVERSA (Xt * X):\n");
    printMatrix(inverse2,n,n);
    printf("\n=================\n"); */

    xt = matrix_transpose_cache_oblivious(X, m, n);
   /*  printf("MATRICE TRASPOSTA Xt:\n");
    printMatrix(xt,n,m);
    printf("\n=================\n");*/
     
    //4 matrici dopo il prodotto in questo punto
    /* printf("MATRICE INVERSA\n");
     printMatrix(inverse, n, n);
     printf("MATRICE TRASPOSTA\n");
     printMatrix(xt, n, n);*/
    prod = matrix_product_cache_oblivious(inverse, xt, n, n, m);
    //printf("MATRICE PRODTTO (Xt * X)^-1 * Xt:\n");
    //printMatrix(prod, n, m);
    // printf("\n=================\n");
    //   saveMatrix(prod,Y,n,n,"matriceProdottoInversa_XT.txt");
    // printMatrix(prod,n,n);
    dealloc_matrix(xt);
    dealloc_matrix(inverse);

    // printf("VETTORE Y:\n");
    // printMatrix(Y, m, 1);
    // printf("\n=================\n");
   /* printf("MATRICE:\n");
        printMatrix(prod,n,m);
        printf("VETTORE:\n");
        printMatrix(Y,m,1);*/
     
    VECTOR beta = matrix_vector_product_cache_oblivious(prod, Y, n, m);
    //  printMatrix(beta,n,1);
    /*   printf("VETTORE PRODOTTO ((Xt * X)^-1 * Xt) * Y:\n");
      printMatrix(beta,n,1);
      printf("\n=================\n");*/
    //  saveMatrix(beta,Y,n,1,"beta.txt");
    dealloc_matrix(prod);

    /*  printf("MATRICE X:\n");
     printMatrix(X,m,n);
     printf("\n=================\n");*/
    /*printf("VETTORE BETA:\n");
       printMatrix(beta,n,1);*/


    return beta;
}

void print128_num(__m128 var) {
    float_t *val = (float_t*) & var; //can also use uint32_t instead of 16_t
    printf("%f %f %f %f \n", val[0], val[1], val[2], val[3]);
}

VECTOR matrix_vector_product_cache_oblivious(MATRIX a, VECTOR b, int am, int abn) {
    //int m = MATRIX_HEIGHT, n = MATRIX_WIDTH;
    VECTOR c = alloc_vector(am);

    int * params_A = (int *) get_block(sizeof (int), 7);
    int * params_B = (int *) get_block(sizeof (int), 7);
    int * params_C = (int *) get_block(sizeof (int), 1);

    params_A[0] = 0; //start x
    params_A[1] = 0; //start y
    params_A[2] = am; //altezza sottomatrice
    params_A[3] = abn; //larghezza sottomatrice
    params_A[4] = am; //altezza matrice contenitore
    params_A[5] = abn; //larghezza matrice contenitore
    params_A[6] = am; //# righe

    params_B[0] = 0;
    //params_B[1] = 0;
    params_B[2] = abn;
    //params_B[3] = bp;
    params_B[4] = abn;
    //params_B[5] = bp;
    params_B[6] = abn;

    params_C[0] = 0;
    //params_C[1] = 0;

    //printMatrix(a,am,abn);

    matrix_vector_product_cache_oblivious_rec(a, b, c, params_A, params_B, params_C);


    free_block(params_A);
    free_block(params_B);
    free_block(params_C);
    return c;
}

void matrix_vector_product_sse(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C) {

    int UNROLL = 4;
    int VECTORIZATION = 4;
    int p = UNROLL * VECTORIZATION;
    int dma = params_A[2];
    int dna = params_A[3];
    //int dmb = params_B[2];
    int dnb = params_B[3];
    int k, i, j, h, z, v;
    int xa = params_A[0];
    int ya = params_A[1];
    //int xb = params_B[0];
    //int yb = params_B[1];
    int ma = params_A[6];
    //int na = params_A[6];
    //int mb = params_B[6];
    //int nb = params_B[6];

    /*printf("BLOCCO A: dm = %d, dn = %d\n", dma, dna);
    printf("X = %d, Y = %d\n", xa, ya);
    printf("BLOCCO B: dm = %d, dn = %d\n", dmb, dnb);
    printf("X = %d, Y = %d\n", xb, yb);
     */
    // printf("Stampo matrice A:\n");
    //printMatrix(a, ma, na);
    // printf("Stampo matrice B:\n");
    //printMatrix(b, mb, nb);

    int lk = (((dma) / p) * p) + xa;
    int li = dna + ya; //(((dna) / p) * p) + ya;
    //int lj = dnb + yb; //(((dnb) / p) * p) + yb;
    __m128 xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6, xmm7;


    int cx = params_C[0];
    //int cy = params_C[1];


    for (k = xa, z = cx; k < lk; k += (p), z += (p)) {

        xmm4 = _mm_load_ps(c + z);
        xmm5 = _mm_load_ps(c + z + 4);
        xmm6 = _mm_load_ps(c + z + 8);
        xmm7 = _mm_load_ps(c + z + 12);

        for (i = ya; i < li; i += VECTORIZATION) {
            xmm3 = _mm_load_ps(b + i);

            //blocco 1
            xmm2 = _mm_load_ps(a + ((i) * ma) + k);
            //prodotto con shuffle sul primo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b00000000);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);


            xmm2 = _mm_load_ps(a + ((i) * ma) + k + 4);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm5 = _mm_add_ps(xmm2, xmm5);

            xmm2 = _mm_load_ps(a + ((i) * ma) + k + 8);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm6 = _mm_add_ps(xmm2, xmm6);

            xmm2 = _mm_load_ps(a + ((i) * ma) + k + 12);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm7 = _mm_add_ps(xmm2, xmm7);


            //blocco 2
            xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k);
            //prodotto con shuffle sul secondo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b01010101);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);


            xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k + 4);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm5 = _mm_add_ps(xmm2, xmm5);

            xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k + 8);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm6 = _mm_add_ps(xmm2, xmm6);

            xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k + 12);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm7 = _mm_add_ps(xmm2, xmm7);


            //blocco 3
            xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k);
            //prodotto con shuffle sul secondo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b10101010);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);


            xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k + 4);

            xmm2 = _mm_mul_ps(xmm0, xmm2);

            xmm5 = _mm_add_ps(xmm2, xmm5);

            xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k + 8);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm6 = _mm_add_ps(xmm2, xmm6);

            xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k + 12);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm7 = _mm_add_ps(xmm2, xmm7);

            //blocco 4
            xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k);
            //prodotto con shuffle sul secondo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b11111111);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);


            xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k + 4);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm5 = _mm_add_ps(xmm2, xmm5);

            xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k + 8);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm6 = _mm_add_ps(xmm2, xmm6);

            xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k + 12);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm7 = _mm_add_ps(xmm2, xmm7);

        }
        _mm_store_ps(c + z, xmm4);
        _mm_store_ps(c + z + 4, xmm5);
        _mm_store_ps(c + z + 8, xmm6);
        _mm_store_ps(c + z + 12, xmm7);

    }


    for (; k < dma + xa; k += (VECTORIZATION), z += (VECTORIZATION)) {

        xmm4 = _mm_load_ps(c + z);
        for (i = ya; i < li; i += VECTORIZATION) {
            xmm3 = _mm_load_ps(b + i);

            //blocco 1
            xmm2 = _mm_load_ps(a + ((i) * ma) + k);
            //prodotto con shuffle sul primo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b00000000);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);

            //blocco 2
            xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k);
            //prodotto con shuffle sul secondo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b01010101);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);

            //blocco 3
            xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k);
            //prodotto con shuffle sul secondo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b10101010);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);

            //blocco 4
            xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k);
            //prodotto con shuffle sul secondo elemento 
            xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b11111111);

            xmm2 = _mm_mul_ps(xmm0, xmm2);
            xmm4 = _mm_add_ps(xmm2, xmm4);

        }
        _mm_store_ps(c + z, xmm4);
    }


    return;
}

void matrix_vector_product_cache_oblivious_rec(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C) {

    int BLOCK = 32;

    if ((params_A[3] <= BLOCK) || (params_A[2] <= BLOCK) /*|| (params_B[2] <= BLOCK) || (params_B[3] <= BLOCK)*/) {
        matrix_vector_product_sse(a, b, c, params_A, params_B, params_C);
        return;
    }

    //delimita il riquadro delle due matrici

    int start_x_a = params_A[0];
    int start_y_a = params_A[1];
    int end_x_a = params_A[2] + start_x_a;
    int end_y_a = params_A[3] + start_y_a;
    int start_x_b = params_B[0];
    //int start_y_b = params_B[1];
    int end_x_b = params_B[2] + start_x_b;
    //int end_y_b = params_B[3] + start_y_b;


    int start_x_c = params_C[0];
    //int start_y_c = params_C[1];
    //divido in 4 parti A e B in modo che siano orizzontalmente uguali dato che A è trasposta

    int length_x_a = end_x_a - start_x_a;
    int length_y_a = end_y_a - start_y_a;
    int length_x_b = end_x_b - start_x_b;
    //int length_y_b = end_y_b - start_y_b;

    int mid_yaxb = length_x_a / 2; //valori relativi
    int xmid_sup_a = length_x_a / 2;
    //int ymid_sup_b = length_y_b / 2;

    int padyx = getNecessaryPadding(mid_yaxb);
    int padx = getNecessaryPadding(xmid_sup_a);

    xmid_sup_a += padx;
    mid_yaxb += padyx;
    //padx = getNecessaryPadding(ymid_sup_b);
    //ymid_sup_b += padx;

    int * pa1 = (int *) get_block(sizeof (int), 7);
    int * pa2 = (int *) get_block(sizeof (int), 7);

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore
    pa1[6] = params_A[6]; //righe matrice originale


    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    //pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    //pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    //pa2[5] = length_y_b; // lunghezza della matrice contenitore
    pa2[6] = params_B[6]; //righe matrice originale

    int * pa3 = (int *) get_block(sizeof (int), 1);

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    //pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*printf("AxE\n");
    printf("\tXA = %d\n", pa1[0]);
    printf("\tYA = %d\n", pa1[1]);
    printf("\tMA = %d\n", pa1[2]);
    printf("\tNA = %d\n\n", pa1[3]);
    printf("\tXB = %d\n", pa2[0]);
    printf("\tYB = %d\n", pa2[1]);
    printf("\tMB = %d\n", pa2[2]);
    printf("\tNB = %d\n\n", pa2[3]);
    printf("\tCX = %d\n", pa3[0]);
    printf("\tCY = %d\n", pa3[1]);*/

    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante A


    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    //pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    //pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    // pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    // pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*printf("BxH\n");
    printf("\tXA = %d\n", pa1[0]);
    printf("\tYA = %d\n", pa1[1]);
    printf("\tMA = %d\n", pa1[2]);
    printf("\tNA = %d\n\n", pa1[3]);
    printf("\tXB = %d\n", pa2[0]);
    printf("\tYB = %d\n", pa2[1]);
    printf("\tMB = %d\n", pa2[2]);
    printf("\tNB = %d\n\n", pa2[3]);
    printf("\tCX = %d\n", pa3[0]);
    printf("\tCY = %d\n", pa3[1]);*/
    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante B


    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    //pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    //pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    // pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    //pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*  printf("DxH\n");
      printf("\tXA = %d\n", pa1[0]);
      printf("\tYA = %d\n", pa1[1]);
      printf("\tMA = %d\n", pa1[2]);
      printf("\tNA = %d\n\n", pa1[3]);
      printf("\tXB = %d\n", pa2[0]);
      printf("\tYB = %d\n", pa2[1]);
      printf("\tMB = %d\n", pa2[2]);
      printf("\tNB = %d\n\n", pa2[3]);
      printf("\tCX = %d\n", pa3[0]);
      printf("\tCY = %d\n", pa3[1]);*/

    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante D

    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    //pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    //pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    //pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    //pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /* printf("CxE\n");
     printf("\tXA = %d\n", pa1[0]);
     printf("\tYA = %d\n", pa1[1]);
     printf("\tMA = %d\n", pa1[2]);
     printf("\tNA = %d\n\n", pa1[3]);
     printf("\tXB = %d\n", pa2[0]);
     printf("\tYB = %d\n", pa2[1]);
     printf("\tMB = %d\n", pa2[2]);
     printf("\tNB = %d\n\n", pa2[3]);
     printf("\tCX = %d\n", pa3[0]);
     printf("\tCY = %d\n", pa3[1]);*/
    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante C

    free_block(pa1);
    free_block(pa2);
    free_block(pa3);
    return;
}

MATRIX matrix_product_cache_oblivious(MATRIX a, MATRIX b, int am, int abn, int bp) {
    //int m = MATRIX_HEIGHT, n = MATRIX_WIDTH;
    MATRIX c = alloc_matrix(am, bp);

    int * params_A = (int *) get_block(sizeof (int), 7);
    int * params_B = (int *) get_block(sizeof (int), 7);
    int * params_C = (int *) get_block(sizeof (int), 2);

    params_A[0] = 0; //start x
    params_A[1] = 0; //start y
    params_A[2] = am; //altezza sottomatrice
    params_A[3] = abn; //larghezza sottomatrice
    params_A[4] = am; //altezza matrice contenitore
    params_A[5] = abn; //larghezza matrice contenitore
    params_A[6] = am; //# righe

    params_B[0] = 0;
    params_B[1] = 0;
    params_B[2] = abn;
    params_B[3] = bp;
    params_B[4] = abn;
    params_B[5] = bp;
    params_B[6] = abn;

    params_C[0] = 0;
    params_C[1] = 0;

    matrix_product_cache_oblivious_rec2(a, b, c, params_A, params_B, params_C);


    free_block(params_A);
    free_block(params_B);
    free_block(params_C);
    return c;
}

void matrix_product_sse(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C) {

    int UNROLL = 4;
    int VECTORIZATION = 4;
    int p = UNROLL * VECTORIZATION;
    int dma = params_A[2];
    int dna = params_A[3];
    //int dmb = params_B[2];
    int dnb = params_B[3];
    int k, i, j, h, z, v;
    int xa = params_A[0];
    int ya = params_A[1];
    //int xb = params_B[0];
    int yb = params_B[1];
    int ma = params_A[6];
    //int na = params_A[6];
    int mb = params_B[6];
    //int nb = params_B[6];

    /*printf("BLOCCO A: dm = %d, dn = %d\n", dma, dna);
    printf("X = %d, Y = %d\n", xa, ya);
    printf("BLOCCO B: dm = %d, dn = %d\n", dmb, dnb);
    printf("X = %d, Y = %d\n", xb, yb);
     */
    // printf("Stampo matrice A:\n");
    //printMatrix(a, ma, na);
    // printf("Stampo matrice B:\n");
    //printMatrix(b, mb, nb);

    int lk = (((dma) / p) * p) + xa;
    int li = dna + ya; //(((dna) / p) * p) + ya;
    int lj = dnb + yb; //(((dnb) / p) * p) + yb;
    __m128 xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6, xmm7;


    int cx = params_C[0];
    int cy = params_C[1];


    for (k = xa, z = cx; k < lk; k += (p), z += (p)) {

        for (j = yb, v = cy; j < lj; j++, v++) {

            xmm4 = _mm_load_ps(c + ((v) * ma) + z);
            xmm5 = _mm_load_ps(c + ((v) * ma) + z + 4);
            xmm6 = _mm_load_ps(c + ((v) * ma) + z + 8);
            xmm7 = _mm_load_ps(c + ((v) * ma) + z + 12);




            for (i = ya; i < li; i += VECTORIZATION) {
                xmm3 = _mm_load_ps(b + (j * mb) + i);

                //blocco 1
                xmm2 = _mm_load_ps(a + ((i) * ma) + k);
                //prodotto con shuffle sul primo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b00000000);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);


                xmm2 = _mm_load_ps(a + ((i) * ma) + k + 4);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm5 = _mm_add_ps(xmm2, xmm5);

                xmm2 = _mm_load_ps(a + ((i) * ma) + k + 8);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm6 = _mm_add_ps(xmm2, xmm6);

                xmm2 = _mm_load_ps(a + ((i) * ma) + k + 12);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm7 = _mm_add_ps(xmm2, xmm7);


                //blocco 2
                xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k);
                //prodotto con shuffle sul secondo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b01010101);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);


                xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k + 4);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm5 = _mm_add_ps(xmm2, xmm5);

                xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k + 8);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm6 = _mm_add_ps(xmm2, xmm6);

                xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k + 12);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm7 = _mm_add_ps(xmm2, xmm7);


                //blocco 3
                xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k);
                //prodotto con shuffle sul secondo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b10101010);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);


                xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k + 4);

                xmm2 = _mm_mul_ps(xmm0, xmm2);

                xmm5 = _mm_add_ps(xmm2, xmm5);

                xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k + 8);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm6 = _mm_add_ps(xmm2, xmm6);

                xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k + 12);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm7 = _mm_add_ps(xmm2, xmm7);

                //blocco 4
                xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k);
                //prodotto con shuffle sul secondo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b11111111);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);


                xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k + 4);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm5 = _mm_add_ps(xmm2, xmm5);

                xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k + 8);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm6 = _mm_add_ps(xmm2, xmm6);

                xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k + 12);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm7 = _mm_add_ps(xmm2, xmm7);

            }
            _mm_store_ps(c + ((v) * ma) + z, xmm4);
            _mm_store_ps(c + ((v) * ma) + z + 4, xmm5);
            _mm_store_ps(c + ((v) * ma) + z + 8, xmm6);
            _mm_store_ps(c + ((v) * ma) + z + 12, xmm7);
        }


    }


    for (; k < dma + xa; k += (VECTORIZATION), z += (VECTORIZATION)) {

        for (j = yb, v = cy; j < lj; j++, v++) {

            xmm4 = _mm_load_ps(c + ((v) * ma) + z);



            for (i = ya; i < li; i += VECTORIZATION) {
                xmm3 = _mm_load_ps(b + (j * mb) + i);

                //blocco 1
                xmm2 = _mm_load_ps(a + ((i) * ma) + k);
                //prodotto con shuffle sul primo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b00000000);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);

                //blocco 2
                xmm2 = _mm_load_ps(a + ((i + 1) * ma) + k);
                //prodotto con shuffle sul secondo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b01010101);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);

                //blocco 3
                xmm2 = _mm_load_ps(a + ((i + 2) * ma) + k);
                //prodotto con shuffle sul secondo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b10101010);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);

                //blocco 4
                xmm2 = _mm_load_ps(a + ((i + 3) * ma) + k);
                //prodotto con shuffle sul secondo elemento 
                xmm0 = _mm_shuffle_ps(xmm3, xmm3, 0b11111111);

                xmm2 = _mm_mul_ps(xmm0, xmm2);
                xmm4 = _mm_add_ps(xmm2, xmm4);

            }
            _mm_store_ps(c + ((v) * ma) + z, xmm4);

        }


    }


    return;
}

void matrix_product_cache_oblivious_rec2(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C) {

    int BLOCK = 32;

    if ((params_A[3] <= BLOCK) || (params_A[2] <= BLOCK) || /*(params_B[2] <= BLOCK) || */(params_B[3] <= BLOCK)) {
        matrix_product_sse(a, b, c, params_A, params_B, params_C);
        return;
    }

    //delimita il riquadro delle due matrici

    int start_x_a = params_A[0];
    int start_y_a = params_A[1];
    int end_x_a = params_A[2] + start_x_a;
    int end_y_a = params_A[3] + start_y_a;
    int start_x_b = params_B[0];
    int start_y_b = params_B[1];
    int end_x_b = params_B[2] + start_x_b;
    int end_y_b = params_B[3] + start_y_b;


    int start_x_c = params_C[0];
    int start_y_c = params_C[1];
    //divido in 4 parti A e B in modo che siano orizzontalmente uguali dato che A è trasposta

    int length_x_a = end_x_a - start_x_a;
    int length_y_a = end_y_a - start_y_a;
    int length_x_b = end_x_b - start_x_b;
    int length_y_b = end_y_b - start_y_b;

    int mid_yaxb = length_x_a / 2; //valori relativi
    int xmid_sup_a = length_x_a / 2;
    int ymid_sup_b = length_y_b / 2;

    int padyx = getNecessaryPadding(mid_yaxb);
    int padx = getNecessaryPadding(xmid_sup_a);

    xmid_sup_a += padx;
    mid_yaxb += padyx;
    padx = getNecessaryPadding(ymid_sup_b);
    ymid_sup_b += padx;

    int * pa1 = (int *) get_block(sizeof (int), 7);
    int * pa2 = (int *) get_block(sizeof (int), 7);

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore
    pa1[6] = params_A[6]; //righe matrice originale


    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore
    pa2[6] = params_B[6]; //righe matrice originale

    int * pa3 = (int *) get_block(sizeof (int), 2);

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*printf("AxE\n");
    printf("\tXA = %d\n", pa1[0]);
    printf("\tYA = %d\n", pa1[1]);
    printf("\tMA = %d\n", pa1[2]);
    printf("\tNA = %d\n\n", pa1[3]);
    printf("\tXB = %d\n", pa2[0]);
    printf("\tYB = %d\n", pa2[1]);
    printf("\tMB = %d\n", pa2[2]);
    printf("\tNB = %d\n\n", pa2[3]);
    printf("\tCX = %d\n", pa3[0]);
    printf("\tCY = %d\n", pa3[1]);*/

    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante A x E


    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*printf("BxG\n");
    printf("\tXA = %d\n", pa1[0]);
    printf("\tYA = %d\n", pa1[1]);
    printf("\tMA = %d\n", pa1[2]);
    printf("\tNA = %d\n\n", pa1[3]);
    printf("\tXB = %d\n", pa2[0]);
    printf("\tYB = %d\n", pa2[1]);
    printf("\tMB = %d\n", pa2[2]);
    printf("\tNB = %d\n\n", pa2[3]);
    printf("\tCX = %d\n", pa3[0]);
    printf("\tCY = %d\n", pa3[1]);*/
    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Bx G

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /* printf("AxF\n");
     printf("\tXA = %d\n", pa1[0]);
     printf("\tYA = %d\n", pa1[1]);
     printf("\tMA = %d\n", pa1[2]);
     printf("\tNA = %d\n\n", pa1[3]);
     printf("\tXB = %d\n", pa2[0]);
     printf("\tYB = %d\n", pa2[1]);
     printf("\tMB = %d\n", pa2[2]);
     printf("\tNB = %d\n\n", pa2[3]);
     printf("\tCX = %d\n", pa3[0]);
     printf("\tCY = %d\n", pa3[1]);*/
    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Ax F

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*printf("BxH\n");
    printf("\tXA = %d\n", pa1[0]);
    printf("\tYA = %d\n", pa1[1]);
    printf("\tMA = %d\n", pa1[2]);
    printf("\tNA = %d\n\n", pa1[3]);
    printf("\tXB = %d\n", pa2[0]);
    printf("\tYB = %d\n", pa2[1]);
    printf("\tMB = %d\n", pa2[2]);
    printf("\tNB = %d\n\n", pa2[3]);
    printf("\tCX = %d\n", pa3[0]);
    printf("\tCY = %d\n", pa3[1]);*/
    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Bx H


    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*  printf("DxH\n");
      printf("\tXA = %d\n", pa1[0]);
      printf("\tYA = %d\n", pa1[1]);
      printf("\tMA = %d\n", pa1[2]);
      printf("\tNA = %d\n\n", pa1[3]);
      printf("\tXB = %d\n", pa2[0]);
      printf("\tYB = %d\n", pa2[1]);
      printf("\tMB = %d\n", pa2[2]);
      printf("\tNB = %d\n\n", pa2[3]);
      printf("\tCX = %d\n", pa3[0]);
      printf("\tCY = %d\n", pa3[1]);*/

    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Dx H

    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /* printf("CxF\n");
     printf("\tXA = %d\n", pa1[0]);
     printf("\tYA = %d\n", pa1[1]);
     printf("\tMA = %d\n", pa1[2]);
     printf("\tNA = %d\n\n", pa1[3]);
     printf("\tXB = %d\n", pa2[0]);
     printf("\tYB = %d\n", pa2[1]);
     printf("\tMB = %d\n", pa2[2]);
     printf("\tNB = %d\n\n", pa2[3]);
     printf("\tCX = %d\n", pa3[0]);
     printf("\tCY = %d\n", pa3[1]);*/

    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Cx F


    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /*  printf("DxG\n");
      printf("\tXA = %d\n", pa1[0]);
      printf("\tYA = %d\n", pa1[1]);
      printf("\tMA = %d\n", pa1[2]);
      printf("\tNA = %d\n\n", pa1[3]);
      printf("\tXB = %d\n", pa2[0]);
      printf("\tYB = %d\n", pa2[1]);
      printf("\tMB = %d\n", pa2[2]);
      printf("\tNB = %d\n\n", pa2[3]);
      printf("\tCX = %d\n", pa3[0]);
      printf("\tCY = %d\n", pa3[1]);*/
    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Dx G

    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    /* printf("CxE\n");
     printf("\tXA = %d\n", pa1[0]);
     printf("\tYA = %d\n", pa1[1]);
     printf("\tMA = %d\n", pa1[2]);
     printf("\tNA = %d\n\n", pa1[3]);
     printf("\tXB = %d\n", pa2[0]);
     printf("\tYB = %d\n", pa2[1]);
     printf("\tMB = %d\n", pa2[2]);
     printf("\tNB = %d\n\n", pa2[3]);
     printf("\tCX = %d\n", pa3[0]);
     printf("\tCY = %d\n", pa3[1]);*/
    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Cx E

    free_block(pa1);
    free_block(pa2);
    free_block(pa3);
    return;
}

MATRIX matrix_transpose_cache_oblivious(MATRIX a, int m, int n) {
    //int m = MATRIX_HEIGHT, n = MATRIX_WIDTH;
    MATRIX c = alloc_matrix(n, m);
    matrix_transpose_cache_oblivious_rec(a, c, 0, 0, m, n, m, n);
    return c;
}

void matrix_transpose_cache_oblivious_rec(MATRIX a, MATRIX c, int x, int y, int dm, int dn, int m, int n) {
    int BLOCK = 32;
    int UNROLL = 4;
    int VECTORIZATION = 1;

    if ((dm <= BLOCK) && (dn <= BLOCK)) {
        int h, k, u;
        //printf("BLOCCO: dm = %d, dn = %d\n", dm, dn);
        // printf("X = %d, Y = %d\n", x, y);
        int p = UNROLL*VECTORIZATION;
        int v;
        int lx = (((dm) / p) * p) + x;
        int ly = (((dn) / p) * p) + y;

        VECTOR params = alloc_vector(6);
        params[0] = x;
        params[1] = y;
        params[2] = lx;
        params[3] = ly;
        params[4] = m;
        params[5] = n;


        /*
        matrix_transpose_nasm(a,c,params);
        dealloc_vector(params);
        return;*/
        __m128 xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6, xmm7;
        for (k = x; k < lx; k += p) {
            for (h = y; h < ly; h += p) {
                //caricare in 4 registri
                //effettuare unpck 2 volte sui 4 registri
                //copiare infine i risultati

                //### LOAD
                xmm0 = _mm_load_ps(a + k + (((m) * h)));
                xmm1 = _mm_load_ps(a + k + (((m)*(h + 1))));
                xmm2 = _mm_load_ps(a + k + (((m)*(h + 2))));
                xmm3 = _mm_load_ps(a + k + (((m)*(h + 3))));

                xmm4 = _mm_load_ps(a + k + (((m) * h)));
                xmm5 = _mm_load_ps(a + k + (((m)*(h + 1))));
                xmm6 = _mm_load_ps(a + k + (((m)*(h + 2))));
                xmm7 = _mm_load_ps(a + k + (((m)*(h + 3))));

                //### END LOAD

                // xmm4 = _mm_blend_ps(xmm4, xmm0, 0b1111); //1111  sostituire con movaps               
                xmm4 = _mm_movelh_ps(xmm4, xmm1);
                // xmm5 = _mm_blend_ps(xmm5, xmm1, 0b1111); //1111  sostituire con movaps    
                xmm5 = _mm_movehl_ps(xmm5, xmm0);
                // xmm6 = _mm_blend_ps(xmm6, xmm2, 0b1111); //1111  sostituire con movaps          
                xmm6 = _mm_movelh_ps(xmm6, xmm3);
                // xmm7 = _mm_blend_ps(xmm7, xmm3, 0b1111); //1111  sostituire con movaps    
                xmm7 = _mm_movehl_ps(xmm7, xmm2);


                xmm0 = _mm_shuffle_ps(xmm4, xmm6, 0b10001000);
                xmm1 = _mm_shuffle_ps(xmm4, xmm6, 0b11011101);
                xmm2 = _mm_shuffle_ps(xmm5, xmm7, 0b10001000);
                xmm3 = _mm_shuffle_ps(xmm5, xmm7, 0b11011101);


                //### STORE
                _mm_store_ps(c + (k * n) + h, xmm0);
                _mm_store_ps(c + ((k + 1) * n) + h, xmm1);
                _mm_store_ps(c + ((k + 2) * n) + h, xmm2);
                _mm_store_ps(c + ((k + 3) * n) + h, xmm3);
                //### END STORE      

            }
        }
        //printMatrix(c,n,m); 
        //printf("FINE BLOCCO: dm = %d, dn = %d\n", dm, dn);
        //printf("X = %d, Y = %d\n", x, y);
        return;
    }

    if (dm >= dn) {
        int xmid = dm / 2;
        int pad = getNecessaryPadding(xmid);
        xmid += pad;
        matrix_transpose_cache_oblivious_rec(a, c, x, y, xmid, dn, m, n);
        matrix_transpose_cache_oblivious_rec(a, c, x + xmid, y, dm - xmid, dn, m, n);
        return;
    } else {
        int ymid = dn / 2;
        int pad = getNecessaryPadding(ymid);
        ymid += pad;
        matrix_transpose_cache_oblivious_rec(a, c, x, y, dm, ymid, m, n);
        matrix_transpose_cache_oblivious_rec(a, c, x, y + ymid, dm, dn - ymid, m, n);
        return;
    }
}

MATRIX matrix_transpose(MATRIX a, int m, int n) {
    int i, j;
    MATRIX c = alloc_matrix(n, m);
    //printf("MATRICE TRASPOSTA DIM: %d, %d\n",MATRIX_WIDTH,MATRIX_HEIGHT);
    int k = 0, t = 0;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {

            int pos1 = (j + (i * n));
            int pos2 = (j * m) + i;
            //printf("i=%d\tj=%d\tk=%d\t\n", i, j, k);
            //printf("Elem: %f da pos2 = %d a pos1 = %d\n", a[pos2], pos2, pos1);
            c[pos1] = a[pos2];
        }

    }
    return c;
}

VECTOR matrix_vector_product(MATRIX a, VECTOR b, int am, int abn) {
    // A = mxn
    // B = nxp
    // C = mxp
    VECTOR c = alloc_vector(am);

    printf("START NORM PRODUCT\n");

    int i, j, k;
    float t;

    for (k = 0; k < am; k++) {
        for (j = 0; j < abn; j++) {



            c[k] += a[(j * am) + k] * b[j];


        }
    }



    return c;

}

MATRIX matrix_product(MATRIX a, MATRIX b, int am, int abn, int bp) {
    // A = mxn
    // B = nxp
    // C = mxp
    MATRIX c = alloc_matrix(am, bp);

    printf("START NORM PRODUCT\n");

    int i, j, k;
    float t;

    for (k = 0; k < am; k++) {
        for (j = 0; j < bp; j++) {
            t = 0;
            for (i = 0; i < abn; i++) {

                t += a[(i * am) + k] * b[(j * abn) + i];

            }
            c[(j * bp) + k] = t;
        }
    }

    /*for (k = 0; k < am; k++) {
        //printf("%d/%d\n", k, am);
        for (j = 0; j < bp; j++) {

            t = 0;
            for (i = 0; i < abn; i++) {

                t += a[(k * abn) + i] * b[(i * bp) + j];

            }
            c[(k * bp) + j] = t;
        }
    }*/


    return c;

}

int matrix_inverse_find_pivot_on_rows(MATRIX a, int x, int m, int pad) {
    int pos = x;
    float max = fabs(a[(x * m) + x]);
    int i;
    float cur;
    int length = m - pad;

    for (i = x + 1; i < length; i++) {
        cur = fabs(a[(x * m) + i]);


        if (cur > max) {
            pos = i;
            max = cur;
        }
    }

    return pos;

}

int matrix_inverse_find_pivot_on_cols(MATRIX a, int x, int m, int pad) {
    int pos = x;
    float max = fabs(a[(x * m) + x]);
    int i;
    float cur;
    int length = m - pad;

    for (i = x + 1; i < length; i++) {
        cur = fabs(a[(i * m) + x]);


        if (cur > max) {
            pos = i;
            max = cur;
        }
    }

    return pos;

}

void matrix_inverse_scaling(MATRIX a, MATRIX id, int x, int m, int pad) {
    float max = fabs(a[(x * m) + x]);
    int i, k;
    float cur;
    int length = m - pad;

    for (k = x; k < length; k++) {

        for (i = k; i < length; i++) {
            cur = fabs(a[(k * m) + i]);

            if (/*(max == 0 && cur != 0) || (*/cur > max/* && cur != 0)*/) {
                max = cur;
            }
        }
        for (i = k; i < length; i++) {
            a[(k * m) + i] = a[(k * m) + i] / max;
            id[(k * m) + i] = id[(k * m) + i] / max;
        }



    }

}

int matrix_inverse_find_pivot_scaled(MATRIX a, VECTOR sm, int x, int m, int pad) {
    int pos = x;
    float max = 0;

    int i, j;
    float cur;
    int length = m - pad;

    for (i = x; i < length; i++) {

        cur = fabs(a[(i * m) + x]) / sm[i];

        if (cur > max) {
            pos = i;
            max = cur;
        }
    }




    return pos;

}

void matrix_inverse_swap_cols_scale(MATRIX a, MATRIX id, VECTOR scalev, int dest, int sorg, int m, int pad) {
    int i;
    float tmp;
    int pos_sorg, pos_dest;
    int length = m - pad;

    tmp = scalev[dest];
    scalev[dest] = scalev[sorg];
    scalev[sorg] = tmp;

    for (i = 0; i < length; i++) {
        pos_sorg = (sorg * m) + i;
        pos_dest = (dest * m) + i;
        //scorro dalla riga corrente (dest sarebbe l'indice sulla diagonale)
        tmp = a[pos_dest];
        a[pos_dest] = a[pos_sorg];
        a[pos_sorg] = tmp;

        tmp = id[pos_dest];
        id[pos_dest] = id[pos_sorg];
        id[pos_sorg] = tmp;


    }


}

void matrix_inverse_swap_rows(MATRIX a, MATRIX id, int dest, int sorg, int m, int pad) {
    int i;
    float tmp;
    int pos_sorg, pos_dest;
    int length = m - pad;
    for (i = 0; i < length; i++) {
        pos_sorg = (i * m) + sorg;
        pos_dest = (i * m) + dest;
        //scorro dalla riga corrente (dest sarebbe l'indice sulla diagonale)
        tmp = a[pos_dest];
        a[pos_dest] = a[pos_sorg];
        a[pos_sorg] = tmp;

        tmp = id[pos_dest];
        id[pos_dest] = id[pos_sorg];
        id[pos_sorg] = tmp;


    }


}

void matrix_inverse_swap_cols(MATRIX a, MATRIX id, int dest, int sorg, int m, int pad) {
    int i;
    float tmp;
    int pos_sorg, pos_dest;
    int length = m - pad;
    for (i = 0; i < length; i++) {
        pos_sorg = (sorg * m) + i;
        pos_dest = (dest * m) + i;
        //scorro dalla riga corrente (dest sarebbe l'indice sulla diagonale)
        tmp = a[pos_dest];
        a[pos_dest] = a[pos_sorg];
        a[pos_sorg] = tmp;

        tmp = id[pos_dest];
        id[pos_dest] = id[pos_sorg];
        id[pos_sorg] = tmp;


    }


}

void calculateScaleFactors(MATRIX mat, int m, int pad, VECTOR scalev) {
    int i, j;
    int length = m - pad;
    float max_col;
    float cur;

    for (i = 0; i < length; i++) {
        max_col = 0;
        for (j = 0; j < length; j++) {
            cur = fabs(mat[(i * m) + j]);
            if (cur > max_col) {
                max_col = cur;
            }
        }
        scalev[i] = max_col;


    }
}

MATRIX getIdendityMatrix(int m, int pad) {
    MATRIX a = alloc_matrix(m, m);
    int i, j;
    int length = m - pad;
    for (i = 0; i < (length); i++) {
        for (j = 0; j < length; j++) {
            a[i * (m) + i] = 1;
        }
    }
    return a;
}

void normalizeMatrix(MATRIX a, MATRIX id, int m, int pad) {

    float max = 0;

    int i, j;
    float cur;
    int length = m - pad;

    for (i = 0; i < length; i++) {
        for (j = 0; j < length; j++) {

            cur = fabs(a[(i * m) + j]);

            if (cur > max) {
                max = cur;
            }
        }
        for (j = 0; j < length; j++) {

            a[(i * m) + j] /= max;
            id[(i * m) + j] /= max;
        }

    }

}

//traspone la matrice originale

MATRIX matrix_square_inverse(MATRIX mat, int m, int pad) {

    // printf("MATRICE DA INVERTIRE:\n");
    //  printMatrix(mat, m, m);

    // trasposta della matrice a
    MATRIX a = matrix_transpose_cache_oblivious(mat, m, m);
    dealloc_matrix(mat);
    // printf("\n\nMATRICE TRASPOSTA DA INVERTIRE\n");
    // printMatrix(a, m, m);



    MATRIX id = getIdendityMatrix(m, pad);
    // normalizeMatrix(a,id, m, pad);

    /*printf("MATRICE IDENTITA'\n");
    printMatrix(id, m, m);*/
    int max_length = m - pad;
    int i, j, k, pos_pivot;
    float pivot, elem_col;
    int pos, pos2;
    VECTOR scalev = alloc_vector(max_length);
    calculateScaleFactors(a, m, pad, scalev);
    /*printf("VETTORE DI SCALATURA:\n");
    printMatrix(scalev,m,1);*/

    for (i = 0; i < max_length; i++) {
        //avanzo sulla diagonale principale e cerco il pivot parziale
        // printf("AVANZO SULLA DIAGONALE: %d, %d\n", i, i);

        pos_pivot = matrix_inverse_find_pivot_scaled(a, scalev, i, m, pad);
        //pos_pivot = matrix_inverse_find_pivot_on_cols(a, i, m, pad);

        //   printf("IL NUOVO PIVOT SI TROVA IN POS: %d\n", pos_pivot);

        if (pos_pivot != i) {
            //il pivot si trova su un'altra colonna, inverto con la corrente.
            //    printf("INVERTO LA RIGA %d con %d\n", i, pos_pivot);
            matrix_inverse_swap_cols_scale(a, id, scalev, i, pos_pivot, m, pad);
            // matrix_inverse_swap_cols(a, id, i, pos_pivot, m, pad);            
            /*   printf("MATRICE CORRENTE:\n");
               printMatrix(a, m, m);
               printMatrix(id, m, m);*/

        }

        //il pivot ora si trova in i
        pivot = a[(i * m) + i];

        //pos_pivot = matrix_inverse_find_pivot_on_rows(a, i, m, pad);

        //   printf("IL NUOVO PIVOT SI TROVA IN POS: %d\n", pos_pivot);

        /* if (pos_pivot != i) {
             //il pivot si trova su un'altra colonna, inverto con la corrente.
             //    printf("INVERTO LA RIGA %d con %d\n", i, pos_pivot);
            // matrix_inverse_swap_cols_scale(a, id, scalev, i, pos_pivot, m, pad);
              matrix_inverse_swap_cols(a, id, i, pos_pivot, m, pad);            
             /*   printf("MATRICE CORRENTE:\n");
                printMatrix(a, m, m);
                printMatrix(id, m, m);

         }*/

        // printf("PIVOT = %f\n", pivot);
        //semplifico la colonna iesima dividendo per il pivot ogni riga
        // printf("SEMPLIFICO LA COLONNA %d\n", i);
        /*if(pivot == 0){
        printf("MATRICE CORRENTE:\n");
       printMatrix(a, m, m);
       printMatrix(id, m, m);
      //    printf("#######################TROVATO UN PIVOT ZERO!!!!#######################\n");
          return ;
      }*/

        for (j = 0; j < max_length; j++) {
            pos = (i * m) + j;
            a[pos] = a[pos] / pivot;
            id[pos] = id[pos] / pivot;

        }

        // printf("MATRICE CORRENTE:\n");
        //  printMatrix(a, m, m);
        //   printMatrix(id, m, m);

        ///  printf("FORWARD ELIMINATION\n");
        for (j = i + 1; j < max_length; j++) {
            //   printf("\tCOLONNA %d\n", j);
            //forward elimination  
            //avanzo sulle colonne dopo il pivot
            elem_col = a[(j * m) + i];
            // printf("\tELEMENTO COLONNA %d = %f\n", j, elem_col);
            for (k = 0; k < max_length; k++) {
                pos = (j * m) + k;
                pos2 = (i * m) + k;
                /* if(a[(i * m) + k] != a[(i * m) + k]){
                     printf("TROVATO!\n");
                 }*/
                //   printf("\tELEMENTO IN A[%d,%d] = %f\n", j, k, a[(j * m) + k]);
                //scendo sulle righe della colonna jesima
                //    printf("\tEFFETTUO SU A[%d,%d]: %f - (%f * %f)\n", j, k, a[(j * m) + k], elem_col, a[(i * m) + k]);
                a[pos] = a[pos]-(elem_col * a[pos2]);
                //   printf("\t= %f\n", a[(j * m) + k]);
                //  printf("\tELEMENTO IN ID[%d,%d] = %f\n", j, k, id[(j * m) + k]);
                //   printf("\tEFFETTUO SU ID[%d,%d]: %f - (%f * %f)\n", j, k, id[(j * m) + k], elem_col, id[(i * m) + k]);
                id[pos] = id[pos]-(elem_col * id[pos2]);
                //  printf("\t= %f\n", id[(j * m) + k]);
            }
            /*printf("MATRICE CORRENTE:\n");
            printMatrix(a, m, m);
            printMatrix(id, m, m);*/
        }



        //printf("BACKWARD ELIMINATION\n");

        /* printf("MATRICE CORRENTE:\n");
             printMatrix(a, m, m);
             printMatrix(id, m, m);*/

    }
    for (i = max_length - 1; i > 0; i--) {
        for (j = i - 1; j >= 0; j--) {

            //backward elimination
            //torno indietro sulle colonne precedenti il pivot
            //se trovo uno zero sul primo elemento mi posso fermare
            //if (a[(j * m) + j] == 0) {
            //     printf("ELEMENTO IN A[%d,%d] = 0. FINITO BACKWARD ELMINATION.\n", j, i);
            //     break;
            // }
            elem_col = a[(j * m) + i];
            //  printf("\tELEMENTO COLONNA %d = %f\n", j, elem_col);

            for (k = 0; k < max_length; k++) {
                pos = (j * m) + k;
                pos2 = (i * m) + k;
                //scendo sulle righe della colonna jesima
                //  printf("\tELEMENTO IN A[%d,%d] = %f\n", j, k, a[(j * m) + k]);
                //  printf("\tEFFETTUO SU A[%d,%d]: %f - (%f * %f)\n", j, k, a[(j * m) + k], elem_col, a[(i * m) + k]);

                a[pos] = a[pos]-(elem_col * a[pos2]);
                //printf("\t= %f\n", a[(j * m) + k]);

                //printf("\tELEMENTO IN ID[%d,%d] = %f\n", j, k, id[(j * m) + k]);
                //printf("\tEFFETTUO SU ID[%d,%d]: %f - (%f * %f)\n", j, k, id[(j * m) + k], elem_col, id[(i * m) + k]);

                id[pos] = id[pos]-(elem_col * id[pos2]);
                //printf("\t= %f\n", id[(j * m) + k]);
            }
            /* printf("MATRICE CORRENTE:\n");
             printMatrix(a, m, m);
             printMatrix(id, m, m);*/
        }
    }
    /*printf("MATRICE CORRENTE1:\n");
    printMatrix(a, m, m);
    printMatrix(id, m, m);*/



    if (isIdentity(a, m, pad) == 1) {
        printf("La matrice di partenza è ora identità\n");
    } else {
        printf("La matrice di partenza non è identità\n");
        // printMatrix(a, m, m);
    }

    dealloc_matrix(a);
    //dealloc_vector(scalev);
    MATRIX tmp = matrix_transpose_cache_oblivious(id, m, m);
    // printf("MATRICE CORRENTE2:\n");
    //printMatrix(id, m, m);

    //dealloc_matrix(id);
    /* printf("MATRICE CORRENTE3:\n");
            printMatrix(tmp, m, m);*/
    return id;




}

float matrix_inverse_lu(const MATRIX c, MATRIX b, int size, int pad) {
    MATRIX a;
    float m, pivot, det;
    int i, j, k;
    int n = size - pad;

    /* Uso una matrice di appoggio `a'		*/
    /* b e' inizializzata all'identita'		*/

    a = alloc_matrix(size, size);

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            a[(i * size) + j] = c[(i * size) + j];
            //b[(i*size)+j] = 0.0;
        }
        b[(i * size) + i] = 1.0;
    }

    /* Ax = b  ->  LUx = b  ->  Ux = inv(L)b		*/
    /* moltiplica per l'inversa di L	*/
    int pos_pivot;
    for (k = 0; k < n; k++) {
        pivot = a[(k * size) + k];

        /* pos_pivot = matrix_inverse_find_pivot_on_cols(a,k,size,pad);
        
         if(pos_pivot!= k){
             matrix_inverse_swap_cols(a,b,k,pos_pivot,size,pad);
         }*/

        if (fabs(pivot) < 5e-16) return 0.0;

        for (i = k + 1; i < n; i++) {
            m = a[(i * size) + k] / pivot;
            for (j = 0; j <= k; j++)
                b[(i * size) + j] -= m * b[(k * size) + j];
            for (j = k; j < n; j++)
                a[(i * size) + j] -= m * a[(k * size) + j];
        }
    }

    /* Ux = inv(L)b  ->  x = inv(U)(inv(L)b)	
      moltiplica per inv(U)= sostituzione all'indietro    	
     Det *= elemU[i][i]	
     */
    det = 1.0;
    for (i = n - 1; i >= 0; i--) {
        pivot = a[(i * size) + i];
        if (fabs(pivot) < 5e-16) return 0.0;
        det *= pivot;
        for (k = 0; k < n; k++) {
            m = b[(i * size) + k];
            for (j = i + 1; j < n; j++)
                m -= a[(i * size) + j] * b[(j * size) + k];
            b[(i * size) + k] = m / pivot;
        }
    }

    dealloc_matrix(a);
    return det;
}

void matrix_inverse_lu_sse(const MATRIX c, MATRIX b, int size, int pad) {

    MATRIX a;
    float m, pivot, det;
    int i, j, k;
    int n = size - pad;



    /* Uso una matrice di appoggio `a'	
     b è la matrice identità		
     */
    a = alloc_matrix(size, size);

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            a[(i * size) + j] = c[(i * size) + j];
            //b[(i*size)+j] = 0.0;
        }
        b[(i * size) + i] = 1.0;
    }

    /* Ax = b  ->  LUx = b  ->  Ux = inv(L)b		*/
    /* moltiplica per l'inversa di L	*/
    int pos_pivot;
    int UNROLL = 4;
    int VECTORIZATION = 4;
    int length = (n / UNROLL) * UNROLL;
    __m128 xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6, xmm7, xmm8, zero_sign, min_pivot;
    int pos1, pos2;
    pos1 = k*size;

    zero_sign = _mm_set1_ps(-0.0);
    min_pivot = _mm_set1_ps(5e-16);
    int h = 0;
    int vmask;
    
    for (k = 0; k < n; k += UNROLL, h++) { 


        //blocco 1
       
        xmm0 = _mm_load_ps(a + (h * size) + k);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value
        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            xmm1 = _mm_load_ps(a + (i * size) + k);
            xmm1 = _mm_shuffle_ps(xmm1, xmm1, 0b00000000);
            xmm1 = _mm_div_ps(xmm1, xmm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 4 elements
                xmm2 = _mm_load_ps(b + (i * size)+(j * VECTORIZATION));
                xmm3 = _mm_load_ps(b + (h * size)+(j * VECTORIZATION));
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm_store_ps(b + (i * size)+(j * VECTORIZATION), xmm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                xmm2 = _mm_load_ps(a + (i * size) + j);
                xmm3 = _mm_load_ps(a + (h * size) + j);
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3);
                _mm_store_ps(a + (i * size) + j, xmm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }

        //blocco 2
        h++;
        
        xmm0 = _mm_load_ps(a + (h * size) + k);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value
        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            xmm1 = _mm_load_ps(a + (i * size) + k);
            xmm1 = _mm_shuffle_ps(xmm1, xmm1, 0b01010101);
            xmm1 = _mm_div_ps(xmm1, xmm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 4 elements
                xmm2 = _mm_load_ps(b + (i * size)+(j * VECTORIZATION));
                xmm3 = _mm_load_ps(b + (h * size)+(j * VECTORIZATION));
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm_store_ps(b + (i * size)+(j * VECTORIZATION), xmm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                xmm2 = _mm_load_ps(a + (i * size) + j);
                xmm3 = _mm_load_ps(a + (h * size) + j);
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3);
                _mm_store_ps(a + (i * size) + j, xmm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }

        //blocco 3
        h++;
   
        xmm0 = _mm_load_ps(a + (h * size) + k);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value
        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            xmm1 = _mm_load_ps(a + (i * size) + k);
            xmm1 = _mm_shuffle_ps(xmm1, xmm1, 0b10101010);
            xmm1 = _mm_div_ps(xmm1, xmm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 4 elements
                xmm2 = _mm_load_ps(b + (i * size)+(j * VECTORIZATION));
                xmm3 = _mm_load_ps(b + (h * size)+(j * VECTORIZATION));
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm_store_ps(b + (i * size)+(j * VECTORIZATION), xmm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                xmm2 = _mm_load_ps(a + (i * size) + j);
                xmm3 = _mm_load_ps(a + (h * size) + j);
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3);
                _mm_store_ps(a + (i * size) + j, xmm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }
        //blocco 4
        h++;
        
        xmm0 = _mm_load_ps(a + (h * size) + k);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value

        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {



            xmm1 = _mm_load_ps(a + (i * size) + k);
            xmm1 = _mm_shuffle_ps(xmm1, xmm1, 0b11111111);
            xmm1 = _mm_div_ps(xmm1, xmm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 4 elements
                xmm2 = _mm_load_ps(b + (i * size)+(j * VECTORIZATION));
                xmm3 = _mm_load_ps(b + (h * size)+(j * VECTORIZATION));
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm_store_ps(b + (i * size)+(j * VECTORIZATION), xmm2);
            }

            for (j = k; j < n; j += VECTORIZATION) {
                xmm2 = _mm_load_ps(a + (i * size) + j);
                xmm3 = _mm_load_ps(a + (h * size) + j);
                xmm3 = _mm_mul_ps(xmm1, xmm3);
                xmm2 = _mm_sub_ps(xmm2, xmm3);
                _mm_store_ps(a + (i * size) + j, xmm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }





        /*  for (i = k + 1; i < n; i++) {
              m = a[(i * size) + k] / pivot;
              for (j = 0; j <= k; j++)
                  b[(i * size) + j] -= m * b[(k * size) + j];
              for (j = k; j < n; j++)
                  a[(i * size) + j] -= m * a[(k * size) + j];
          }*/
    }
    /*printf("MATRICE A\n");
    printMatrix(a,size,size);
    printf("MATRICE B\n");
    printMatrix(b,size,size);*/

    /* Ux = inv(L)b  ->  x = inv(U)(inv(L)b)	
      moltiplica per inv(U)= sostituzione all'indietro    	
     Det *= elemU[i][i]	
     */
   // det = 1.0;
    h=n-1;
    float tmp ;
    int pos_block;
    for (i = n - 1; i >= 0; i -= UNROLL,h--) {
        
        //blocco 1
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        xmm0 = _mm_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value
        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }        
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            xmm1 = _mm_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                xmm2 = _mm_set1_ps(tmp);
                xmm3 = _mm_load_ps(b+(j*size)+k);
                xmm3 = _mm_mul_ps(xmm2,xmm3);
                xmm1 = _mm_sub_ps(xmm1,xmm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            xmm1 = _mm_div_ps(xmm1,xmm0);//m / pivot;
            _mm_store_ps(b+(h*size)+k,xmm1);
            
           
        }
        
         //blocco 2
        h--;        
        xmm0 = _mm_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value
        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }        
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            xmm1 = _mm_load_ps(b + ((h) * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                xmm2 = _mm_set1_ps(tmp);
                xmm3 = _mm_load_ps(b+(j*size)+k);
                xmm3 = _mm_mul_ps(xmm2,xmm3);
                xmm1 = _mm_sub_ps(xmm1,xmm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            xmm1 = _mm_div_ps(xmm1,xmm0);//m / pivot;
            _mm_store_ps(b+(h*size)+k,xmm1);
            
           
        }
         //blocco 3
        h--;
        xmm0 = _mm_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value
        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }        
       // det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            xmm1 = _mm_load_ps(b + ((h) * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                xmm2 = _mm_set1_ps(tmp);
                xmm3 = _mm_load_ps(b+(j*size)+k);
                xmm3 = _mm_mul_ps(xmm2,xmm3);
                xmm1 = _mm_sub_ps(xmm1,xmm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            xmm1 = _mm_div_ps(xmm1,xmm0);//m / pivot;
            _mm_store_ps(b+(h*size)+k,xmm1);
            
           
        }
         //blocco 4
        h--;
        xmm0 = _mm_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000); //pivot

        //if (fabs(pivot) < 5e-16) return 0.0;
        xmm1 = _mm_andnot_ps(zero_sign, xmm0); //absolute value
        xmm1 = _mm_cmplt_ps(xmm1, min_pivot);
        vmask = _mm_movemask_ps(xmm1);
        if (vmask != 0) {
            break;
        }        
       // det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            xmm1 = _mm_load_ps(b + ((h) * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                xmm2 = _mm_set1_ps(tmp);
                xmm3 = _mm_load_ps(b+(j*size)+k);
                xmm3 = _mm_mul_ps(xmm2,xmm3);
                xmm1 = _mm_sub_ps(xmm1,xmm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            xmm1 = _mm_div_ps(xmm1,xmm0);//m / pivot;
            _mm_store_ps(b+(h*size)+k,xmm1);
            
           
        }
        
    }

    dealloc_matrix(a);
    

 
}

int isIdentity(MATRIX mat, int m, int pad) {
    int i, j;
    int l = m - pad;
    for (i = 0; i < l; i++) {
        for (j = 0; j < l; j++) {
            if (i == j && mat[(i * m) + j] != 1) {
                printf("elemento in %d,%d non è 1 ma %f\n", i, j, mat[(i * m) + j]);
                return 0;
            } else if (i != j) {
                if (mat[(i * m) + j] != 0) {
                    printf("elemento in %d,%d non è 0 ma %f\n", i, j, mat[(i * m) + j]);
                    return 0;
                }
            }
        }
    }
    return 1;
}

/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX X, VECTOR Y, VECTOR beta, int m, int n) {
    int i, j;
    /*printf("Y=\n");
    printMatrix(Y, m, 1);
    printf("BETA=\n");
    printMatrix(beta, n, 1);*/
	int size_m = m-ROW_PADDING;
	int size_n = n-COL_PADDING;

	//printf("M = %d, N= %d\n",m,n);
//printf("MATRIX_HEIGHT = %d, MATRIX_WIDTH= %d\n",MATRIX_HEIGHT,MATRIX_WIDTH);
    float err = 0, de, yp;

    for (i = 0; i < size_m; i++) {
        yp = 0;
        for (j = 0; j < size_n; j++) {
            // printf("\t%d)yp=%f*%f = ",j,X[(j * m) + i],beta[j]);
            yp += X[(j * m) + i] * beta[j];
            //printf("%f\n",yp);
        }
        //printf("%d)de=fabs(%f-%f) = ",i,Y[i],yp);
        de = fabs(Y[i] - yp);
        //printf("%f\n",de);
        err += (de * de);
    }
    return err / (size_m * size_n);
}

void printMatrixXy(MATRIX Xy, int m, int n, VECTOR Y) {



    int i, j;
    for (i = 0; i < (m); i++) {
        printf("\n%d) ", i);
        for (j = 0; j < (n); j++) {
            printf("%f ", Xy[(j * m) + i]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }

        printf("Y=%f", Y[i % m]);
    }

    printf("\n\n================================================\n\n");
}

void saveMatrix(MATRIX a, VECTOR Y, int m, int n, char * filename) {
    FILE * fp;
    fp = fopen(filename, "w");

    int i, j;
    for (i = 0; i < (m); i++) {
        fprintf(fp, "\n%d) ", i);
        for (j = 0; j < (n); j++) {
            fprintf(fp, "%f ", a[(j * m) + i]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }

        fprintf(fp, "Y=%f", Y[i % m]);
    }
    //fprintf(fp, "Y=%f", Y[i % m]);
    fclose(fp);

}

void saveMatrixNoPadding(MATRIX a, VECTOR Y, int m, int n, char * filename) {
    FILE * fp;
    fp = fopen(filename, "w");
    /*int size_m, size_n;
    getSizeWithPadding(m, n, &size_m, &size_n);*/
    int i, j;
    for (i = 0; i < (m); i++) {
        fprintf(fp, "\n%d) ", i);
        for (j = 0; j < (n); j++) {
            if (j == (n)) {
                j += COL_PADDING - 1;
                continue;
            }
            fprintf(fp, "%f ", a[i * (MATRIX_WIDTH) + j]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }
        if (i < m)
            fprintf(fp, "Y=%f", Y[i % m]);
    }
    fclose(fp);

}

void printMatrix(MATRIX a, int m, int n) {
    int i, j;
    for (i = 0; i < (m); i++) {
        printf("\n%d) ", i);
        for (j = 0; j < (n); j++) {
            printf("%f\t", a[(j * m) + i]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }

    }

    printf("\n\n================================================\n\n");
}

int equalsMatrix(MATRIX a, MATRIX b, int n, int m) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            if (a[(j * m) + i] != b[(j * m) + i]) {
                printf("Elemento diverso in: %d,%d :\n a= %f - b= %f\n", i, j, a[(j * m) + i], b[(j * m) + i]);
                return 0;
            }
        }
    }
    return 1;
}

void getPaddingNumberRC(int m, int n, int * n_rows, int * n_cols) {
    * n_rows = ROW_PADDING;
    * n_cols = COL_PADDING;
}

int getNecessaryPadding(int length) {
    int MULT = 4;
    return (length % MULT) == 0 ? 0 : MULT - (length % MULT);
}

void setPaddingNumberRC(int m, int n) {
    int MULT = 4;
    ROW_PADDING = (m % MULT) == 0 ? 0 : MULT - (m % MULT);
    COL_PADDING = (n % MULT) == 0 ? 0 : MULT - (n % MULT);
    MATRIX_HEIGHT = m + ROW_PADDING;
    MATRIX_WIDTH = n + COL_PADDING;
}

void getSizeWithPadding(int m, int n, int * p_m, int * p_n) {
    int pm, pn;
    getPaddingNumberRC(m, n, &pm, &pn);
    * p_m = m + (pm);
    * p_n = n + (pn);
}

MATRIX fromRowToColumnMajor(MATRIX a, int m, int n) {
    MATRIX tmp = (MATRIX) alloc_matrix(m, n);
    int i, j, k, h;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            k = i + (j * m);
            h = (i * n) + j;
            tmp[k] = a[h];

        }
    }
    //dealloc_matrix(tmp);
    return tmp;




}

MATRIX fromColumnToRowMajor(MATRIX a, int m, int n) {
    MATRIX tmp = (MATRIX) alloc_matrix(m, n);
    int i, j, k, h;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            k = i + (j * m);
            h = (i * n) + j;
            tmp[h] = a[k];

        }
    }
    //dealloc_matrix(tmp);
    return tmp;




}

void printMatrixAsArray(MATRIX a, int m, int n) {
    int i;
    for (i = 0; i < m * n; i++) {
        printf("%f\t", a[i]);
    }
    printf("\n");
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_12.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/

int main(int argc, char** argv) {
    int m = 10;
    int n = 2;
    MATRIX X;
    VECTOR Y;
    VECTOR beta;

    char* filename = "";
    int silent = 0, display = 0, fsave = 0;
    int i,j;

    srandom(time(NULL));

    int par = 1;
    while (par < argc) {
        if (strcmp(argv[par], "-l") == 0) {
            par++;
            if (par < argc) {
                filename = argv[par];
                par++;
            }
        } else if (strcmp(argv[par], "-r") == 0) {
            par++;
            if (par < argc) {
                m = atoi(argv[par]);
                par++;
                if (par < argc) {
                    n = atoi(argv[par]);
                    par++;
                }
            }
        } else if (strcmp(argv[par], "-f") == 0) {
            fsave = 1;
            par++;
        } else if (strcmp(argv[par], "-s") == 0) {
            silent = 1;
            par++;
        } else if (strcmp(argv[par], "-d") == 0) {
            display = 1;
            par++;
        } else
            par++;
    }

    if (!silent) {
        printf("linreg32\n");
        printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
        printf("\nParameters:\n");
        printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
        printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
        printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
        printf("\t-d : displays input and output\n");
        printf("\t-s : silent\n");
    }

    if (strlen(filename) == 0)
        X = random_input(m, n, &Y);
    else
        X = load_input(filename, &m, &n, &Y);

	//printMatrix(X,MATRIX_HEIGHT,MATRIX_WIDTH);

    if (!silent && display) {
        printf("\nInput augmented matrix:\n");
	//printf("M = %d, N= %d\n",m,n);
        for (i = 0; i < m; i++) {		
            for(j=0;j<n;j++){
		printf("%.3f ",X[(j*MATRIX_HEIGHT)+i]);		
		}
		printf("%.3f\n",Y[i]);
		
        }
        printf("\n");
    }

	if (!silent)
        printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
    //printMatrix(Y,m,1);
    //saveMatrix(X,Y,m,n,"matriceX.txt");
    clock_t t = clock();
    beta = linreg(X, Y, MATRIX_HEIGHT, MATRIX_WIDTH);
    t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

    if (!silent)
        printf("\nExecution time = %.3f seconds\n", ((float) t) / CLOCKS_PER_SEC);
    else
        printf("%.3f\n", ((float) t) / CLOCKS_PER_SEC);

    if (!silent && display) {
        printf("\nOutput coefficient vector:\n");
        for (i = 0; i < n; i++)
            printf("%.3f ", beta[i]);
        printf("\n");
    }

    float err = error(X, Y, beta, MATRIX_HEIGHT, MATRIX_WIDTH);
    if (!silent)
        printf("\nThe error is %f.\n", err);
    else
        printf("%.3f\n", err);

    if (strlen(filename) == 0 && fsave)
        save_input("last.mat", X, MATRIX_HEIGHT, MATRIX_WIDTH, Y);
    
    return EXIT_SUCCESS;
}
