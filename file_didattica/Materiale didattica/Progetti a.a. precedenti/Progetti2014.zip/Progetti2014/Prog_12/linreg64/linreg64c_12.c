/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 30 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 linreg64.nasm && gcc -O3 -m64 -mavx linreg64.o linreg64c.c -o linreg64c && ./linreg64c
 
 oppure
 
 ./runlinreg64

 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>
#include <immintrin.h>
//#include <smmintrin.h>

/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*


int ROW_PADDING = 0, COL_PADDING = 0, MATRIX_HEIGHT = 0, MATRIX_WIDTH = 0;



/*
 PROTOTYPE FUNCTION
 */

VECTOR matrix_vector_product_cache_oblivious(MATRIX a, VECTOR b, int am, int abn);
void matrix_vector_product_cache_oblivious_rec(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C);
void matrix_vector_product_avx(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C);

void matrix_inverse_lu_avx(const MATRIX c, MATRIX b, int size, int pad);

MATRIX matrix_product_cache_oblivious(MATRIX a, MATRIX b, int am, int abn, int bp);
void matrix_product_cache_oblivious_rec2(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C);
void matrix_product_avx(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C);


MATRIX matrix_traspose_cache_oblivious(MATRIX a, int m, int n);
void matrix_traspose_cache_oblivious_rec(MATRIX a, MATRIX c, int x, int y, int dm, int dn, int m, int n);

MATRIX fromColumnToRowMajor(MATRIX a, int m, int n);
MATRIX fromRowToColumnMajor(MATRIX a, int m, int n);


void setPaddingNumberRC(int m, int n);
int getNecessaryPadding(int length);
void getPaddingNumberRC(int m, int n, int * n_rows, int * n_cols);
void getSizeWithPadding(int m, int n, int * p_m, int * p_n);

void saveMatrix(MATRIX a, VECTOR Y, int m, int n, char * filename);



/*
 END PROTOTYPE
 */


void* get_block(int size, int elements) {
    return _mm_malloc(elements*size, 32);
}

void free_block(void* p) {
    _mm_free(p);
}

VECTOR alloc_vector(int rows) {
    VECTOR A = (VECTOR) get_block(sizeof (float), rows);
    int i;
    for (i = 0; i < rows; i++) {
        A[i] = 0;
    }
    return A;
}

MATRIX alloc_matrix(int rows, int cols) {
    MATRIX A = (MATRIX) get_block(sizeof (float), rows * cols);
    int i;
    for (i = 0; i < rows * cols; i++) {
        A[i] = 0;
    }
    return A;
}

void dealloc_vector(VECTOR vec) {
    free_block(vec);
}

void dealloc_matrix(MATRIX mat) {
    free_block(mat);
}

float frand() {
    float r = (float) rand();
    return r / RAND_MAX;
}

/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n, VECTOR * Y) {
    int i, j;
    int pm, pn;
    setPaddingNumberRC(m, n);
    int size_m = m + ROW_PADDING;
    int size_n = n + COL_PADDING;
    MATRIX A = alloc_matrix(size_m, size_n);
    VECTOR Y2 = alloc_vector(size_m);
    //printf("Allocata matrice %d,%d\n", size_m, size_n);
    float x, y, e;
    float* beta = calloc(n, sizeof (float));

    for (i = 0; i < n; i++)
        beta[i] = frand();
    e = frand()*0.2;

    for (i = 0; i < m; i++) {
        y = 0;
        for (j = 0; j < n; j++) {
            if (j < n - 1)
                x = frand();
            else
                x = 1.0;
            //pos = i * (n + 1) + j;
            A[(i * (size_n)) + j] = x;
            y += x * beta[j];
        }
        /*for (j = n; j < size_n; j++) {
            A[(i * (size_n)) + j] = 0;
        }*/
        Y2[i] = y; //* (1 + frand() * e - e / 2);
        //printf("Y[%d] = %f in Y[%d]\n", i, (*Y)[i], i);
    }
    /*for (i = m; i < size_m; i++) {
        for (j = 0; j < size_n; j++) {
            A[(i * (size_n)) + j] = 0;
        }
        Y2[i] = 0;
    }*/


    *Y = Y2;
    free(beta);
    MATRIX A2 = fromRowToColumnMajor(A, size_m, size_n);
    dealloc_matrix(A);
    return A2;
}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n, VECTOR * Y) {
    FILE* fp;
    int rows, cols, status;

    fp = fopen(filename, "rb");
    status = fread(&cols, sizeof (int), 1, fp);
    status = fread(&rows, sizeof (int), 1, fp);

    setPaddingNumberRC(rows, cols - 1);
    int size_m = rows + ROW_PADDING;
    int size_n = cols - 1 + COL_PADDING;
    MATRIX Xy = alloc_matrix(size_m, size_n);

    VECTOR Y2 = alloc_vector(size_m);
    int i, j;
    for (i = 0; i < rows; i++) {
        //printf("i=%d\n", i);
        for (j = 0; j < cols - 1; j++) {
            status = fread(&Xy[i * (size_n) + j], sizeof (float), 1, fp);

            //printf("Letto %f\n", Xy[i * (size_n) + j]);



        }
        /* for (j = cols - 1; j < size_n; j++) {
             Xy[i * (size_n) + j] = 0;
         }*/
        status = fread(&Y2[i], sizeof (float), 1, fp);
        //printf("Letto y %f in %d\n", (*Y)[i], i);
    }
    /*for (i = rows; i < size_m; i++) {
        for (j = 0; j < size_n; j++) {
            Xy[i * (size_n) + j] = 0;
        }
        Y2[i] = 0;
    }*/

    //status = fread(Xy, sizeof (float), rows*cols, fp);
    fclose(fp);

    *m = rows;
    *n = cols - 1;
    *Y = Y2;
    MATRIX Xy2 = fromRowToColumnMajor(Xy, size_m, size_n);
    dealloc_matrix(Xy);
    return Xy2;
}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n, VECTOR Y) {
    MATRIX Xy2 = fromColumnToRowMajor(Xy, m, n);

/*printf("MATRICE XY\n");
printMatrix(Xy,m,n);
printf("MATRICE XY2\n");
printMatrix(Xy2,m,n);*/

    dealloc_matrix(Xy);

    int status;
    FILE * fp;
    fp = fopen(filename, "wb");
    int size_m, size_n;
//    getSizeWithPadding(m, n, &size_m, &size_n);
size_m = m-ROW_PADDING;
size_n = n-COL_PADDING;

    int i, j;
    size_n++;
    status = fwrite(&size_n, sizeof (int), 1, fp);
    status = fwrite(&size_m, sizeof (int), 1, fp);

	
	
    for (i = 0; i < (size_m); i++) {
        for (j = 0; j < (size_n - 1); j++) {
            status = fwrite(&Xy2[i * (n) + j], sizeof (float), 1, fp);
//            printf("SCRITTO A[%d,%d]=%f\n", i, j, Xy2[i * (n) + j]);
        }

        status = fwrite(&Y[i % m], sizeof (float), 1, fp);
   //     printf("SCRITTO Y[%d,%d]=%f\n", i, j, Y[i % m]);
    }
    fclose(fp);

}

/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX X, VECTOR Y, int m, int n) {

    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------

    //linreg64(Xy, beta, m, n); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------
  /* printf("MATRICE X\n");
    printMatrix(X, m, n);*/
    MATRIX xt = matrix_traspose_cache_oblivious(X, m, n);
   /* printf("MATRICE XT\n");
    printMatrix(xt, n, m);*/
    //saveMatrix(X, Y, m, n, "matrice_X.txt");
    //saveMatrix(xt, Y, n, m, "matrice_XT.txt");

    MATRIX prod = matrix_product_cache_oblivious(xt, X, n, m, n);

    //saveMatrix(prod,Y,n,n,"matrice_XT_X.txt");
    /*printf("PRODOTTO\n");
    printMatrix(prod,n,n);*/

    dealloc_matrix(xt);

    MATRIX inverse = alloc_matrix(n, n);
    matrix_inverse_lu_avx(prod, inverse, n, COL_PADDING);
/*printf("INVERSA\n");
    printMatrix(inverse,n,n);*/
    //saveMatrix(inverse,Y,n,n,"matrice_inversa.txt");
    
    xt = matrix_traspose_cache_oblivious(X, m, n);

    prod = matrix_product_cache_oblivious(inverse, xt, n, n, m);

    dealloc_matrix(xt);
    dealloc_matrix(inverse);

   /* printf("MATRICE:\n");
    printMatrix(prod,n,m);
    printf("VETTORE:\n");
    printMatrix(Y,m,1);
*/
    VECTOR beta = matrix_vector_product_cache_oblivious(prod, Y, n, m);
    dealloc_matrix(prod);

    /*printf("VETTORE BETA:\n");
    printMatrix(beta,n,1);*/

    return beta;
}

void print256_num(__m256 var) {
    float_t *val = (float_t*) & var; //can also use uint32_t instead of 16_t
    printf("%f %f %f %f %f %f %f %f\n", val[0], val[1], val[2], val[3], val[4], val[5], val[6], val[7]);
}

VECTOR matrix_vector_product_cache_oblivious(MATRIX a, VECTOR b, int am, int abn) {
    //int m = MATRIX_HEIGHT, n = MATRIX_WIDTH;
    VECTOR c = alloc_vector(am);

    int * params_A = (int *) get_block(sizeof (int), 7);
    int * params_B = (int *) get_block(sizeof (int), 7);
    int * params_C = (int *) get_block(sizeof (int), 1);

    params_A[0] = 0; //start x
    params_A[1] = 0; //start y
    params_A[2] = am; //altezza sottomatrice
    params_A[3] = abn; //larghezza sottomatrice
    params_A[4] = am; //altezza matrice contenitore
    params_A[5] = abn; //larghezza matrice contenitore
    params_A[6] = am; //# righe

    params_B[0] = 0;
    //params_B[1] = 0;
    params_B[2] = abn;
    //params_B[3] = bp;
    params_B[4] = abn;
    //params_B[5] = bp;
    params_B[6] = abn;

    params_C[0] = 0;
    //params_C[1] = 0;

    //printMatrix(a,am,abn);

    matrix_vector_product_cache_oblivious_rec(a, b, c, params_A, params_B, params_C);


    free_block(params_A);
    free_block(params_B);
    free_block(params_C);
    return c;
}

void matrix_vector_product_avx(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C) {

    int UNROLL = 4;
    int VECTORIZATION = 8;
    int p = UNROLL * VECTORIZATION;
    int dma = params_A[2];
    int dna = params_A[3];

    int dnb = params_B[3];
    int k, i, j, h, z, v;
    int xa = params_A[0];
    int ya = params_A[1];

    int ma = params_A[6];

    int lk = (((dma) / p) * p) + xa;
    int li = dna + ya; //(((dna) / p) * p) + ya;

    __m256 ymm0, ymm1, ymm2, ymm3, ymm4, ymm5, ymm6, ymm7, ymm8, ymm9, ymm10, ymm11;


    int cx = params_C[0];
    //int cy = params_C[1];

    __m128 xmm0, xmm1;
    int pos;
    for (k = xa, z = cx; k < lk; k += (p), z += (p)) {



        ymm4 = _mm256_load_ps(c + z);
        ymm5 = _mm256_load_ps(c + z + 8);
        ymm6 = _mm256_load_ps(c + z + 16);
        ymm7 = _mm256_load_ps(c + z + 24);
        /*ymm8 = _mm256_load_ps(c + ((v) * ma) + z + 32);
        ymm9 = _mm256_load_ps(c + ((v) * ma) + z + 40);
        ymm10 = _mm256_load_ps(c + ((v) * ma) + z + 48);
        ymm11 = _mm256_load_ps(c + ((v) * ma) + z + 56);*/


        for (i = ya; i < li; i += VECTORIZATION) {
            ymm3 = _mm256_load_ps(b + i);

            //blocco 1
            pos = ((i) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sul primo elemento 
            xmm0 = _mm256_extractf128_ps(ymm3, 0b00000000); //estraggo la parte bassa (128bit) di ymm3 per i primi 4 elementi

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
            //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /*  ymm2 = _mm256_load_ps(a+pos + 32);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm8 = _mm256_add_ps(ymm2, ymm8);

              ymm2 = _mm256_load_ps(a+pos+ 40);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm9 = _mm256_add_ps(ymm2, ymm9);

              ymm2 = _mm256_load_ps(a+pos+ 48);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm10 = _mm256_add_ps(ymm2, ymm10);

              ymm2 = _mm256_load_ps(a+pos+ 56);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm11 = _mm256_add_ps(ymm2, ymm11);*/



            //blocco 2
            pos = ((i + 1) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sul secondo elemento 
            // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al secondo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al secondo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /* ymm2 = _mm256_load_ps(a+pos + 32);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm8 = _mm256_add_ps(ymm2, ymm8);

             ymm2 = _mm256_load_ps(a+pos + 40);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm9 = _mm256_add_ps(ymm2, ymm9);

             ymm2 = _mm256_load_ps(a+pos+ 48);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm10 = _mm256_add_ps(ymm2, ymm10);

             ymm2 = _mm256_load_ps(a+pos + 56);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm11 = _mm256_add_ps(ymm2, ymm11);
             */

            //blocco 3
            pos = ((i + 2) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sul terzo elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al terzo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al terzo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /* ymm2 = _mm256_load_ps(a+pos + 32);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm8 = _mm256_add_ps(ymm2, ymm8);

             ymm2 = _mm256_load_ps(a+pos+ 40);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm9 = _mm256_add_ps(ymm2, ymm9);

             ymm2 = _mm256_load_ps(a+pos + 48);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm10 = _mm256_add_ps(ymm2, ymm10);

             ymm2 = _mm256_load_ps(a+pos + 56);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm11 = _mm256_add_ps(ymm2, ymm11);*/

            //blocco 4
            pos = ((i + 3) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sul quarto elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quarto) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quarto) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /*    ymm2 = _mm256_load_ps(a+pos + 32);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm8 = _mm256_add_ps(ymm2, ymm8);

                ymm2 = _mm256_load_ps(a+pos+ 40);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm9 = _mm256_add_ps(ymm2, ymm9);

                ymm2 = _mm256_load_ps(a+pos + 48);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm10 = _mm256_add_ps(ymm2, ymm10);

                ymm2 = _mm256_load_ps(a+pos + 56);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm11 = _mm256_add_ps(ymm2, ymm11);*/

            //blocco 5    
            pos = ((i + 4) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sul quinto elemento (il primo della seconda metà)
            xmm0 = _mm256_extractf128_ps(ymm3, 0b00000001); //estraggo la parte alta (128bit) di ymm3

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
            //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quinto) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quinto) nella parte alta di ymm1

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /*  ymm2 = _mm256_load_ps(a+pos + 32);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm8 = _mm256_add_ps(ymm2, ymm8);

              ymm2 = _mm256_load_ps(a+pos + 40);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm9 = _mm256_add_ps(ymm2, ymm9);

              ymm2 = _mm256_load_ps(a+pos + 48);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm10 = _mm256_add_ps(ymm2, ymm10);

              ymm2 = _mm256_load_ps(a+pos+ 56);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm11 = _mm256_add_ps(ymm2, ymm11);*/

            //blocco 6
            pos = ((i + 5) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sul sesto elemento 
            // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al sesto) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al sesto) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /*  ymm2 = _mm256_load_ps(a+pos + 32);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm8 = _mm256_add_ps(ymm2, ymm8);

              ymm2 = _mm256_load_ps(a+pos + 40);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm9 = _mm256_add_ps(ymm2, ymm9);

              ymm2 = _mm256_load_ps(a+pos+ 48);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm10 = _mm256_add_ps(ymm2, ymm10);

              ymm2 = _mm256_load_ps(a+pos + 56);

              ymm2 = _mm256_mul_ps(ymm1, ymm2);
              ymm11 = _mm256_add_ps(ymm2, ymm11);*/

            //blocco 7
            pos = ((i + 6) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sul settimo elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al settimo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al settimo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /* ymm2 = _mm256_load_ps(a+pos + 32);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm8 = _mm256_add_ps(ymm2, ymm8);

             ymm2 = _mm256_load_ps(a+pos + 40);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm9 = _mm256_add_ps(ymm2, ymm9);

             ymm2 = _mm256_load_ps(a+pos + 48);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm10 = _mm256_add_ps(ymm2, ymm10);

             ymm2 = _mm256_load_ps(a+pos + 56);

             ymm2 = _mm256_mul_ps(ymm1, ymm2);
             ymm11 = _mm256_add_ps(ymm2, ymm11);*/

            //blocco 8
            pos = ((i + 7) * ma) + k;
            ymm2 = _mm256_load_ps(a + pos);
            //prodotto con shuffle sull'ottavo elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);


            ymm2 = _mm256_load_ps(a + pos + 8);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm5 = _mm256_add_ps(ymm2, ymm5);

            ymm2 = _mm256_load_ps(a + pos + 16);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm6 = _mm256_add_ps(ymm2, ymm6);

            ymm2 = _mm256_load_ps(a + pos + 24);

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm7 = _mm256_add_ps(ymm2, ymm7);

            /*    ymm2 = _mm256_load_ps(a+pos+ 32);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm8 = _mm256_add_ps(ymm2, ymm8);

                ymm2 = _mm256_load_ps(a+pos + 40);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm9 = _mm256_add_ps(ymm2, ymm9);

                ymm2 = _mm256_load_ps(a+pos+ 48);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm10 = _mm256_add_ps(ymm2, ymm10);

                ymm2 = _mm256_load_ps(a+pos + 56);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm11 = _mm256_add_ps(ymm2, ymm11);*/

        }

        _mm256_store_ps(c + z, ymm4);
        _mm256_store_ps(c + z + 8, ymm5);
        _mm256_store_ps(c + z + 16, ymm6);
        _mm256_store_ps(c + z + 24, ymm7);
        /*_mm256_store_ps(c + ((v) * ma) + z + 32, ymm8);
        _mm256_store_ps(c + ((v) * ma) + z + 40, ymm9);
        _mm256_store_ps(c + ((v) * ma) + z + 48, ymm10);
        _mm256_store_ps(c + ((v) * ma) + z + 56, ymm11);*/




    }


    for (; k < dma + xa; k += (VECTORIZATION), z += (VECTORIZATION)) {



        ymm4 = _mm256_load_ps(c + z);

        for (i = ya; i < li; i += VECTORIZATION) {
            ymm3 = _mm256_load_ps(b + i);

            //blocco 1
            ymm2 = _mm256_load_ps(a + ((i) * ma) + k);
            //prodotto con shuffle sul primo elemento
            xmm0 = _mm256_extractf128_ps(ymm3, 0b00000000); //estraggo la parte bassa (128bit) di ymm3 per i primi 4 elementi

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
            //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

            //blocco 2
            ymm2 = _mm256_load_ps(a + ((i + 1) * ma) + k);
            //prodotto con shuffle sul secondo elemento 
            // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al secondo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al secondo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

            //blocco 3
            ymm2 = _mm256_load_ps(a + ((i + 2) * ma) + k);
            //prodotto con shuffle sul terzo elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al terzo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al terzo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

            //blocco 4
            ymm2 = _mm256_load_ps(a + ((i + 3) * ma) + k);
            //prodotto con shuffle sul quarto elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quarto) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quarto) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

            //blocco 5            
            ymm2 = _mm256_load_ps(a + ((i + 4) * ma) + k);
            //prodotto con shuffle sul quinto elemento (il primo della seconda metà)
            xmm0 = _mm256_extractf128_ps(ymm3, 0b00000001); //estraggo la parte alta (128bit) di ymm3

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
            //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quinto) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quinto) nella parte alta di ymm1

            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

            //blocco 6
            ymm2 = _mm256_load_ps(a + ((i + 5) * ma) + k);
            //prodotto con shuffle sul sesto elemento 
            // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al sesto) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al sesto) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

            //blocco 7
            ymm2 = _mm256_load_ps(a + ((i + 6) * ma) + k);
            //prodotto con shuffle sul settimo elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al settimo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al settimo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

            //blocco 8
            ymm2 = _mm256_load_ps(a + ((i + 7) * ma) + k);
            //prodotto con shuffle sull'ottavo elemento 
            //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


            xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

            ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte alta di ymm1


            ymm2 = _mm256_mul_ps(ymm1, ymm2);
            ymm4 = _mm256_add_ps(ymm2, ymm4);

        }
        _mm256_store_ps(c + z, ymm4);


    }


    return;
}

void matrix_vector_product_cache_oblivious_rec(MATRIX a, VECTOR b, VECTOR c, int * params_A, int * params_B, int * params_C) {

    int BLOCK = 64;

    if ((params_A[3] <= BLOCK) || (params_A[2] <= BLOCK) /*|| (params_B[2] <= BLOCK) || (params_B[3] <= BLOCK)*/) {
        matrix_vector_product_avx(a, b, c, params_A, params_B, params_C);
        return;
    }

    //delimita il riquadro delle due matrici

    int start_x_a = params_A[0];
    int start_y_a = params_A[1];
    int end_x_a = params_A[2] + start_x_a;
    int end_y_a = params_A[3] + start_y_a;
    int start_x_b = params_B[0];

    int end_x_b = params_B[2] + start_x_b;



    int start_x_c = params_C[0];

    //divido in 4 parti A e B in modo che siano orizzontalmente uguali dato che A è trasposta

    int length_x_a = end_x_a - start_x_a;
    int length_y_a = end_y_a - start_y_a;
    int length_x_b = end_x_b - start_x_b;


    int mid_yaxb = length_x_a / 2; //valori relativi
    int xmid_sup_a = length_x_a / 2;


    int padyx = getNecessaryPadding(mid_yaxb);
    int padx = getNecessaryPadding(xmid_sup_a);

    xmid_sup_a += padx;
    mid_yaxb += padyx;

    int * pa1 = (int *) get_block(sizeof (int), 7);
    int * pa2 = (int *) get_block(sizeof (int), 7);

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore
    pa1[6] = params_A[6]; //righe matrice originale


    pa2[0] = start_x_b; //valore assoluto della posizione di XB

    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)

    pa2[4] = length_x_b; //altezza della matrice contenitore

    pa2[6] = params_B[6]; //righe matrice originale

    int * pa3 = (int *) get_block(sizeof (int), 1);

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)

    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante A


    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB

    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)

    pa2[4] = length_x_b; //altezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)

    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante B


    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB

    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)

    pa2[4] = length_x_b; //altezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)

    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante D

    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB

    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)

    pa2[4] = length_x_b; //altezza della matrice contenitore


    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)

    matrix_vector_product_cache_oblivious_rec(a, b, c, pa1, pa2, pa3); //quadrante C

    free_block(pa1);
    free_block(pa2);
    free_block(pa3);
    return;
}

MATRIX matrix_product_cache_oblivious(MATRIX a, MATRIX b, int am, int abn, int bp) {

    MATRIX c = alloc_matrix(am, bp);

    int * params_A = (int *) get_block(sizeof (int), 7);
    int * params_B = (int *) get_block(sizeof (int), 7);
    int * params_C = (int *) get_block(sizeof (int), 2);

    params_A[0] = 0; //start x
    params_A[1] = 0; //start y
    params_A[2] = am; //altezza sottomatrice
    params_A[3] = abn; //larghezza sottomatrice
    params_A[4] = am; //altezza matrice contenitore
    params_A[5] = abn; //larghezza matrice contenitore
    params_A[6] = am; //# righe

    params_B[0] = 0;
    params_B[1] = 0;
    params_B[2] = abn;
    params_B[3] = bp;
    params_B[4] = abn;
    params_B[5] = bp;
    params_B[6] = abn;

    params_C[0] = 0;
    params_C[1] = 0;

    matrix_product_cache_oblivious_rec2(a, b, c, params_A, params_B, params_C);


    free_block(params_A);
    free_block(params_B);
    free_block(params_C);
    return c;
}

void matrix_product_avx(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C) {

    int UNROLL = 4;
    int VECTORIZATION = 8;
    int p = UNROLL * VECTORIZATION;
    int dma = params_A[2];
    int dna = params_A[3];
    //int dmb = params_B[2];
    int dnb = params_B[3];
    int k, i, j, h, z, v;
    int xa = params_A[0];
    int ya = params_A[1];
    //int xb = params_B[0];
    int yb = params_B[1];
    int ma = params_A[6];
    //int na = params_A[6];
    int mb = params_B[6];
    //int nb = params_B[6];

    /*printf("BLOCCO A: dm = %d, dn = %d\n", dma, dna);
    printf("X = %d, Y = %d\n", xa, ya);
    printf("BLOCCO B: dm = %d, dn = %d\n", dmb, dnb);
    printf("X = %d, Y = %d\n", xb, yb);
     */
    // printf("Stampo matrice A:\n");
    //printMatrix(a, ma, na);
    // printf("Stampo matrice B:\n");
    //printMatrix(b, mb, nb);

    int lk = (((dma) / p) * p) + xa;
    int li = dna + ya; //(((dna) / p) * p) + ya;
    int lj = dnb + yb; //(((dnb) / p) * p) + yb;
    __m256 ymm0, ymm1, ymm2, ymm3, ymm4, ymm5, ymm6, ymm7, ymm8, ymm9, ymm10, ymm11;



    int cx = params_C[0];
    int cy = params_C[1];
    int pos;
    __m128 xmm0, xmm1;

    for (k = xa, z = cx; k < lk; k += (p), z += (p)) {

        for (j = yb, v = cy; j < lj; j++, v++) {

            ymm4 = _mm256_load_ps(c + ((v) * ma) + z);
            ymm5 = _mm256_load_ps(c + ((v) * ma) + z + 8);
            ymm6 = _mm256_load_ps(c + ((v) * ma) + z + 16);
            ymm7 = _mm256_load_ps(c + ((v) * ma) + z + 24);
            /*ymm8 = _mm256_load_ps(c + ((v) * ma) + z + 32);
            ymm9 = _mm256_load_ps(c + ((v) * ma) + z + 40);
            ymm10 = _mm256_load_ps(c + ((v) * ma) + z + 48);
            ymm11 = _mm256_load_ps(c + ((v) * ma) + z + 56);*/


            for (i = ya; i < li; i += VECTORIZATION) {
                ymm3 = _mm256_load_ps(b + (j * mb) + i);

                //blocco 1
                pos = ((i) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sul primo elemento 
                xmm0 = _mm256_extractf128_ps(ymm3, 0b00000000); //estraggo la parte bassa (128bit) di ymm3 per i primi 4 elementi

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
                //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al primo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al primo) nella parte alta di ymm1

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /*  ymm2 = _mm256_load_ps(a+pos + 32);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm8 = _mm256_add_ps(ymm2, ymm8);

                  ymm2 = _mm256_load_ps(a+pos+ 40);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm9 = _mm256_add_ps(ymm2, ymm9);

                  ymm2 = _mm256_load_ps(a+pos+ 48);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm10 = _mm256_add_ps(ymm2, ymm10);

                  ymm2 = _mm256_load_ps(a+pos+ 56);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm11 = _mm256_add_ps(ymm2, ymm11);*/



                //blocco 2
                pos = ((i + 1) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sul secondo elemento 
                // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al secondo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al secondo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /* ymm2 = _mm256_load_ps(a+pos + 32);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm8 = _mm256_add_ps(ymm2, ymm8);

                 ymm2 = _mm256_load_ps(a+pos + 40);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm9 = _mm256_add_ps(ymm2, ymm9);

                 ymm2 = _mm256_load_ps(a+pos+ 48);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm10 = _mm256_add_ps(ymm2, ymm10);

                 ymm2 = _mm256_load_ps(a+pos + 56);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm11 = _mm256_add_ps(ymm2, ymm11);
                 */

                //blocco 3
                pos = ((i + 2) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sul terzo elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al terzo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al terzo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /* ymm2 = _mm256_load_ps(a+pos + 32);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm8 = _mm256_add_ps(ymm2, ymm8);

                 ymm2 = _mm256_load_ps(a+pos+ 40);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm9 = _mm256_add_ps(ymm2, ymm9);

                 ymm2 = _mm256_load_ps(a+pos + 48);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm10 = _mm256_add_ps(ymm2, ymm10);

                 ymm2 = _mm256_load_ps(a+pos + 56);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm11 = _mm256_add_ps(ymm2, ymm11);*/

                //blocco 4
                pos = ((i + 3) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sul quarto elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quarto) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quarto) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /*    ymm2 = _mm256_load_ps(a+pos + 32);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm8 = _mm256_add_ps(ymm2, ymm8);

                    ymm2 = _mm256_load_ps(a+pos+ 40);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm9 = _mm256_add_ps(ymm2, ymm9);

                    ymm2 = _mm256_load_ps(a+pos + 48);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm10 = _mm256_add_ps(ymm2, ymm10);

                    ymm2 = _mm256_load_ps(a+pos + 56);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm11 = _mm256_add_ps(ymm2, ymm11);*/

                //blocco 5    
                pos = ((i + 4) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sul quinto elemento (il primo della seconda metà)
                xmm0 = _mm256_extractf128_ps(ymm3, 0b00000001); //estraggo la parte alta (128bit) di ymm3

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
                //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quinto) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quinto) nella parte alta di ymm1

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /*  ymm2 = _mm256_load_ps(a+pos + 32);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm8 = _mm256_add_ps(ymm2, ymm8);

                  ymm2 = _mm256_load_ps(a+pos + 40);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm9 = _mm256_add_ps(ymm2, ymm9);

                  ymm2 = _mm256_load_ps(a+pos + 48);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm10 = _mm256_add_ps(ymm2, ymm10);

                  ymm2 = _mm256_load_ps(a+pos+ 56);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm11 = _mm256_add_ps(ymm2, ymm11);*/

                //blocco 6
                pos = ((i + 5) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sul sesto elemento 
                // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al sesto) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al sesto) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /*  ymm2 = _mm256_load_ps(a+pos + 32);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm8 = _mm256_add_ps(ymm2, ymm8);

                  ymm2 = _mm256_load_ps(a+pos + 40);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm9 = _mm256_add_ps(ymm2, ymm9);

                  ymm2 = _mm256_load_ps(a+pos+ 48);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm10 = _mm256_add_ps(ymm2, ymm10);

                  ymm2 = _mm256_load_ps(a+pos + 56);

                  ymm2 = _mm256_mul_ps(ymm1, ymm2);
                  ymm11 = _mm256_add_ps(ymm2, ymm11);*/

                //blocco 7
                pos = ((i + 6) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sul settimo elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al settimo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al settimo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /* ymm2 = _mm256_load_ps(a+pos + 32);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm8 = _mm256_add_ps(ymm2, ymm8);

                 ymm2 = _mm256_load_ps(a+pos + 40);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm9 = _mm256_add_ps(ymm2, ymm9);

                 ymm2 = _mm256_load_ps(a+pos + 48);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm10 = _mm256_add_ps(ymm2, ymm10);

                 ymm2 = _mm256_load_ps(a+pos + 56);

                 ymm2 = _mm256_mul_ps(ymm1, ymm2);
                 ymm11 = _mm256_add_ps(ymm2, ymm11);*/

                //blocco 8
                pos = ((i + 7) * ma) + k;
                ymm2 = _mm256_load_ps(a + pos);
                //prodotto con shuffle sull'ottavo elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);


                ymm2 = _mm256_load_ps(a + pos + 8);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm5 = _mm256_add_ps(ymm2, ymm5);

                ymm2 = _mm256_load_ps(a + pos + 16);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm6 = _mm256_add_ps(ymm2, ymm6);

                ymm2 = _mm256_load_ps(a + pos + 24);

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm7 = _mm256_add_ps(ymm2, ymm7);

                /*    ymm2 = _mm256_load_ps(a+pos+ 32);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm8 = _mm256_add_ps(ymm2, ymm8);

                    ymm2 = _mm256_load_ps(a+pos + 40);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm9 = _mm256_add_ps(ymm2, ymm9);

                    ymm2 = _mm256_load_ps(a+pos+ 48);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm10 = _mm256_add_ps(ymm2, ymm10);

                    ymm2 = _mm256_load_ps(a+pos + 56);

                    ymm2 = _mm256_mul_ps(ymm1, ymm2);
                    ymm11 = _mm256_add_ps(ymm2, ymm11);*/

            }

            _mm256_store_ps(c + ((v) * ma) + z, ymm4);
            _mm256_store_ps(c + ((v) * ma) + z + 8, ymm5);
            _mm256_store_ps(c + ((v) * ma) + z + 16, ymm6);
            _mm256_store_ps(c + ((v) * ma) + z + 24, ymm7);
            /*_mm256_store_ps(c + ((v) * ma) + z + 32, ymm8);
            _mm256_store_ps(c + ((v) * ma) + z + 40, ymm9);
            _mm256_store_ps(c + ((v) * ma) + z + 48, ymm10);
            _mm256_store_ps(c + ((v) * ma) + z + 56, ymm11);*/

        }


    }


    for (; k < dma + xa; k += (VECTORIZATION), z += (VECTORIZATION)) {

        for (j = yb, v = cy; j < lj; j++, v++) {

            ymm4 = _mm256_load_ps(c + ((v) * ma) + z);

            for (i = ya; i < li; i += VECTORIZATION) {
                ymm3 = _mm256_load_ps(b + (j * mb) + i);

                //blocco 1
                ymm2 = _mm256_load_ps(a + ((i) * ma) + k);
                //prodotto con shuffle sul primo elemento
                xmm0 = _mm256_extractf128_ps(ymm3, 0b00000000); //estraggo la parte bassa (128bit) di ymm3 per i primi 4 elementi

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
                //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al primo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al primo) nella parte alta di ymm1

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

                //blocco 2
                ymm2 = _mm256_load_ps(a + ((i + 1) * ma) + k);
                //prodotto con shuffle sul secondo elemento 
                // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al secondo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al secondo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

                //blocco 3
                ymm2 = _mm256_load_ps(a + ((i + 2) * ma) + k);
                //prodotto con shuffle sul terzo elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al terzo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al terzo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

                //blocco 4
                ymm2 = _mm256_load_ps(a + ((i + 3) * ma) + k);
                //prodotto con shuffle sul quarto elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quarto) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quarto) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

                //blocco 5            
                ymm2 = _mm256_load_ps(a + ((i + 4) * ma) + k);
                //prodotto con shuffle sul quinto elemento (il primo della seconda metà)
                xmm0 = _mm256_extractf128_ps(ymm3, 0b00000001); //estraggo la parte alta (128bit) di ymm3

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
                //faccio lo shuffle normale su xmm0 per ottenere in tutti i campi il primo

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al quinto) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al quinto) nella parte alta di ymm1

                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

                //blocco 6
                ymm2 = _mm256_load_ps(a + ((i + 5) * ma) + k);
                //prodotto con shuffle sul sesto elemento 
                // xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3

                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al sesto) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al sesto) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

                //blocco 7
                ymm2 = _mm256_load_ps(a + ((i + 6) * ma) + k);
                //prodotto con shuffle sul settimo elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al settimo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al settimo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

                //blocco 8
                ymm2 = _mm256_load_ps(a + ((i + 7) * ma) + k);
                //prodotto con shuffle sull'ottavo elemento 
                //xmm0 = _mm256_extractf128_ps(ymm3,0b00000000); //estraggo la parte bassa (128bit) di ymm3


                xmm1 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);

                ymm1 = _mm256_insertf128_ps(ymm2, xmm1, 0b00000000); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte bassa di ymm1
                ymm1 = _mm256_insertf128_ps(ymm1, xmm1, 0b00000001); //ricopio xmm1 (con tutti i campi = al ottavo) nella parte alta di ymm1


                ymm2 = _mm256_mul_ps(ymm1, ymm2);
                ymm4 = _mm256_add_ps(ymm2, ymm4);

            }
            _mm256_store_ps(c + ((v) * ma) + z, ymm4);

        }


    }


    return;
}

void matrix_product_cache_oblivious_rec2(MATRIX a, MATRIX b, MATRIX c, int * params_A, int * params_B, int * params_C) {

    int BLOCK = 64;

    if ((params_A[3] <= BLOCK) || (params_A[2] <= BLOCK) || /*(params_B[2] <= BLOCK) || */(params_B[3] <= BLOCK)) {
        matrix_product_avx(a, b, c, params_A, params_B, params_C);
        return;
    }

    //delimita il riquadro delle due matrici

    int start_x_a = params_A[0];
    int start_y_a = params_A[1];
    int end_x_a = params_A[2] + start_x_a;
    int end_y_a = params_A[3] + start_y_a;
    int start_x_b = params_B[0];
    int start_y_b = params_B[1];
    int end_x_b = params_B[2] + start_x_b;
    int end_y_b = params_B[3] + start_y_b;


    int start_x_c = params_C[0];
    int start_y_c = params_C[1];
    //divido in 4 parti A e B in modo che siano orizzontalmente uguali dato che A è trasposta

    int length_x_a = end_x_a - start_x_a;
    int length_y_a = end_y_a - start_y_a;
    int length_x_b = end_x_b - start_x_b;
    int length_y_b = end_y_b - start_y_b;

    int mid_yaxb = length_x_a / 2; //valori relativi
    int xmid_sup_a = length_x_a / 2;
    int ymid_sup_b = length_y_b / 2;

    int padyx = getNecessaryPadding(mid_yaxb);
    int padx = getNecessaryPadding(xmid_sup_a);

    xmid_sup_a += padx;
    mid_yaxb += padyx;
    padx = getNecessaryPadding(ymid_sup_b);
    ymid_sup_b += padx;

    int * pa1 = (int *) get_block(sizeof (int), 7);
    int * pa2 = (int *) get_block(sizeof (int), 7);

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore
    pa1[6] = params_A[6]; //righe matrice originale


    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore
    pa2[6] = params_B[6]; //righe matrice originale

    int * pa3 = (int *) get_block(sizeof (int), 2);

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante A x E


    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)


    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Bx G

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Ax F

    pa1[0] = start_x_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)


    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Bx H


    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)



    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Dx H

    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b + ymid_sup_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = length_y_b - ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c + (ymid_sup_b); // posizione Y da dove iniziare a salvare in C (è pari ad YB)


    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Cx F


    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a + mid_yaxb; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = length_y_a - mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b + mid_yaxb; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = length_x_b - mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Dx G

    pa1[0] = start_x_a + xmid_sup_a; //valore assoluto della posizione di XA
    pa1[1] = start_y_a; //valore assoluto della posizione di YA
    pa1[2] = length_x_a - xmid_sup_a; //altezza della sottomatrice (non posizione finale)
    pa1[3] = mid_yaxb; //lunghezza della sottomatrice
    pa1[4] = length_x_a; //altezza della matrice contenitore
    pa1[5] = length_y_a; // lunghezza della matrice contenitore

    pa2[0] = start_x_b; //valore assoluto della posizione di XB
    pa2[1] = start_y_b; //valore assoluto della posizione di YB
    pa2[2] = mid_yaxb; //altezza della sottomatrice (non posizione finale)
    pa2[3] = ymid_sup_b; //lunghezza della sottomatrice
    pa2[4] = length_x_b; //altezza della matrice contenitore
    pa2[5] = length_y_b; // lunghezza della matrice contenitore

    pa3[0] = start_x_c + xmid_sup_a; // posizione X da dove iniziare a salvare in C (è pari ad XA)
    pa3[1] = start_y_c; // posizione Y da dove iniziare a salvare in C (è pari ad YB)

    matrix_product_cache_oblivious_rec2(a, b, c, pa1, pa2, pa3); //quadrante Cx E

    free_block(pa1);
    free_block(pa2);
    free_block(pa3);
    return;
}

MATRIX matrix_traspose_cache_oblivious(MATRIX a, int m, int n) {
    //int m = MATRIX_HEIGHT, n = MATRIX_WIDTH;
    MATRIX c = alloc_matrix(n, m);
    matrix_traspose_cache_oblivious_rec(a, c, 0, 0, m, n, m, n);
    return c;
}

void matrix_traspose_cache_oblivious_rec(MATRIX a, MATRIX c, int x, int y, int dm, int dn, int m, int n) {
    int BLOCK = 32;
    int UNROLL = 8;
    int VECTORIZATION = 1;

    if ((dm <= BLOCK) && (dn <= BLOCK)) {
        int h, k, u;
        //printf("BLOCCO: dm = %d, dn = %d\n", dm, dn);
        // printf("X = %d, Y = %d\n", x, y);
        int p = UNROLL*VECTORIZATION;
        int v;
        int lx = (((dm) / p) * p) + x;
        int ly = (((dn) / p) * p) + y;

        __m256 ymm0, ymm1, ymm2, ymm3, ymm4, ymm5, ymm6, ymm7,ymm8,ymm9,ymm10,ymm11,ymm12,ymm13,ymm14,ymm15;

        /*__m128 xmm8, xmm9, xmm10, xmm11, xmm12, xmm13, xmm14, xmm15, 
                tmp4, tmp5, tmp6, tmp7;*/

        for (k = x; k < lx; k += p) {
            for (h = y; h < ly; h += p) {
                

                //### LOAD
                ymm0 = _mm256_load_ps(a + k + (m * h));
                ymm1 = _mm256_load_ps(a + k + (m * (h + 1)));
                ymm2 = _mm256_load_ps(a + k + (m * (h + 2)));
                ymm3 = _mm256_load_ps(a + k + (m * (h + 3)));
                ymm4 = _mm256_load_ps(a + k + (m * (h + 4)));
                ymm5 = _mm256_load_ps(a + k + (m * (h + 5)));
                ymm6 = _mm256_load_ps(a + k + (m * (h + 6)));
                ymm7 = _mm256_load_ps(a + k + (m * (h + 7)));

                //### END LOAD
                
                ymm8 = _mm256_shuffle_ps(ymm0,ymm0,0b11100100);
                ymm9 = _mm256_shuffle_ps(ymm0,ymm0,0b11100100);
                ymm10 = _mm256_shuffle_ps(ymm1,ymm1,0b11100100);
                ymm11 = _mm256_shuffle_ps(ymm1,ymm1,0b11100100);
                ymm12 = _mm256_shuffle_ps(ymm4,ymm4,0b11100100);
                ymm13 = _mm256_shuffle_ps(ymm4,ymm4,0b11100100);
                ymm14 = _mm256_shuffle_ps(ymm5,ymm5,0b11100100);
                ymm15 = _mm256_shuffle_ps(ymm5,ymm5,0b11100100);
                ymm8 = _mm256_unpacklo_ps(ymm8,ymm2);
                ymm9 = _mm256_unpackhi_ps(ymm9,ymm2);
                ymm10 = _mm256_unpacklo_ps(ymm10,ymm3);
                ymm11 = _mm256_unpackhi_ps(ymm11,ymm3);
                ymm12 = _mm256_unpacklo_ps(ymm12,ymm6);
                ymm13 = _mm256_unpackhi_ps(ymm13,ymm6);
                ymm14 = _mm256_unpacklo_ps(ymm14,ymm7);
                ymm15 = _mm256_unpackhi_ps(ymm15,ymm7);
                
                ymm0 = _mm256_shuffle_ps(ymm8,ymm8,0b11100100);
                ymm1 = _mm256_shuffle_ps(ymm8,ymm8,0b11100100);
                ymm2 = _mm256_shuffle_ps(ymm9,ymm9,0b11100100);
                ymm3 = _mm256_shuffle_ps(ymm9,ymm9,0b11100100);
                ymm4 = _mm256_shuffle_ps(ymm12,ymm12,0b11100100);
                ymm5 = _mm256_shuffle_ps(ymm12,ymm12,0b11100100);
                ymm6 = _mm256_shuffle_ps(ymm13,ymm13,0b11100100);
                ymm7 = _mm256_shuffle_ps(ymm13,ymm13,0b11100100);
                ymm0 = _mm256_unpacklo_ps(ymm0,ymm10);
                ymm1 = _mm256_unpackhi_ps(ymm1,ymm10);
                ymm2 = _mm256_unpacklo_ps(ymm2,ymm11);
                ymm3 = _mm256_unpackhi_ps(ymm3,ymm11);
                ymm4 = _mm256_unpacklo_ps(ymm4,ymm14);
                ymm5 = _mm256_unpackhi_ps(ymm5,ymm14);
                ymm6 = _mm256_unpacklo_ps(ymm6,ymm15);
                ymm7 = _mm256_unpackhi_ps(ymm7,ymm15);
	
	
                ymm8 = _mm256_shuffle_ps(ymm0,ymm0,0b11100100);
                ymm9 = _mm256_shuffle_ps(ymm1,ymm1,0b11100100);
                ymm10 = _mm256_shuffle_ps(ymm2,ymm2,0b11100100);
                ymm11 = _mm256_shuffle_ps(ymm3,ymm3,0b11100100);
                
                ymm0 = _mm256_permute2f128_ps(ymm0,ymm4,0b00100000);
                ymm4 = _mm256_permute2f128_ps(ymm4,ymm8,0b00010011);
                ymm1 = _mm256_permute2f128_ps(ymm1,ymm5,0b00100000);
                ymm5 = _mm256_permute2f128_ps(ymm5,ymm9,0b00010011);
                ymm2 = _mm256_permute2f128_ps(ymm2,ymm6,0b00100000);
                ymm6 = _mm256_permute2f128_ps(ymm6,ymm10,0b00010011);
                ymm3 = _mm256_permute2f128_ps(ymm3,ymm7,0b00100000);
                ymm7 = _mm256_permute2f128_ps(ymm7,ymm11,0b00010011);


               /* TEST con extract più lento
                xmm8 = _mm256_extractf128_ps(ymm0, 0b0); //parte bassa di ymm0
                xmm9 = _mm256_extractf128_ps(ymm1, 0b0); //parte bassa di ymm1
                xmm10 = _mm_movelh_ps(xmm8, xmm9); // *


                xmm11 = _mm256_extractf128_ps(ymm2, 0b0); //parte bassa di ymm2
                xmm12 = _mm256_extractf128_ps(ymm3, 0b0); //parte bassa di ymm3
                xmm13 = _mm_movelh_ps(xmm11, xmm12); //*

                xmm14 = _mm_shuffle_ps(xmm10, xmm13, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm10, xmm13, 0b11011101); //*
                ymm0 = _mm256_insertf128_ps(ymm0, xmm14, 0b0);
                ymm1 = _mm256_insertf128_ps(ymm1, xmm15, 0b0);

                xmm10 = _mm_movehl_ps(xmm9, xmm8); // *
                xmm13 = _mm_movehl_ps(xmm12, xmm11); // *

                xmm14 = _mm_shuffle_ps(xmm10, xmm13, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm10, xmm13, 0b11011101); //*
                ymm2 = _mm256_insertf128_ps(ymm2, xmm14, 0b0);
                ymm3 = _mm256_insertf128_ps(ymm3, xmm15, 0b0);


                tmp4 = _mm256_extractf128_ps(ymm4, 0b0);
                tmp5 = _mm256_extractf128_ps(ymm5, 0b0);
                tmp6 = _mm256_extractf128_ps(ymm6, 0b0);
                tmp7 = _mm256_extractf128_ps(ymm7, 0b0);


                xmm8 = _mm256_extractf128_ps(ymm0, 0b1); //parte alta di ymm0
                xmm9 = _mm256_extractf128_ps(ymm1, 0b1); //parte alta di ymm1
                xmm10 = _mm_movelh_ps(xmm8, xmm9); // *

                xmm11 = _mm256_extractf128_ps(ymm2, 0b1); //parte alta di ymm2
                xmm12 = _mm256_extractf128_ps(ymm3, 0b1); //parte alta di ymm3
                xmm13 = _mm_movelh_ps(xmm11, xmm12); //*

                xmm14 = _mm_shuffle_ps(xmm10, xmm13, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm10, xmm13, 0b11011101); //*
                ymm4 = _mm256_insertf128_ps(ymm4, xmm14, 0b0);
                ymm5 = _mm256_insertf128_ps(ymm5, xmm15, 0b0);

                xmm10 = _mm_movehl_ps(xmm9, xmm8); // *
                xmm13 = _mm_movehl_ps(xmm12, xmm11); // *

                xmm14 = _mm_shuffle_ps(xmm10, xmm13, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm10, xmm13, 0b11011101); //*
                ymm6 = _mm256_insertf128_ps(ymm6, xmm14, 0b0);
                ymm7 = _mm256_insertf128_ps(ymm7, xmm15, 0b0);


                xmm8 = _mm_movelh_ps(tmp4, tmp5);
                xmm9 = _mm_movelh_ps(tmp6, tmp7); //*

                xmm14 = _mm_shuffle_ps(xmm8, xmm9, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm8, xmm9, 0b11011101); //*
                ymm0 = _mm256_insertf128_ps(ymm0, xmm14, 0b1);
                ymm1 = _mm256_insertf128_ps(ymm1, xmm15, 0b1);

                xmm8 = _mm_movehl_ps(tmp5, tmp4); // *
                xmm9 = _mm_movehl_ps(tmp7, tmp6); // *

                xmm14 = _mm_shuffle_ps(xmm8, xmm9, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm8, xmm9, 0b11011101); //*
                ymm2 = _mm256_insertf128_ps(ymm2, xmm14, 0b1);
                ymm3 = _mm256_insertf128_ps(ymm3, xmm15, 0b1);

                xmm8 = _mm256_extractf128_ps(ymm4, 0b1); //parte alta di ymm4
                xmm9 = _mm256_extractf128_ps(ymm5, 0b1); //parte alta di ymm5
                xmm10 = _mm_movelh_ps(xmm8, xmm9); // *

                xmm11 = _mm256_extractf128_ps(ymm6, 0b1); //parte alta di ymm6
                xmm12 = _mm256_extractf128_ps(ymm7, 0b1); //parte alta di ymm7
                xmm13 = _mm_movelh_ps(xmm11, xmm12); //*

                xmm14 = _mm_shuffle_ps(xmm10, xmm13, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm10, xmm13, 0b11011101); //*
                ymm4 = _mm256_insertf128_ps(ymm4, xmm14, 0b1);
                ymm5 = _mm256_insertf128_ps(ymm5, xmm15, 0b1);

                xmm10 = _mm_movehl_ps(xmm9, xmm8); // *
                xmm13 = _mm_movehl_ps(xmm12, xmm11); // *

                xmm14 = _mm_shuffle_ps(xmm10, xmm13, 0b10001000); //*
                xmm15 = _mm_shuffle_ps(xmm10, xmm13, 0b11011101); //*
                ymm6 = _mm256_insertf128_ps(ymm6, xmm14, 0b1);
                ymm7 = _mm256_insertf128_ps(ymm7, xmm15, 0b1);*/


                //### STORE
                _mm256_store_ps(c + (k * n) + h,ymm0);
                _mm256_store_ps(c + ((k + 1) * n) + h,ymm1);
                _mm256_store_ps(c + ((k + 2) * n) + h,ymm2);
                _mm256_store_ps(c + ((k + 3) * n) + h,ymm3);
                _mm256_store_ps(c + ((k + 4) * n) + h,ymm4);
                _mm256_store_ps(c + ((k + 5) * n) + h,ymm5);
                _mm256_store_ps(c + ((k + 6) * n) + h,ymm6);
                _mm256_store_ps(c + ((k + 7) * n) + h,ymm7);
                //### END STORE      

            }
        }
        //printMatrix(c,n,m); 
        //printf("FINE BLOCCO: dm = %d, dn = %d\n", dm, dn);
        //printf("X = %d, Y = %d\n", x, y);
        return;
    }

    if (dm >= dn) {
        int xmid = dm / 2;
        int pad = getNecessaryPadding(xmid);
        xmid += pad;
        matrix_traspose_cache_oblivious_rec(a, c, x, y, xmid, dn, m, n);
        matrix_traspose_cache_oblivious_rec(a, c, x + xmid, y, dm - xmid, dn, m, n);
        return;
    } else {
        int ymid = dn / 2;
        int pad = getNecessaryPadding(ymid);
        ymid += pad;
        matrix_traspose_cache_oblivious_rec(a, c, x, y, dm, ymid, m, n);
        matrix_traspose_cache_oblivious_rec(a, c, x, y + ymid, dm, dn - ymid, m, n);
        return;
    }
}

void matrix_inverse_lu_avx(const MATRIX c, MATRIX b, int size, int pad) {

    MATRIX a;
    float m, pivot, det;
    int i, j, k;
    int n = size - pad;



    /* Uso una matrice di appoggio `a'	
     b è la matrice identità		
     */
    a = alloc_matrix(size, size);

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            a[(i * size) + j] = c[(i * size) + j];
            //b[(i*size)+j] = 0.0;
        }
        b[(i * size) + i] = 1.0;
    }

    /* Ax = b  ->  LUx = b  ->  Ux = inv(L)b		*/
    /* moltiplica per l'inversa di L	*/
    int pos_pivot;
    int UNROLL = 8;
    int VECTORIZATION = 8;
    int length = (n / UNROLL) * UNROLL;
    __m128 xmm0;
    int pos1, pos2;
    pos1 = k*size;
    __m256 ymm0,ymm1,ymm2,ymm3,zero_sign, min_pivot;

    zero_sign = _mm256_set1_ps(-0.0);
    min_pivot = _mm256_set1_ps(5e-16);
    int h = 0;
    int vmask;
    for (k = 0; k < n; k += UNROLL, h++) { //the loop step are UNROLL! single increments are done inside


        //blocco 1
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b0);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }

         //blocco 2
        h++;
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b0);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }

        //blocco 3
        h++;
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b0);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }
        
        //blocco 4
        h++;
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b0);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }
       //blocco 5
        h++;
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b1);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }
        
        //blocco 6
        h++;
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b1);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }
        
        //blocco 7
        h++;
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b1);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }
        //blocco 8
        h++;
        ymm0 = _mm256_load_ps(a + (h * size) + k);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

        

        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }

        for (i = h + 1; i < n; i++) {
            ymm1 = _mm256_load_ps(a + (i * size) + k);
            xmm0 = _mm256_extractf128_ps(ymm1,0b1);
            xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111);
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
            ymm1 = _mm256_insertf128_ps(ymm1, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1

            ymm1 = _mm256_div_ps(ymm1, ymm0); // m = a[(i * size) + k] / pivot;

            int b_steps = (int) floor(h / VECTORIZATION);

            for (j = 0; j <= b_steps; j++) {
                //in every step are loaded 8 elements
                ymm2 = _mm256_load_ps(b + (i * size)+(j * VECTORIZATION));
                ymm3 = _mm256_load_ps(b + (h * size)+(j * VECTORIZATION));
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3); //b[(i * size) + j] -= m * b[(k * size) + j];
                _mm256_store_ps(b + (i * size)+(j * VECTORIZATION), ymm2);
            }
            for (j = k; j < n; j += VECTORIZATION) {
                ymm2 = _mm256_load_ps(a + (i * size) + j);
                ymm3 = _mm256_load_ps(a + (h * size) + j);
                ymm3 = _mm256_mul_ps(ymm1, ymm3);
                ymm2 = _mm256_sub_ps(ymm2, ymm3);
                _mm256_store_ps(a + (i * size) + j, ymm2); //a[(i * size) + j] -= m * a[(k * size) + j];

            }


        }





        /*  for (i = k + 1; i < n; i++) {
              m = a[(i * size) + k] / pivot;
              for (j = 0; j <= k; j++)
                  b[(i * size) + j] -= m * b[(k * size) + j];
              for (j = k; j < n; j++)
                  a[(i * size) + j] -= m * a[(k * size) + j];
          }*/
    }
    /*printf("MATRICE A\n");
    printMatrix(a,size,size);
    printf("MATRICE B\n");
    printMatrix(b,size,size);*/

    /* Ux = inv(L)b  ->  x = inv(U)(inv(L)b)	
      moltiplica per inv(U)= sostituzione all'indietro    	
     Det *= elemU[i][i]	
     */
   // det = 1.0;
    h=n-1;
    float tmp ;
    int pos_block;
    for (i = n - 1; i >= 0; i -= UNROLL,h--) {
        
        //blocco 1
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
        
        //blocco 2
        h--;
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
         //blocco 3
        h--;
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
         //blocco 4        
        h--;
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b1);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
        
        //blocco 5
        h--;
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b11111111); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
        
        //blocco 6
        h--;
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b10101010); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
        //blocco 7
        h--;
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b01010101); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
        //blocco 8
        h--;
        pos_block = (int)floor(i/VECTORIZATION);
        pos_block*=VECTORIZATION;
        ymm0 = _mm256_load_ps(a + (h * size) + pos_block);
        xmm0 = _mm256_extractf128_ps(ymm0,0b0);
        xmm0 = _mm_shuffle_ps(xmm0, xmm0, 0b00000000); //pivot
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000000); //ricopio xmm0 (con tutti i campi = al primo) nella parte bassa di ymm1
        ymm0 = _mm256_insertf128_ps(ymm0, xmm0, 0b00000001); //ricopio xmm0 (con tutti i campi = al primo) nella parte alta di ymm1


        //if (fabs(pivot) < 5e-16) return 0.0;
        ymm1 = _mm256_andnot_ps(zero_sign, ymm0); //absolute value
        ymm1 = _mm256_cmp_ps(ymm1, min_pivot,0b00000001); //cmplt
        vmask = _mm256_movemask_ps(ymm1);
        if (vmask != 0) {
            break;
        }     
        //det*=a[(h*size)+h];
        
        for(k=0;k<n;k+=VECTORIZATION){
            ymm1 = _mm256_load_ps(b + (h * size) + k);//m
            for (j = h + 1; j < n; j++){//ciclo resto e multiplo
                tmp = a[(h*size)+j];
                ymm2 = _mm256_set1_ps(tmp);
                ymm3 = _mm256_load_ps(b+(j*size)+k);
                ymm3 = _mm256_mul_ps(ymm2,ymm3);
                ymm1 = _mm256_sub_ps(ymm1,ymm3);// m -= a[(i * size) + j] * b[(j * size) + k];
            }
            ymm1 = _mm256_div_ps(ymm1,ymm0);//m / pivot;
            _mm256_store_ps(b+(h*size)+k,ymm1);
            
           
        }
        
    }

    dealloc_matrix(a);

   // return det;
}

/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX X, VECTOR Y, VECTOR beta, int m, int n) {
    int i, j;
    /*printf("Y=\n");
    printMatrix(Y, m, 1);
    printf("BETA=\n");
    printMatrix(beta, n, 1);*/
	int size_m = m-ROW_PADDING;
	int size_n = n-COL_PADDING;

	//printf("M = %d, N= %d\n",m,n);
//printf("MATRIX_HEIGHT = %d, MATRIX_WIDTH= %d\n",MATRIX_HEIGHT,MATRIX_WIDTH);
    float err = 0, de, yp;

    for (i = 0; i < size_m; i++) {
        yp = 0;
        for (j = 0; j < size_n; j++) {
            // printf("\t%d)yp=%f*%f = ",j,X[(j * m) + i],beta[j]);
            yp += X[(j * m) + i] * beta[j];
            //printf("%f\n",yp);
        }
        //printf("%d)de=fabs(%f-%f) = ",i,Y[i],yp);
        de = fabs(Y[i] - yp);
        //printf("%f\n",de);
        err += (de * de);
    }
    return err / (size_m * size_n);
}

void printMatrixXy(MATRIX Xy, int m, int n, VECTOR Y) {



    int i, j;
    for (i = 0; i < (m); i++) {
        printf("\n%d) ", i);
        for (j = 0; j < (n); j++) {
            printf("%f ", Xy[(j * m) + i]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }

        printf("Y=%f", Y[i % m]);
    }

    printf("\n\n================================================\n\n");
}

void saveMatrix(MATRIX a, VECTOR Y, int m, int n, char * filename) {
    FILE * fp;
    fp = fopen(filename, "w");

    int i, j;
    for (i = 0; i < (m); i++) {
        fprintf(fp, "\n%d) ", i);
        for (j = 0; j < (n); j++) {
            fprintf(fp, "%f ", a[(j * m) + i]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }

        fprintf(fp, "Y=%f", Y[i % m]);
    }
    //fprintf(fp, "Y=%f", Y[i % m]);
    fclose(fp);

}

void saveMatrixNoPadding(MATRIX a, VECTOR Y, int m, int n, char * filename) {
    FILE * fp;
    fp = fopen(filename, "w");
    /*int size_m, size_n;
    getSizeWithPadding(m, n, &size_m, &size_n);*/
    int i, j;
    for (i = 0; i < (m); i++) {
        fprintf(fp, "\n%d) ", i);
        for (j = 0; j < (n); j++) {
            if (j == (n)) {
                j += COL_PADDING - 1;
                continue;
            }
            fprintf(fp, "%f ", a[i * (MATRIX_WIDTH) + j]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }
        if (i < m)
            fprintf(fp, "Y=%f", Y[i % m]);
    }
    fclose(fp);

}

void printMatrix(MATRIX a, int m, int n) {
    int i, j;
    for (i = 0; i < (m); i++) {
        printf("\n%d) ", i);
        for (j = 0; j < (n); j++) {
            printf("%f\t", a[(j * m) + i]);
            //printf("SCRITTO A[%d,%d]=%f\n", i,j, a[i *(size_n+1)+ j]);
        }

    }

    printf("\n\n================================================\n\n");
}

int equalsMatrix(MATRIX a, MATRIX b, int n, int m) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            if (a[(j * m) + i] != b[(j * m) + i]) {
                printf("Elemento diverso in: %d,%d :\n a= %f - b= %f\n", i, j, a[(j * m) + i], b[(j * m) + i]);
                return 0;
            }
        }
    }
    return 1;
}

void getPaddingNumberRC(int m, int n, int * n_rows, int * n_cols) {
    * n_rows = ROW_PADDING;
    * n_cols = COL_PADDING;
}

int getNecessaryPadding(int length) {
    int MULT = 8;
    return (length % MULT) == 0 ? 0 : MULT - (length % MULT);
}

void setPaddingNumberRC(int m, int n) {
    int MULT = 8;
    ROW_PADDING = (m % MULT) == 0 ? 0 : MULT - (m % MULT);
    COL_PADDING = (n % MULT) == 0 ? 0 : MULT - (n % MULT);
    MATRIX_HEIGHT = m + ROW_PADDING;
    MATRIX_WIDTH = n + COL_PADDING;
}

void getSizeWithPadding(int m, int n, int * p_m, int * p_n) {
    int pm, pn;
    getPaddingNumberRC(m, n, &pm, &pn);
    * p_m = m + (pm);
    * p_n = n + (pn);
}

MATRIX fromRowToColumnMajor(MATRIX a, int m, int n) {
    MATRIX tmp = (MATRIX) alloc_matrix(m, n);
    int i, j, k, h;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            k = i + (j * m);
            h = (i * n) + j;
            tmp[k] = a[h];

        }
    }
    //dealloc_matrix(tmp);
    return tmp;




}

MATRIX fromColumnToRowMajor(MATRIX a, int m, int n) {
    MATRIX tmp = (MATRIX) alloc_matrix(m, n);
    int i, j, k, h;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            k = i + (j * m);
            h = (i * n) + j;
            tmp[h] = a[k];

        }
    }
    //dealloc_matrix(tmp);
    return tmp;




}

void printMatrixAsArray(MATRIX a, int m, int n) {
    int i;
    for (i = 0; i < m * n; i++) {
        printf("%f\t", a[i]);
    }
    printf("\n");
}





/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_12.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/




int main(int argc, char** argv) {
    int m = 10;
    int n = 2;
    MATRIX X;
    VECTOR Y;
    VECTOR beta;

    char* filename = "";
    int silent = 0, display = 0, fsave = 0;
    int i,j;

    srandom(time(NULL));

    int par = 1;
    while (par < argc) {
        if (strcmp(argv[par], "-l") == 0) {
            par++;
            if (par < argc) {
                filename = argv[par];
                par++;
            }
        } else if (strcmp(argv[par], "-r") == 0) {
            par++;
            if (par < argc) {
                m = atoi(argv[par]);
                par++;
                if (par < argc) {
                    n = atoi(argv[par]);
                    par++;
                }
            }
        } else if (strcmp(argv[par], "-f") == 0) {
            fsave = 1;
            par++;
        } else if (strcmp(argv[par], "-s") == 0) {
            silent = 1;
            par++;
        } else if (strcmp(argv[par], "-d") == 0) {
            display = 1;
            par++;
        } else
            par++;
    }

    if (!silent) {
        printf("linreg64\n");
        printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
        printf("\nParameters:\n");
        printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
        printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
        printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
        printf("\t-d : displays input and output\n");
        printf("\t-s : silent\n");
    }

    if (strlen(filename) == 0)
        X = random_input(m, n, &Y);
    else
        X = load_input(filename, &m, &n, &Y);

    if (!silent && display) {
        printf("\nInput augmented matrix:\n");
        for (i = 0; i < m; i++) {		
            for(j=0;j<n;j++){
		printf("%.3f ",X[(j*MATRIX_HEIGHT)+i]);		
		}
		printf("%.3f\n",Y[i]);
		
        }
        printf("\n");
    }

	if (!silent)
        printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
    //printMatrix(Y,m,1);
    //saveMatrix(X,Y,m,n,"matriceX.txt");
    clock_t t = clock();
    beta = linreg(X, Y, MATRIX_HEIGHT, MATRIX_WIDTH);
    t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

    if (!silent)
        printf("\nExecution time = %.3f seconds\n", ((float) t) / CLOCKS_PER_SEC);
    else
        printf("%.3f\n", ((float) t) / CLOCKS_PER_SEC);

    if (!silent && display) {
        printf("\nOutput coefficient vector:\n");
        for (i = 0; i < n; i++)
            printf("%.3f ", beta[i]);
        printf("\n");
    }

    float err = error(X, Y, beta, MATRIX_HEIGHT, MATRIX_WIDTH);
    if (!silent)
        printf("\nThe error is %f.\n", err);
    else
        printf("%.3f\n", err);

    if (strlen(filename) == 0 && fsave)
        save_input("last.mat", X, MATRIX_HEIGHT, MATRIX_WIDTH, Y);
    return EXIT_SUCCESS;
}
