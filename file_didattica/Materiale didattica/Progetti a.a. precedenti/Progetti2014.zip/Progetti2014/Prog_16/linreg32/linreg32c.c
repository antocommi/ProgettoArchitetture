/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*

void print_vector(VECTOR X,int n);

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand()-0.5;
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand()-0.5;
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y;
		//*(1+frand()*e-e/2);
	}
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}

void print_matrix(MATRIX x,int m,int n){
    int i,j;
	printf("Matrix Print:\n");
    for( i=0;i<m;i++){
        for( j=0;j<n;j++)
            printf("%f\t ",x[i*(n)+j]);
        printf("\n");
    }
}

void print_vector(VECTOR x,int n){
    int i;
	printf("Vector Print:\n");
    for(i=0;i<n;i++)
        printf("%f\n",x[i]);
}

MATRIX trasposta(MATRIX x,int m,int n){
    int i,j;
	MATRIX x_t = alloc_matrix(n,m);
    for(i=0;i<m;i++)
        for( j=0;j<n;j++)
            x_t[i+j*m]=x[i*(n)+j];
    return x_t;
}

MATRIX trasposta2(MATRIX x,int m,int n){
    MATRIX x_t = alloc_matrix(n,m);
    transpose(x,x_t,m,n);
    return x_t;
}


void transpose4x4_SSE(MATRIX A, MATRIX B, const int lda, const int ldb){
    __m128 tmp3, tmp2, tmp1, tmp0;
    __m128 row0 = _mm_load_ps(&A[0*lda]);
    __m128 row1 = _mm_load_ps(&A[1*lda]);
    __m128 row2 = _mm_load_ps(&A[2*lda]);
    __m128 row3 = _mm_load_ps(&A[3*lda]);
    tmp0 = _mm_unpacklo_ps((row0), (row1));
    tmp2 = _mm_unpacklo_ps((row2), (row3));
    tmp1 = _mm_unpackhi_ps((row0), (row1));
    tmp3 = _mm_unpackhi_ps((row2), (row3));
    row0 = _mm_movelh_ps(tmp0, tmp2);
    row1 = _mm_movehl_ps(tmp2, tmp0);
    row2 = _mm_movelh_ps(tmp1, tmp3);
    row3 = _mm_movehl_ps(tmp3, tmp1);
    _mm_store_ps(&B[0*ldb], row0);
    _mm_store_ps(&B[1*ldb], row1);
    _mm_store_ps(&B[2*ldb], row2);
    _mm_store_ps(&B[3*ldb], row3);
}
/*
 * limitazioni: matrici mxn con m ed n multipli di 4
 * lda e ldb indici rispettivamente riga e colonna della matrice trasposta
 */
MATRIX transpose_block_SSE4x4(MATRIX A, const int m, const int n, const int lda, const int ldb ,const int block_size) {
    int i2,j,i,j2;
	MATRIX B=alloc_matrix(n, m);
//    #pragma omp parallel for
    for(i=0; i<m; i+=block_size) {
        for(j=0; j<n; j+=block_size) {
            int max_i2 = i+block_size < m ? i + block_size : m;
            int max_j2 = j+block_size < n ? j + block_size : n;
            for(i2=i; i2<max_i2; i2+=4) {
                for( j2=j; j2<max_j2; j2+=4) {
                    //vengono effettuate m*n/(4*4) operazioni di trasposta
                 transpose4x4_SSE(&A[i2*lda+j2],&B[j2*ldb+i2],lda,ldb);
                }
            }
        }
    }
    return B;
}

/*
 * Si presuppone già che vi siano le condizioni necessarie per effettuare un prodotto vettoriale
 * a=row*inner
 * b=inner*col
 * c=row*col
 */
MATRIX prod_row_row(MATRIX a,MATRIX b, const int row, const int col,const int inner){
    int i,j,k;
	MATRIX c=alloc_matrix(row,col);
	 for(i=0;i<row;i++)
        for(j=0;j<col;j++){
            float t=0;
            for(k=0;k<inner;k++)
                t+=a[i*inner+k]*b[j*inner+k];
            c[i*col+j]=t;
        }
    return c;
}
/*
 * Si presuppone già che vi siano le condizioni necessarie per effettuare un prodotto vettoriale
 * a=row*inner
 * b=inner*col
 * c=row*col
 */
MATRIX prod_row_row2(MATRIX a,MATRIX b, const int row, const int col,const int inner){
    MATRIX c=alloc_matrix(row,col);
   productSSE(a,b,c,row,col,inner);
    return c;
}

void divideRow(MATRIX a,MATRIX b,int pivot,int n,float div){
    int i;
    for(i=0;i<n;i++){
        a[pivot*n+i]=a[pivot*n+i]/div;
        b[pivot*n+i]=b[pivot*n+i]/div;
    }
}

void sumRow(MATRIX a,MATRIX b,int pivot,int row,int n,float mul){
    int i;
    float tmp=mul/a[pivot*n+pivot];
    mul=tmp;
    for(i=0;i<n;i++){
        a[row*n+i]=a[row*n+i]-a[pivot*n+i]*mul;
        b[row*n+i]=b[row*n+i]-b[pivot*n+i]*mul;
    }
}
void swapRows(MATRIX a,MATRIX b,int row,int swap,int n){
	int i=0;
	float tmp;
	for(i=0;i<n;i++){
		tmp=a[row*n+i];
		a[row*n+i]=a[swap*n+i];
		a[swap*n+i]=tmp;
		tmp=b[row*n+i];
		b[row*n+i]=b[swap*n+i];
		b[swap*n+i]=tmp;
	}
}
MATRIX inv(MATRIX a,int n){
    MATRIX b=alloc_matrix(n, n);
    int i,j;
    int swap;
    float tmp;
    for(i=0;i<n;i++)
        b[i*n+i]=1;
    for(i=0;i<n;i++){
        tmp=a[i*n+i];
        swap=i;
        for(j=i+1;j<n;j++){
            if(a[j*n+i]<=tmp)
                continue;
            tmp=a[j*n+i];
            swap=j;
        }
        if(swap!=i)
            swapRows(a,b,i,swap,n);
        for(j=i+1;j<n;j++){
            tmp=a[j*n+i];
            if(tmp==0)
                continue;
            sumRow(a,b,i,j,n,tmp);
        }
        for(j=i-1;j>=0;j--){
            tmp=a[j*n+i];
            if(tmp==0)
                continue;
            sumRow(a,b,i,j,n,tmp);
        }
	}
     for(i=0;i<n;i++){
	  tmp=a[i*n+i];
        if(tmp==1)
	    continue;
	divideRow(a,b,i,n,tmp);}
    return b;
}


/*
 *	lilinreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg (MATRIX x,VECTOR y, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);
    MATRIX xt=alloc_matrix(n,m);
	MATRIX x2=alloc_matrix(n,m);
	MATRIX xx=alloc_matrix(n,n);
    MATRIX inv2=alloc_matrix(n,n);
    transpose(x,xt, m, n);   
    productSSE(xt, xt,xx, n, n, m); //xx è una matrice n*n
    inverse(xx,inv2,n);
	productSSE(inv2, x,x2, n, m, n); //x2 è una matrice n*m   
 productSSE(x2,y,beta,n,1,m);
/*    free(y);
    free(inv);
    free(xt);
    free(x2);
    free(xx);
*/
    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;

	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}

MATRIX generate_sequence_number(int m,int n){
    int i;
	MATRIX X=alloc_matrix(m, n);
    for(i=0;i<m*n;i++)
        X[i]=i;
    return X;
}
/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_16.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/

void main(int argc, char** argv) {
	int m = 12800;
	int n = 12800;
	MATRIX Xy;
	VECTOR beta;

	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;

	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0){
		Xy = random_input(m,n);
    }  	else
		Xy = load_input(filename, &m, &n);
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}
    


    //getXY
    int cx=0,cy=0;
    MATRIX x=alloc_matrix(m, n);;
    VECTOR y=get_block(sizeof(float), m);
    for(cx=0,cy=0,i=0;i<m*(n+1);i++)
        if((i+1)%(n+1)==0){
            y[cy]=Xy[i];
            cy++;
        }else{
            x[cx]=Xy[i];
            cx++;
        }
    //getXY
//	print_matrix(x,m,n);
//	print_matrix(y,m,1);



	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock();
	beta=linreg(x,y,m,n);
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/
	
	
	
	print_vector(beta, n);
	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err/(m*n));
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
