/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 30 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 linreg64.nasm && gcc -O3 -m64 -mavx linreg64.o linreg64c.c -o linreg64c && ./linreg64c
 
 oppure
 
 ./runlinreg64

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*

static int loop=0;

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,32); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


MATRIX estraiMatrice(MATRIX Xy, int m, int n) {
	int i, j,y;
	MATRIX A = alloc_matrix(m,n);
        y=0;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
		     //printf("%i",(i*n+j+y)); 
	             //printf (" ");
	 	     A[i*(n)+j]=Xy[i*n+j+y];
		}
		y++;
		
	}
	return A;
}

void stampaMatrice(MATRIX A,int righe, int colonne){
	int i,j;
	for(i=0;i<righe;i++) {
	  for(j=0;j<colonne;j++){
		printf ("%f", A[i*righe+j]);
		printf (",");
	 }
	printf("\n");	
	}	
	

}
MATRIX prodMatrixRowCacheUnroll(MATRIX A, MATRIX B, int righeA, int colonneB, int RC, int block_size){//FUNZIONA
	MATRIX Prod = alloc_matrix(righeA,colonneB);         
	int i,j,k,ii,jj,kk;        
	int unroll=10;
        for (i=0;i<righeA;i+=block_size) {
            for (j=0;j<colonneB;j+=block_size) {
                for(k=0;k<RC;k+=block_size){
                    for (ii=i; ii<i+block_size; ii++) {
			for (jj=j; jj<j+block_size; jj++){
                            for (kk=k; kk<k+block_size; kk+=unroll) {
				
				Prod[(ii*colonneB)+jj]+=A[(ii*RC)+kk]*B[(kk*colonneB)+jj];
                                Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+1)]*B[((kk+1)*colonneB)+jj];
                                Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+2)]*B[((kk+2)*colonneB)+jj];
                                Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+3)]*B[((kk+3)*colonneB)+jj];
                                Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+4)]*B[((kk+4)*colonneB)+jj];
				Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+5)]*B[((kk+5)*colonneB)+jj];
                                Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+6)]*B[((kk+6)*colonneB)+jj];
                                Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+7)]*B[((kk+7)*colonneB)+jj];
                                Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+8)]*B[((kk+8)*colonneB)+jj];
				Prod[(ii*colonneB)+jj]+=A[(ii*RC)+(kk+9)]*B[((kk+9)*colonneB)+jj];
                            }
                        }
                    }
                }
            }
        }
        return Prod;
    }

MATRIX prodMatrixVectorRowCacheUnroll(MATRIX A, MATRIX B, int righeA,int RC, int block_size){//FUNZIONA
        VECTOR C = get_block(sizeof(float),righeA);
	int i,k,ii,kk;         
        int unroll=10;
        for (i=0;i<righeA;i+=block_size) {
            for(k=0;k<RC;k+=block_size){
                 for (ii=i; ii<i+block_size; ii++) {
			for (kk=k; kk<k+block_size; kk+=unroll) {
				C[ii]+=A[(ii*RC)+kk]*B[kk];
                                C[ii]+=A[(ii*RC)+(kk+1)]*B[kk+1];
                                C[ii]+=A[(ii*RC)+(kk+2)]*B[kk+2];
                                C[ii]+=A[(ii*RC)+(kk+3)]*B[kk+3];
                                C[ii]+=A[(ii*RC)+(kk+4)]*B[kk+4];
				C[ii]+=A[(ii*RC)+(kk+5)]*B[kk+5];
				C[ii]+=A[(ii*RC)+(kk+6)]*B[kk+6];
				C[ii]+=A[(ii*RC)+(kk+7)]*B[kk+7];
				C[ii]+=A[(ii*RC)+(kk+8)]*B[kk+8];
				C[ii]+=A[(ii*RC)+(kk+9)]*B[kk+9];
                        }
               	 }
     	   }
        }
            
        
        return C;
    }


MATRIX inversaOpt(MATRIX a, int n,int block_size) {//FUNZIONA
        int unroll=10;
	int i,j,k,kk;
	MATRIX x = alloc_matrix(n,n);  
	MATRIX b = alloc_matrix(n,n);
	int* index = calloc(n,sizeof(int));
        for (i=0; i<n; ++i)
            b[(i*n)+i] = 1;

        gaussianOpt(a, index,n,block_size,unroll);
        
        
        for (i=0; i<n-1; i++){
            for (j=i+1; j<n; j++){
                for (k=0; k<n; k+=block_size){
                    for (kk=k; kk<k+block_size; kk+=unroll) {
                          b[(index[j]*n)+kk]-= a[(index[j]*n)+i]*b[(index[i]*n)+kk];
                          b[(index[j]*n)+(kk+1)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+1)];
			  b[(index[j]*n)+(kk+2)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+2)];
			  b[(index[j]*n)+(kk+3)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+3)];
			  b[(index[j]*n)+(kk+4)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+4)];
			  b[(index[j]*n)+(kk+5)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+5)];
			  b[(index[j]*n)+(kk+6)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+6)];
			  b[(index[j]*n)+(kk+7)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+7)];
			  b[(index[j]*n)+(kk+8)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+8)];
  			  b[(index[j]*n)+(kk+9)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+9)];
                    }      
                }
            }
        }
        
        for (i=0; i<n; ++i) {
            x[((n-1)*n)+i] = b[(index[n-1]*n)+i]/a[(index[n-1]*n)+(n-1)];
            for (j=n-2; j>=0; --j) {
                x[(j*n)+i] = b[(index[j]*n)+i];
                for (k=j+1; k<n; ++k) {
                    x[(j*n)+i] -= a[(index[j]*n)+k]*x[(k*n)+i];
                }
                x[(j*n)+i] /= a[(index[j]*n)+j];
            }
	
        }
        return x; 
    }

 void gaussianOpt(MATRIX a,int* index,int n,int block_size,int unroll) {
        int i,ii,j,jj,k,l;
        VECTOR c= get_block(sizeof(float),n);

         for (i=0;i<n;i+=block_size) {
            for (ii=i; ii<i+block_size; ii+=unroll) {
                index[ii] = ii;
                index[ii+1] = ii+1;
                index[ii+2] = ii+2;
                index[ii+3] = ii+3;
                index[ii+4] = ii+4;
		index[ii+5] = ii+5;
		index[ii+6] = ii+6;
		index[ii+7] = ii+7;
		index[ii+8] = ii+8;
		index[ii+9] = ii+9;
            }
        }
        
        for (i=0; i<n; i+=block_size) {
            for (ii=i; ii<i+block_size; ii++) {
                float c1 = 0;
                for (j=0; j<n; j+=block_size) {
                    for (jj=j; jj<j+block_size;jj+=unroll){
                        float c00 = a[(ii*n)+jj]; //1° unroll
                        if(c00<0)
                            c00*=-1;
                        if (c00 > c1) 
                            c1 = c00;
                        float c01 = a[(ii*n)+(jj+1)]; //2° unroll
                        if(c01<0)
                            c01*=-1;
                        if (c01 > c1) 
                            c1 = c01;
			float c02 = a[(ii*n)+(jj+2)]; //3° unroll
                        if(c02<0)
                            c02*=-1;
                        if (c02 > c1) 
                            c1 = c02;
			float c03 = a[(ii*n)+(jj+3)]; //4° unroll
                        if(c03<0)
                            c03*=-1;
                        if (c03 > c1) 
                            c1 = c03;
			float c04 = a[(ii*n)+(jj+4)]; //5° unroll
                        if(c04<0)
                            c04*=-1;
                        if (c04 > c1) 
                            c1 = c04; 
			float c05 = a[(ii*n)+(jj+5)]; //6° unroll
                        if(c05<0)
                            c05*=-1;
                        if (c05 > c1) 
                            c1 = c05; 
			float c06 = a[(ii*n)+(jj+6)]; //7° unroll
                        if(c06<0)
                            c06*=-1;
                        if (c06 > c1) 
                            c1 = c06; 
			float c07 = a[(ii*n)+(jj+7)]; //8° unroll
                        if(c07<0)
                            c07*=-1;
                        if (c07 > c1) 
                            c1 = c07; 
			float c08 = a[(ii*n)+(jj+8)]; //9° unroll
                        if(c08<0)
                            c08*=-1;
                        if (c08 > c1) 
                            c1 = c08; 
			float c09 = a[(ii*n)+(jj+9)]; //10° unroll
                        if(c09<0)
                            c09*=-1;
                        if (c09 > c1) 
                            c1 = c09; 

                        
                    }
                }
                c[ii] = c1;
            }
        }

        k = 0;
        for (j=0; j<n-1; ++j) {
            float pi1 = 0;
            for (i=j; i<n; ++i) {
                float pi0 = a[(index[i]*n)+j];
                if(pi0<0)
                    pi0*=-1;
                pi0 /= c[index[i]];
                if (pi0 > pi1) {
                    pi1 = pi0;
                    k = i;
                }
            }

            int itmp = index[j];
            index[j] = index[k];
            index[k] = itmp;
            for (i=j+1; i<n; ++i) {
                float pj = a[(index[i]*n)+j]/a[(index[j]*n)+j];
                a[(index[i]*n)+j] = pj;
                for (l=j+1; l<n; ++l)
                    a[(index[i]*n)+l] -= pj*a[(index[j]*n)+l];
            }
        }
    }

MATRIX calcTraspostaCacheUnroll(MATRIX A,int m, int n, int block_size){//FUNZIONA
	MATRIX TRASPOSTA = alloc_matrix(n,m);        
	int i,j,jj;        
	int cont=0;
        int unroll=10;
       
        for (i=0; i< n; i++) {
            for (j=0; j< m; j+=block_size) {
                for (jj=j; jj<j+block_size; jj+=unroll){ 
                    TRASPOSTA[cont]=A[jj*n+i];
                    cont++;
                    TRASPOSTA[cont]=A[(jj+1)*n+i];
                    cont++;
                    TRASPOSTA[cont]=A[(jj+2)*n+i];
                    cont++;
                    TRASPOSTA[cont]=A[(jj+3)*n+i];
                    cont++;
                    TRASPOSTA[cont]=A[(jj+4)*n+i];
                    cont++; 
	            TRASPOSTA[cont]=A[(jj+5)*n+i];
                    cont++;
		    TRASPOSTA[cont]=A[(jj+6)*n+i];
                    cont++;
		    TRASPOSTA[cont]=A[(jj+7)*n+i];
                    cont++;
	            TRASPOSTA[cont]=A[(jj+8)*n+i];
                    cont++; 
		    TRASPOSTA[cont]=A[(jj+9)*n+i];
                    cont++;
                }
            }
        }
        return TRASPOSTA;
    }



VECTOR estraiVettore(MATRIX Xy, int m, int n){
	VECTOR Y = get_block(sizeof(float),m);
	int i,y,dim;
        y=0;
	dim=(n+1)*m;
	for (i = n; i < dim; i+=(n+1)) {
		Y[y]=Xy[i];
		y++;
		}
	return Y;
	
}

MATRIX addM(MATRIX A, MATRIX B, int n){
	int i,j;        
	MATRIX result = alloc_matrix(n,n);
        for(i=0; i<n; i++)
            for(j=0; j<n; j++)
                result[(i*n)+j] = A[(i*n)+j] + B[(i*n)+j];
        return result;
}
    
MATRIX subtractM(MATRIX A, MATRIX B, int n){
	int i,j;        
	MATRIX result = alloc_matrix(n,n);
        for(i=0; i<n; i++)
            for(j=0; j<n; j++)
                result[(i*n)+j] = A[(i*n)+j] - B[(i*n)+j];
        return result;
}

void divideArray(MATRIX parent, MATRIX child, int iB, int jB,int n){
	int i1,j1,i2,j2;
        for(i1 = 0, i2=iB; i1<n; i1++, i2++)
            for(j1 = 0, j2=jB; j1<n; j1++, j2++){
                child[(i1*n)+j1] = parent[(i2*(n*2))+j2];
            }
}
    

void copySubArray(MATRIX child, MATRIX parent, int iB, int jB,int n){
	int i1,j1,i2,j2;
        for(i1 = 0, i2=iB; i1<n; i1++, i2++)
            for(j1 = 0, j2=jB; j1<n; j1++, j2++){
                parent[(i2*(n*2))+j2] = child[(i1*n)+j1];
            }
    }

MATRIX strassenProdMatrix(MATRIX A, MATRIX B, int n){
	loop++;
	if(loop%1000==0){	
		printf (" LOOP:\n");
		printf ("%d\n",loop);
	}
	int i,j;        
	MATRIX result = alloc_matrix(n,n);
        if((n%2 != 0 ) && (n !=1)){
            //MATRIX a1, b1, c1;
            int n1 = n+1;
            MATRIX a1 = alloc_matrix(n1,n1);
            MATRIX b1 = alloc_matrix(n1,n1);
            MATRIX c1 = alloc_matrix(n1,n1);
            for(i=0; i<n; i++)
                for(j=0; j<n; j++){
                    a1[(i*n)+j] =A[(i*n)+j];
                    b1[(i*n)+j] =B[(i*n)+j];
                }
            c1 = strassenProdMatrix(a1, b1,n1);
            for(i=0; i<n; i++)
                for(j=0; j<n; j++)
                    result[(i*n)+j] =c1[(i*n)+j];
	    dealloc_matrix(a1);
	    dealloc_matrix(b1);
            dealloc_matrix(c1);
            return result;
        }
        if(n == 1){
            result[0] = A[0] * B[0];
        }
        else{
            MATRIX A11 = alloc_matrix(n/2,n/2);
            MATRIX A12 = alloc_matrix(n/2,n/2);
            MATRIX A21 = alloc_matrix(n/2,n/2);
            MATRIX A22 = alloc_matrix(n/2,n/2);
            MATRIX B11 = alloc_matrix(n/2,n/2);
            MATRIX B12 = alloc_matrix(n/2,n/2);
            MATRIX B21 = alloc_matrix(n/2,n/2);
            MATRIX B22 = alloc_matrix(n/2,n/2);
            divideArray(A, A11, 0 , 0,n/2);
            divideArray(A, A12, 0 , n/2,n/2);
            divideArray(A, A21, n/2, 0,n/2);
            divideArray(A, A22, n/2, n/2,n/2);
            divideArray(B, B11, 0 , 0,n/2);
            divideArray(B, B12, 0 , n/2,n/2);
            divideArray(B, B21, n/2, 0,n/2);
            divideArray(B, B22, n/2, n/2,n/2);
            
	    MATRIX P1 = strassenProdMatrix(addM(A11, A22,n/2), addM(B11, B22,n/2),n/2);
            MATRIX P2 = strassenProdMatrix(addM(A21, A22,n/2), B11,n/2);
            MATRIX P3 = strassenProdMatrix(A11, subtractM(B12, B22,n/2),n/2);
            MATRIX P4 = strassenProdMatrix(A22, subtractM(B21, B11,n/2),n/2);
            MATRIX P5 = strassenProdMatrix(addM(A11, A12,n/2), B22,n/2);
            MATRIX P6 = strassenProdMatrix(subtractM(A21, A11,n/2), addM(B11, B12,n/2),n/2);
            MATRIX P7 = strassenProdMatrix(subtractM(A12, A22,n/2), addM(B21, B22,n/2),n/2);
	    dealloc_matrix(A11);
	    dealloc_matrix(A12);
            dealloc_matrix(A21);
	    dealloc_matrix(A22);
	    dealloc_matrix(B11);
	    dealloc_matrix(B12);
            dealloc_matrix(B21);
	    dealloc_matrix(B22);
	    MATRIX C11 = addM(subtractM(addM(P1, P4,n/2), P5,n/2), P7,n/2);
            MATRIX C12 = addM(P3, P5,n/2);
            MATRIX C21 = addM(P2, P4,n/2);
            MATRIX C22 = addM(subtractM(addM(P1, P3,n/2), P2,n/2), P6,n/2);
	    dealloc_matrix(P1);
	    dealloc_matrix(P2);
            dealloc_matrix(P3);
	    dealloc_matrix(P4);
	    dealloc_matrix(P5);
	    dealloc_matrix(P6);
            dealloc_matrix(P7);
            copySubArray(C11, result, 0 , 0,n/2);
            copySubArray(C12, result, 0 , n/2,n/2);
            copySubArray(C21, result, n/2, 0,n/2);
            copySubArray(C22, result, n/2, n/2,n/2);
        }
        return result;
    }

MATRIX inversaOptStrassen(MATRIX a, int n,int block_size) {//FUNZIONA
        int unroll=2;
	int i,j,k,kk;
	MATRIX x = alloc_matrix(n,n);  
	MATRIX b = alloc_matrix(n,n);
	int* index = calloc(n,sizeof(int));
        for (i=0; i<n; ++i)
            b[(i*n)+i] = 1;

        gaussianOptStrassen(a, index,n,block_size,unroll);
        
        
        for (i=0; i<n-1; i++){
            for (j=i+1; j<n; j++){
                for (k=0; k<n; k+=block_size){
                    for (kk=k; kk<k+block_size; kk+=unroll) {
                          b[(index[j]*n)+kk]-= a[(index[j]*n)+i]*b[(index[i]*n)+kk];
                          b[(index[j]*n)+(kk+1)]-= a[(index[j]*n)+i]*b[(index[i]*n)+(kk+1)];
			  
                    }      
                }
            }
        }
        
        for (i=0; i<n; ++i) {
            x[((n-1)*n)+i] = b[(index[n-1]*n)+i]/a[(index[n-1]*n)+(n-1)];
            for (j=n-2; j>=0; --j) {
                x[(j*n)+i] = b[(index[j]*n)+i];
                for (k=j+1; k<n; ++k) {
                    x[(j*n)+i] -= a[(index[j]*n)+k]*x[(k*n)+i];
                }
                x[(j*n)+i] /= a[(index[j]*n)+j];
            }
	
        }
        return x; 
    }

void gaussianOptStrassen(MATRIX a,int* index,int n,int block_size,int unroll) {
        int i,ii,j,jj,k,l;
        VECTOR c= get_block(sizeof(float),n);

         for (i=0;i<n;i+=block_size) {
            for (ii=i; ii<i+block_size; ii+=unroll) {
                index[ii] = ii;
                index[ii+1] = ii+1;
               
            }
        }
        
        for (i=0; i<n; i+=block_size) {
            for (ii=i; ii<i+block_size; ii++) {
                float c1 = 0;
                for (j=0; j<n; j+=block_size) {
                    for (jj=j; jj<j+block_size;jj+=unroll){
                        float c00 = a[(ii*n)+jj]; //1° unroll
                        if(c00<0)
                            c00*=-1;
                        if (c00 > c1) 
                            c1 = c00;
                        float c01 = a[(ii*n)+(jj+1)]; //2° unroll
                        if(c01<0)
                            c01*=-1;
                        if (c01 > c1) 
                            c1 = c01;
			  
                    }
                }
                c[ii] = c1;
            }
        }

        k = 0;
        for (j=0; j<n-1; ++j) {
            float pi1 = 0;
            for (i=j; i<n; ++i) {
                float pi0 = a[(index[i]*n)+j];
                if(pi0<0)
                    pi0*=-1;
                pi0 /= c[index[i]];
                if (pi0 > pi1) {
                    pi1 = pi0;
                    k = i;
                }
            }

            int itmp = index[j];
            index[j] = index[k];
            index[k] = itmp;
            for (i=j+1; i<n; ++i) {
                float pj = a[(index[i]*n)+j]/a[(index[j]*n)+j];
                a[(index[i]*n)+j] = pj;
                for (l=j+1; l<n; ++l)
                    a[(index[i]*n)+l] -= pj*a[(index[j]*n)+l];
            }
        }
    }

MATRIX calcTraspostaCacheUnrollStrassen(MATRIX A,int m, int n, int block_size){//FUNZIONA
	MATRIX TRASPOSTA = alloc_matrix(n,m);        
	int i,j,jj;        
	int cont=0;
        int unroll=2;
       
        for (i=0; i< n; i++) {
            for (j=0; j< m; j+=block_size) {
                for (jj=j; jj<j+block_size; jj+=unroll){ 
                    TRASPOSTA[cont]=A[jj*n+i];
                    cont++;
                    TRASPOSTA[cont]=A[(jj+1)*n+i];
                    cont++;
                    
                }
            }
        }
        return TRASPOSTA;
    }

int checkStrassen(int m, int n,int block_size){
	if(m==n){//deve essere anche potenza di 2
	 	float x=(float)m;
		float y=(float)block_size;
		float LOG2E = log(2.0);
        	float log2x=log(x)/LOG2E;
		float log2y=log(y)/LOG2E;
		int confrontoX=(int)log2x; 
		int confrontoY=(int)log2y;        
        	if((confrontoX==log2x)&&(confrontoY==log2y)&&(block_size<n))
			return 1;
		else
			return 0;
	}
	else
	   return 0;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}


/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX Xy, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);	
	VECTOR Y;	
	int j;
	int block_size=50; 
	
    	printf (" Xy\n");
	//stampaMatrice(Xy,m,n+1);
	printf("\n");	
	
	MATRIX A=estraiMatrice(Xy,m,n);
	
        Y= estraiVettore(Xy,m,n);
        
	if(checkStrassen(m,n,block_size)){
	
		printf (" STRASSEN METHOD\n");
		printf ("\n");
		//printf (" A\n");
        	//stampaMatrice(A,m,n);
        	//printf("\n");
		//printf (" V\n");

       		/* for(j=0;j<m;j++){
           		printf ("  ");
           		printf ("%f", Y[j]);
        	} */
       		printf("\n");
       		printf("\n");
		printf ("CALCOLO TRASPOSTA...\n");
		MATRIX trasposta = calcTraspostaCacheUnrollStrassen(A,m,m,block_size);
        	printf ("TRASPOSTA CALCOLATA...\n");
		//stampaMatrice(trasposta,n,m);
        	printf("\n");
		printf("CALCOLO PRODOTTO...\n");
	
		MATRIX prodotto=strassenProdMatrix(trasposta,A,m);
		printf("PRODOTTO CALCOLATO\n");	
		//stampaMatrice(prodotto,n,n);
        
		printf("\n");
		printf("\n");
		//stampaMatrice(prodotto2,n,n);	
		printf("CALCOLO INVERSA...\n");
		MATRIX inversa=inversaOptStrassen(prodotto, n,block_size);
	
		printf("INVERSA CALCOLATA\n");
        	//stampaMatrice(inversa,n,n);
		printf("\n");
		printf("CALCOLO BETA...\n");	
		beta=prodMatrixVectorRowCacheUnroll(strassenProdMatrix(inversa,trasposta,m),Y,n,m,block_size);
		
		/*for(j=0;j<n;j++){
           		printf ("%d",j);
	   		printf (" ");
           		printf ("%f\n", Y[j]);
        	}*/
		printf("ESECUZIONE COMPLETATA!\n");
	}
	else{
		printf (" NORMAL METHOD\n");
		printf ("\n");
		//printf (" A\n");
        	//stampaMatrice(A,m,n);
        	//printf("\n");
		//printf (" V\n");

       		/* for(j=0;j<m;j++){
           		printf ("  ");
           		printf ("%f", Y[j]);
        	} */
       		printf("\n");
       		printf("\n");
		printf ("CALCOLO TRASPOSTA...\n");
		MATRIX trasposta = calcTraspostaCacheUnroll(A,m,n,block_size);
        	printf ("TRASPOSTA CALCOLATA...\n");
		//stampaMatrice(trasposta,n,m);
        	printf("\n");
		printf("CALCOLO PRODOTTO...\n");
	
		MATRIX prodotto=prodMatrixRowCacheUnroll(trasposta,A,n,n,m,block_size);
		printf("PRODOTTO CALCOLATO\n");	
		//stampaMatrice(prodotto,n,n);
        	printf("\n");
		printf("\n");
		//stampaMatrice(prodotto2,n,n);	
		printf("CALCOLO INVERSA...\n");
		MATRIX inversa=inversaOpt(prodotto, n,block_size);
		printf("INVERSA CALCOLATA\n");
        	//stampaMatrice(inversa,n,n);
		printf("\n");
		printf("CALCOLO BETA...\n");	
		beta=prodMatrixVectorRowCacheUnroll(prodMatrixRowCacheUnroll(inversa,trasposta,n,m,n,block_size),Y,n,m,block_size);
		
		/*for(j=0;j<n;j++){
           		printf ("%d",j);
	   		printf (" ");
           		printf ("%f\n", Y[j]);
        	}*/
		printf("ESECUZIONE COMPLETATA!\n");
	
	}	

    
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------
    
    //linreg32(Xy, beta, m, n); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------

    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	err/=(m*n);
	return err;
}



void main(int argc, char** argv) {
	int m = 1000;
	int n = 1000;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");

		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
