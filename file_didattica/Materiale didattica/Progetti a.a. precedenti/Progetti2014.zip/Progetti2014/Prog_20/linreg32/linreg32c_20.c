#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float* 

extern void separa(float* Xy, float* y, int m, int n);
extern void estraiMatrice(float* Xy, float* Xt, int m, int n);
extern void prodottoMatriciRigaRiga(float* A, float* B, float* C, int i, int j, int m, int n);
extern void prodottoMatrici2RigaRiga(float* A, float* B, float* C, int i, int j, int m, int n);
extern float* prodottoVettore(float *A, float *B, float *C, int m, int n, int r);
extern void reduce(float *B, int i, int j, int n, float d);
VECTOR linreg32(MATRIX Xy, VECTOR beta, int m, int n);

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size, 16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	//e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y; //*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}



void transpose(float *m, int w, int h)
{
	int start, next, i;
	float tmp;
 
	for (start = 0; start <= w * h - 1; start++) {
		next = start;
		i = 0;
		do {	i++;
			next = (next % h) * w + next / h;
		} while (next > start);
		if (next < start || i == 1) continue;
 
		tmp = m[next = start];
		do {
			i = (next % h) * w + next / h;
			m[next] = (i == start) ? tmp : m[i];
			next = i;
		} while (next > start);
	}
}

void prodotto(float* Xt, float* X, float* XtX, int m, int n){
  int i, j, k, p=4;
  for(i=0;i<n;i++){
    for(j=0;j<n;j++){
      prodottoMatriciRigaRiga(Xt, X, XtX, i, j, m, n);
	    
      /*for che calcola i "rimasugli"*/     
      for(k=p*floor(m/p);k<m;k++){ 
	XtX[i*n+j]+=Xt[i*m+k]*X[j*m+k];
      }
    }
  }
}


void prodotto2(float* inv, float* Xt, float* ris, int m, int n){
  int i, j, k, p=4;
  for(i=0;i<n;i++){
    for(j=0;j<m;j++){
      prodottoMatrici2RigaRiga(inv, Xt, ris, i, j, m, n);

      /*for che calcola i "rimasugli"*/
      for(k=p*floor(n/p);k<n;k++){ 
	ris[i*m+j]+=inv[i*n+k]*Xt[j*n+k];
      }
    }
  }
}

void prodottoMV(float *A, float *B, float *C, int m, int n, int p)
{
   int flag=p*floor(m/p);
   int rest= m-flag; /* numero di elementi residui da saltare */
   int cor=4-rest-1; /* valore da sottrarre ad esi in dipendenza dei numeri da saltare */

   prodottoVettore(A,B, C, n, m,rest); /* chiamata alla funzione assembly */

   if(m-flag!=0) /* caso in cui ci siano elementi residui da processare */
   {
      /* 
         flag      -> indice da cui iniziare a prendere i residui sia su A che B
         n - flag  -> numero di residui presenti dopo aver elaborato blocchi di p=4 elementi nella funzione prodotto in assembly  
      */
      int i,k;
      
      for(i=0;i<n;i++)
      {
            for(k=0;k<(m-flag);k++)
            {
               C[i]+=A[(i*m)+flag+k]*B[flag+k];
            }
      }
   }
}

MATRIX copyElements(float *A, int n){
    MATRIX B = alloc_matrix(n, 2*n);
    int i,j;
    for(i=0;i<n;i++){
        for(j=0;j<n*2;j++)
        {
            if(j<n)
                B[i*(n*2)+j]=A[i*n+j]; //Ricopio gli elementi
            if(j==(i+n))
                B[i*(n*2)+j]=1; //Aggiungo 1 sulla diagonale principale della matrice "orlata"
        }
    }
    return B;
}

void partialPivot(float *B, int n){
    int i, j;
    float d;
    for(i=n-1;i>0;i--)
    {
        if(B[(i-1)*(2*n)]<B[i*2*n])
            for(j=0;j<n*2;j++)
            {
                d=B[i*(2*n)+j];
                B[i*(2*n)+j]=B[(i-1)*(2*n)+j];
                B[(i-1)*(2*n)+j]=d;
            }
    }
}

void reductionDiagonalMatrix(float *B, int n)
{
    int i, j, k, p=4;
    float d;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++){
            
            if(j!=i)
            {
                d=B[j*(2*n)+i]/B[i*(2*n)+i];
		
		reduce(B, i, j, n, d);
                for(k=p*floor((2*n)/p);k<n*2;k++)
                    B[j*(2*n)+k]-=B[i*(2*n)+k]*d;
            }
        }
    }
}

void reductionUnitaryMatrix(float *B, int n){
    int i, j;
    float d;
    for(i=0;i<n;i++)
    {
        d=B[i*(2*n)+i];
        for(j=0;j<n*2;j++)
            B[i*(2*n)+j]=B[i*(2*n)+j]/d;
    }
}

void solution(float *B, float* z, int n){
    
    int a=0, i, j;
    for(i=0;i<n;i++){
        for(j=n;j<n*2;j++)
            z[a++]=B[i*(2*n)+j];
    }
}


void inverse(float *A, float* z, int n)
{
 // int i, j;
    MATRIX B=copyElements(A, n);
//    printf("\ncopyElements fatto!\n");
    partialPivot(B, n);
 /*    printf("\npartialPivot fatto!\n");
     for(i=0;i<n; i++){
       for(j=0;j<2*n;j++){
 	printf("%f ", B[i*(2*n)+j]);
       }
       printf("\n");
     }*/
    reductionDiagonalMatrix(B, n);
//    printf("\nreductionDiagonalMatrix fatto!\n");
/*printf("\nStampo la matrice ridotta\n");
for(i=0;i<n;i++){
	for(j=0;j<2*n;j++){
		printf("%f ", B[i*(2*n)+j]);
	}
	printf("\n");
}*/
    reductionUnitaryMatrix(B, n);
 //   printf("\nreductionUnitaryMatrix fatto!\n");
    solution(B, z, n);
 //   printf("\nsolution fatto!\n");
    //dealloc_matrix(B);
}


VECTOR linreg32(MATRIX Xy, VECTOR beta, int m, int n){
 // int i, j;
  
  
  VECTOR y = alloc_matrix(m, 1);
  MATRIX Xt=alloc_matrix(m, n); 
  MATRIX X=alloc_matrix(m, n);
  MATRIX XtX=alloc_matrix(n,n);
  MATRIX z=alloc_matrix(n, n);
  MATRIX ris=alloc_matrix(n, m);
  
  
 // printf("\nSeparo\n");
   separa(Xy, y, m, n); // Prendo il vettore y
/*     printf("\nStampo vettore y\n");
   	for(i=0;i<m;i++){
   	  printf("%f ", y[i]);
   	}
 */ 	
  	
 // printf("\nEstraggo\n");
  estraiMatrice(Xy, Xt, m, n); // Prendo la matrice da trasporre
/*     printf("\nStampo matrice Xt\n");
   	for(i=0;i<m;i++){
   	  for(j=0;j<n;j++){
   	    printf("%f ", Xt[i*n+j]);
   	  }
   	  printf("\n");
   	}
  */	
  	
//  printf("\nEstraggo\n");
  estraiMatrice(Xy, X, m, n); // Prendo la matrice originaria
//    printf("\nStampo matrice X\n");
//  	for(i=0;i<m;i++){
//  	  for(j=0;j<n;j++){
//  	    printf("%f ", X[i*n+j]);
//  	  }
//  	  printf("\n");
//  	}
  
  
 // printf("\nTraspongo\n");
  transpose(Xt, n, m);  // Calcolo la trasposta
//    printf("\nStampo matrice Xt'\n");
//  	for(i=0;i<n;i++){
//  	  for(j=0;j<m;j++){
//  	    printf("%f ", Xt[i*m+j]);
//  	  }
//  	  printf("\n");
//  	}
  
 //   printf("\nTraspongo\n");
  transpose(X, n, m);  // Calcolo la trasposta
//    printf("\nStampo matrice X'\n");
//  	for(i=0;i<n;i++){
//  	  for(j=0;j<m;j++){
//  	    printf("%f ", X[i*m+j]);
//  	  }
//  	  printf("\n");
//  	}
  
//  printf("\nProdotto XtX\n");
   prodotto(Xt, X, XtX, m, n); // Xt*X
 /*   printf("\nStampo matrice XtX\n");
  	for(i=0;i<n;i++){
  	  for(j=0;j<n;j++){
  	    printf("%f ", XtX[i*n+j]);
  	  }
  	  printf("\n");
  	}
 */ 
  
//  printf("\nCalcolo l'inversa\n");
  inverse(XtX, z, n); // inv(Xt*X)
  
/*    printf("\nStampo matrice inv(XtX)\n");
  	for(i=0;i<n;i++){
  	  for(j=0;j<n;j++){
  	    printf("%f ", z[i*n+j]);
  	  }
  	  printf("\n");
  	}
*/
  transpose(X, m, n);
//     printf("\nStampo matrice X'\n");
//   	for(i=0;i<m;i++){
//   	  for(j=0;j<n;j++){
//   	    printf("%f ", X[i*n+j]);
//   	  }
//   	  printf("\n");
//   	}
  	
//  printf("\nCalcolo inv(XtX)*Xt\n");
   prodotto2(z, X, ris, m, n); // inv(Xt*X)*Xt
/*    printf("\nStampo matrice inv(XtX)Xt\n");
  	for(i=0;i<n;i++){
  	  for(j=0;j<m;j++){
  	    printf("%f ", ris[i*m+j]);
  	  }
  	  printf("\n");
  	}
 */
  
 // printf("\nCalcolo vettore\n");
  prodottoMV(ris, y, beta, m, n, 4); // inv(Xt*X)*Xt*y
  
  //dealloc_matrix(y);
  //dealloc_matrix(Xt);
  //dealloc_matrix(X);
  //dealloc_matrix(XtX);
  //dealloc_matrix(z);
  //dealloc_matrix(ris);
  
  return beta;
}




/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX Xy, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);
    
    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------
    
    linreg32(Xy, beta, m, n); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------
    
    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}


/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_20.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/



void main(int argc, char** argv) {
	int m = 10;
	int n = 2;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);

	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
	
	//dealloc_matrix(beta);
}
