/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 * esempio: beta= (X^T * X)^1 X^T y:
 * mat:3 2 5
 *     4 1 9
 * 
 * Y:      5
 *         9 
 * 
 * X:      3 2  
 *         4 1
 * 
 * X^T:    3 4
 *         2 1
 * 
 * X^T*X: 25 10
 *        10 5
 *
 *(X^T*X)^1: 0.2  -0.4  
 *          -0.4   1
 * 
 * (X^T * X)^1 X^T :-0.2   0.4
 *                   0.8  -0.6
 * 
 * (X^T * X)^1 X^T y : 2.6
 *                    -1.4
 */


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */

typedef enum {
    false, true
} bool;


#define	MATRIX	float*
#define	VECTOR	float*

void trasformaDaMAF(MATRIX, float **, int, int);
//MATRIX trasformaDaFAM(float**, int, int);
float** create(int, int);
float** inversa(float**, int, int);
float** prodottoMatrici(float **, float **, int, int, int, int);
float* prodottoMV(float **, float *, int, int);
void print(float**, int, int);
void printVettore(float *, int);
void liberaMatrice(float**, int, int);
void liberaVettore(float*);

float** create(int r, int c) {
    float **m;
    int i;
    m = (float**) malloc(r * sizeof (float*));
    if (m == NULL) {
        printf("MEMORIA NON DISPONIBILE! \n");
        exit(-1);
    } else {
        for (i = 0; i < r; i++) {
            m[i] = (float*) malloc(c * sizeof (float));
            if (m[i] == NULL) {
                printf("MEMORIA NON DISPONIBILE! \n");
                free(m);
                exit(-1);
            }
        }
    }
    return m;
}


void trasformaDaMAF(MATRIX m, float ** ma, int r, int c){
    int i,j,conta=0;
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++){
            ma[i][j]=m[conta++];

        }
    }
}
/*
MATRIX trasformaDaFAM (float** m, int r, int c){
    MATRIX mat = alloc_matrix(r,c);
    int i,j,conta=0;
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++){
            mat[conta++]=m[i][j];
        }
    }
    return mat;
}
*/

void liberaMatrice(float** m, int r, int c) {
    int i;
    for (i = 0; i < r; i++) {
        free(m[i]);
    }
    free(m);
}

void liberaVettore(float *v) {
    free(v);
}


void print(float** m, int r, int c) {
    int i, j;
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
            printf("%f\t", m[i][j]);
        }
        printf("\n");
    }
}

void printVettore(float *v, int c) {
    int i;
    for (i = 0; i < c; i++) {
        printf("%f\t", v[i]);
        printf("\n");
    }
}

float* prodottoMV(float **m, float *v, int r, int c) {
    float * vet;
    vet = (float*) malloc(r * sizeof (float));
    if (vet == NULL) {
        printf("MEMORIA NON DISPONIBILE! \n");
        exit(-1);
    }

    int i, k;
    float somma = 0;
    for (i = 0; i < r; i++) {
        {
            for (k = 0; k < r; k++) {
                somma = somma + m[i][k] * v[k];
            }
            vet[i] = somma;
            somma = 0;
        }
    }
    return vet;
}

float** inversa(float** matrice, int r, int c) {

    float** m = create(r, c);
    float ratio, a;
    int i, j, k, n = r;
    for (i = 0; i < n; i++) {
        for (j = n; j < 2 * n; j++) {
            if (i == (j - n))
                matrice[i][j] = 1.0;
            else
                matrice[i][j] = 0.0;
        }
    }
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if (i != j) {
                ratio = matrice[j][i] / matrice[i][i];
                for (k = 0; k < 2 * n; k++) {
                    matrice[j][k] -= ratio * matrice[i][k];
                }
            }
        }
    }
    for (i = 0; i < n; i++) {
        a = matrice[i][i];
        for (j = 0; j < 2 * n; j++) {
            matrice[i][j] /= a;
        }
    }
    for (i = 0; i < n; i++) {
        for (j = n; j < 2 * n; j++) {
            m[i][j - n] = matrice[i][j];
        }
    }

    return m;
}

//int m=righe prima matrice, n=colonne prima matrice, p=righe seconda matrice, q=colonne seconda matrice
float** prodottoMatrici(float ** m1, float ** m2, int m, int n, int p, int q) {
    float** prodotto = create(m, p);
    if (n != p)
        printf("questa matrice non puÃ² essere moltiplicata.\n");
    int c, d, k;
    float somma = 0;
    for (c = 0; c < m; c++) {
        for (d = 0; d < q; d++) {
            for (k = 0; k < p; k++) {
                somma = somma + m1[c][k] * m2[k][d];
            }
            prodotto[c][d] = somma;
	    somma = 0;
        }
    }
    return prodotto;
}

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y;
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}


/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
    VECTOR linreg(MATRIX Xy, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);		//vettore da trovare
    VECTOR uc= get_block(sizeof(float),m); 		//ultima colonna di mat
    MATRIX sm= get_block(sizeof(float),m*n); 		//matrice tranne ultima colonna
    MATRIX mt= get_block(sizeof(float),m*n);		//matrice trasposta di sottoMatrice
    float **traspX=create(n,m);				//trasposta di x    
    float **smf=create(m,n);				//matrice iniziale tranne ultima colonna smf=sotto matrice float**   
    float **prodottoMat;		         	//prodotto tra x e x^T
    float **prodInvTrasp;
    float **matriceProdottoInv; 			//inversa di prodottoMat (x^T * x)^-1
    
    ultimaColonna(Xy,uc,m,n+1);
    sottoMatrice(Xy,sm,m,n+1);
    trasposta(sm,mt,m,n);

    trasformaDaMAF(mt,traspX,n,m);			//ritrasformo in float**
    trasformaDaMAF(sm,smf,m,n);				//ritrasformo in float**
  
  
  // printf("la matrice passata e':\n");
  // printVettore(Xy,m*(n+1));

  //printf("l'ultima colonna e':\n");
  //printVettore(uc,m);

  
  
 

  //printf("la sotto matrice e':\n");
  //print(smf,m,n);

  //printf("la trasposta e':\n");
  //print(traspX,n,m);//nm
  //printf("n%d ",n);
    prodottoMat = prodottoMatrici(traspX, smf, n, m, m,n);
  //printf("\nil prodotto tra x^T e x e'š:\n");
  //print(prodottoMat, n, n);
  
  //il metodo matrice inversa cambia la matrice d'origine, attenzione a come si usa

    matriceProdottoInv = inversa(prodottoMat, n, n);    //l'inversa avrà n righe e n colonne
  //printf("\nla matrice inversa di x^T * x e':\n");
  //print(matriceProdottoInv, n, n);

    prodInvTrasp = prodottoMatrici(matriceProdottoInv, traspX, n, n, n, m);
  //printf("\nil prodotto tra inversa e x^T e':\n");
  //print(prodInvTrasp, n, m);

    beta = prodottoMV(prodInvTrasp, uc, n, m);
  //printf("\nil vettore beta e':\n");
  //printVettore(beta, n);



  //liberaMatrice(traspX, n, m);
  //liberaMatrice(prodInvTrasp, n, m);
  //liberaMatrice(smf, m, n);
  //liberaMatrice(matriceProdottoInv, n, n);
  //liberaMatrice(prodottoMat, n, n);
  //liberaVettore(uc);

    return beta;
}

/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */

float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err/(m*n);
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_22.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/


void main(int argc, char** argv) {
	int m = 10;
	int n = 2;
	MATRIX Xy;
	VECTOR beta;
float **c=create(2,2);
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
/*      MATRIX A=alloc_matrix(2,3);
        A[0]=3;
        A[1]=2;
        A[2]=5;
        A[3]=4;
        A[4]=1;
        A[5]=9;
               
	beta = linreg(A,2,2);
*/
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
