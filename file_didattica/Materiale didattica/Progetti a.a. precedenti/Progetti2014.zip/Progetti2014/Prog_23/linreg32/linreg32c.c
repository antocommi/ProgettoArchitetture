/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*

extern	void	_multiplication(MATRIX m1, MATRIX m2, MATRIX res, int r, int c,int c2);
extern	void	_decompLU(MATRIX m1, int dim, int* piv, MATRIX res);
extern	void	_transposte(MATRIX m, int r, int c, MATRIX res);
extern	void	_XY(MATRIX m, int r, int c, MATRIX x, VECTOR y);
void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}

void invert(VECTOR mat, int dim, VECTOR inv){
	int m, m1,i,j;float x;
	VECTOR d = get_block(sizeof(float),dim);
        VECTOR y = get_block(sizeof(float),dim);
   
	int n=dim-1;
     for (m=0; m<=n; m++){
	for(m1=0;m1<=n;m1++){
         if(m==m1){
            d[m1]=1.0;
            } else {d[m1]=0.0;}
           }
               y[0]=d[0];
		for(i=1;i<=n;i++){ 
			x=0.0; 
			for(j=0;j<=i-1;j++){
				x=x+mat[i*dim+j]*y[j];}
				y[i]=(d[i]-x);
			}
                        y[n]=y[n]/mat[n*dim+n];
			for(i=n-1;i>=0;i--){ 
				x=0.0; 
				for(j=i+1;j<=n;j++){
					x=x+mat[i*dim+j]*y[j];
				}
                        y[i]=(y[i]-x)/mat[i*dim+i];
			
		}
               for(j=0;j<=n;j++){inv[j*dim+m]=y[j];}
	}
}

void order(VECTOR inv, int*piv, VECTOR invo,int dim){
	int i,k,j;
	int n=dim-1;
		for(i=0;i<=n;i++){ 
                     k=0;
                     k=piv[i];
			for(j=0;j<=n;j++){
			invo[j*dim+k]=inv[j*dim+i];}}	
}


/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
void stampa(VECTOR V,int r, int c){
	int i,j;	
	printf("\n");	
	for (i = 0; i < r; i++) {
		for (j = 0; j < c; j++) {
			printf("%.3f, ",V[i*c+j]);
		}
		printf("\n");
	}
	printf("\n");
}

void stampaI(int* V,int r, int c){
	int i,j;	
	printf("\n");	
	for (i = 0; i < r; i++) {
		for (j = 0; j < c; j++) {
			printf("%d, ",V[i*c+j]);

		}
		printf("\n");
	}
	printf("\n");
}

VECTOR linreg(MATRIX Xy, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);
    MATRIX trasposta=get_block(sizeof(float),(n)*m);
    MATRIX m1=get_block(sizeof(float),(n)*(n));
    //MATRIX m3=get_block(sizeof(float),(n)*(n));
    //MATRIX m4=get_block(sizeof(float),(n)*(n));
    VECTOR m2=get_block(sizeof(float),n);
    int* piv=get_block(sizeof(int),n);
    MATRIX mLU=get_block(sizeof(float),(n)*(n));
    MATRIX inv=get_block(sizeof(float),(n)*(n));
    MATRIX invo=get_block(sizeof(float),(n)*(n));
    MATRIX x=get_block(sizeof(float),(n)*m);
    MATRIX y=get_block(sizeof(float),m);
    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------
    _XY(Xy,m,n,x,y);
     //stampa(y,m,1);
     //stampa(x,m,n);
    _transposte(x,m,n,trasposta);
    _multiplication(trasposta,trasposta,m1,n,m,n);
     //_multiplication(trasposta,trasposta,m3,n,m,n);
     //stampa(m1,n,n);
 // Esempio di chiamata di funzione assembly
    _multiplication(trasposta,y,m2,n,m,1);
    _decompLU(m1,n,piv,mLU);
      //stampaI(piv,n,1);
    //stampa(m2,n-1,1);
    //invert(m1,n-1,inv);
    //stampa(inv,n-1,n-1);
    invert(mLU,n,inv);
    order(inv,piv,invo,n);
    _multiplication(invo,m2,beta,n,n,1);
    //stampa(invo,n,n);
    //_multiplication(invo,m3,m4,n,n,n);
    //stampa(m4,n,n);
    dealloc_matrix(trasposta);
    dealloc_matrix(m1);
    dealloc_matrix(mLU);
    dealloc_matrix(inv);
    dealloc_matrix(invo);
    dealloc_matrix(x);
    dealloc_matrix(y);
    free_block(piv);
    free_block(m2);
    // -------------------------------------------------

    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_23.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/


void main(int argc, char** argv) {
	int m = 4;
	int n = 3;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
