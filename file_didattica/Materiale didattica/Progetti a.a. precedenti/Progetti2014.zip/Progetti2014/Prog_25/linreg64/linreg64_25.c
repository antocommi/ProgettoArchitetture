 /****************************************************************************
 *
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 *
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 *
 * Fabrizio Angiulli, 28 aprile 2014
 *
 ****************************************************************************/

/*

 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software
 installabili mediante il packaging tool del sistema
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c

 oppure

 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>

extern float **linreg64(int m, int n, float **Xy);

/*
 *
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere
 * 	memorizzate mediante array di array (float**).
 *
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 *
 */




float frand() {
    float r = (float) rand();
    return r/RAND_MAX;
}

/*
 *
 * 	random_input
 * 	============
 *
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg.
 *
 */

float **random_input(int m, int n) {
    int i,j;
    float x, y;
    float **a= allocate_mem_matrix(m,n);

    for(i=0; i<m; i++) {
        y = 0;
        for(j=0; j<n; j++) {
            if(j < n-1) {
                a[i][j]= frand();
            }
            else {
                a[i][j]=1.0;
                y+=frand();
            }
        }
        a[i][j]=y*(1+frand());
    }
    return a;
}

/*
 *
 * 	load_input
 * 	===========
 *
 *	Legge da file una matrice m x (n+1)
 * 	da fornire in input alla funzione linreg.
 *
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 *
 */

void* get_block(int size, int elements) {
    return _mm_malloc(elements*size,16);
}

float* alloc_matrix(int rows, int cols) {
    return (float*) get_block(sizeof(float),rows*cols);
}

float* load_input(char* filename, int *m, int *n) {
    FILE* fp;
    int rows, cols, status;

    fp = fopen(filename, "rb");
    status = fread(&cols, sizeof(int), 1, fp);
    status = fread(&rows, sizeof(int), 1, fp);
    float* Xy = alloc_matrix(rows,cols);
    status = fread(Xy, sizeof(float), rows*cols, fp);
    fclose(fp);

    *m = rows;
    *n = cols-1;
    return Xy;
}

float** to_bidimensional_matrix(int rows, int cols, float* Xy) {
    float** res=allocate_mem_matrix(rows, cols);
    int i=0, j=0;
    //conversione in matrie bidimensionale
    for(i=0; i < rows; i++) {
        for(j=0; j < cols; j++) {
            res[i][j]=Xy[(i * (cols)) +j];
        }
    }
    return res;
}

void printMatrix(int m, int n, float **matrix) {
    int i,j;
    for(i=0; i<m; i++) {
        printf("\n");
        for(j=0; j<n; j++) {
            printf(" %f", matrix[i][j]);
        }
    }
}

/*
 *
 * 	save_input
 * 	===========
 *
 *	Scrive su file una matrice m x (n+1).
 *
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 *
 */

void save_input(char* filename, float* Xy, int m, int n) {
    FILE* fp;
    int status;

    fp = fopen(filename, "wb");
    n++;
    status = fwrite(&n, sizeof(int), 1, fp);
    status = fwrite(&m, sizeof(int), 1, fp);
    status = fwrite(Xy, sizeof(float), m*n, fp);
    fclose(fp);
}


/*
 *	linreg
 * 	======
 *
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 *
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 *
 */


float **linreg(float **Xy, int m, int n) {
    printf("\nCALCOLO BETA SEGNATO con linreg a 64 bit IN CORSO...\n");
    float **beta= linreg64(m, n, Xy);
    return beta;
}

/*
 *
 * 	error
 * 	=====
 *
 *	Calcola l'errore di regressione.
 *
 */
float error(float **Xy, float **beta, int m, int n) {
    int i, j;
    float err = 0, de, yp;

    for (i = 0; i < m; i++) {
        yp = 0;
        for (j = 0; j < n-1; j++)
            yp += Xy[i][j] * beta[j][0];
        de = fabs(Xy[i][n-1]-yp);
        err += (de*de);
    }
    return err/(m*n);
}




void main(int argc, char** argv) {
    int m = 1000;
    int n = 1000;
    float **Xy;
    float **beta;

    float* matrixVector;

    char* filename = "";
    int silent = 0, display = 0, fsave = 0;
    int i;

    srandom(time(NULL));

    int par = 1;
    while (par < argc) {
        if (strcmp(argv[par],"-l") == 0) {
            par++;
            if (par < argc) {
                filename = argv[par];
                par++;
            }
        } else if (strcmp(argv[par],"-r") == 0) {
            par++;
            if (par < argc) {
                m = atoi(argv[par]);
                par++;
                if (par < argc) {
                    n = atoi(argv[par]);
                    par++;
                }
            }
        } else if (strcmp(argv[par],"-f") == 0) {
            fsave = 1;
            par++;
        } else if (strcmp(argv[par],"-s") == 0) {
            silent = 1;
            par++;
        } else if (strcmp(argv[par],"-d") == 0) {
            display = 1;
            par++;
        } else
            par++;
    }

    if (!silent) {
        printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
        printf("\nParameters:\n");
        printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
        printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
        printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
        printf("\t-d : displays input and output\n");
        printf("\t-s : silent\n");

        printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
    }

    if (strlen(filename) == 0) {
        Xy = random_input(m,n);
    }
    else {
        float* matrixVector= load_input(filename, &m, &n);
        Xy = to_bidimensional_matrix(m, n+1, matrixVector);
    }
    if (!silent && display) {
        printf("\nInput augmented matrix:\n");
        printMatrix(m,n+1, Xy);
        printf("\n");
    }

    clock_t t = clock();
    beta = linreg(Xy,m,n);
    t = clock() - t;

    if (!silent)
        printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
    else
        printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);

    if (!silent && display) {
        printf("\nOutput coefficient vector:\n");
        for (i = 0; i < n-1; i++) {
            printf("%.3f ", beta[i][0]);
        }
        printf("\n");
    }

    float err = error(Xy,beta,m,n);
    if (!silent)
        printf("\nThe error is %f.\n", err);
    else
        printf("%f\n", err);

    if (strlen(filename) == 0 && fsave)
        save_input("last.mat",matrixVector,m,n);
}

