/****************************************************************************
 *
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 *
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 *
 * Fabrizio Angiulli, 28 aprile 2014
 *
 ****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>




float frand() {
    float r = (float) rand();
    return r/RAND_MAX;
}


//**********************************************************************
// Inizio sezione di Codice C relativa al calcolo di beta segnato
// (con tutti i metodi annessi) su cui e' basato il codice NASM
// di linreg proposto
//
// S. Marano matricola: 166521
//**********************************************************************


float **allocate_mem_matrix(int m, int n) {
    printf("\nALLOCAZIONE MEMORIA...\n");
    int i;
    float **memoryArray = malloc(m*sizeof(*memoryArray));
    for(i=0; i<m; i++) {
        memoryArray[i]=malloc(n*sizeof(**memoryArray));
    }
    return memoryArray;
}

void free_mem_matrix(int m, float **memoryArray) {
    printf("\nDEALLOCAZIONE MEMORIA...\n");
    int i;
    for (i = 0; i < m; i++) {
        free(memoryArray[i]);
    }
    free(memoryArray);
}

float **transposeMatrix(int m, int n, float **matrix) {
    printf("\nTRASPOSIZIONE MATRICE...\n");
    int i,j;
    float **result = allocate_mem_matrix(n,m);
    for(i = 0; i < m; i++) {
        for(j = 0; j < n; j++) {
            result[j][i] = matrix[i][j];
        }
    }
    return result;
}

float **multiplyMatrix(int m1, int n1, float **matrix1,int m2, int n2, float **matrix2) {
    printf("\nMOLTIPLICAZIONE MATRICI...\n");
    int i,j,k;
    float **result = allocate_mem_matrix(m1,n2);
    for (i = 0; i < m1; i++) {
        for (j = 0; j < n2; j++) {
            for (k = 0; k < n1; k++) {
                result[i][j] = result[i][j] + matrix1[i][k] * matrix2[k][j];
            }
        }
    }
    return result;
}

float **identityMatrix(int n) {
    printf("\nCREAZIONE MATRICE DI IDENTITA'...\n");
    int i,j;
    float **b= allocate_mem_matrix(n,n);
    for(i=0; i<n; i++) {
        for(j=0; j<n; j++) {
            if(i==j) {
                b[i][j]=1;
            }
            else {
                b[i][j]=0;
            }
        }
    }
    return b;
}

float **invertMatrix(int n, float **matrix) {
    printf("\nINVERSIONE MATRICE...\n");
    float tmp0=0,tmp1=0,tmp2=0,tmp3=0,tmp4=0,tmp5=0;
    int m=0,i=0,j=0,p=0,q=0;

    //get an identity matrix of the same size
    float **a= identityMatrix(n);

    for(i=0; i<n; i++) {
        tmp1=matrix[i][i];
        if(tmp1<0)
            tmp1=tmp1*(-1);
        p=i;
        for(j=i+1; j<n; j++) {
            if(matrix[j][i]<0)
                tmp0=matrix[j][i]*(-1);
            else
                tmp0=matrix[j][i];
            if(tmp1<0)
                tmp1=tmp1*(-1);
            if(tmp0>tmp1) {
                p=j;
                tmp1=matrix[j][i];
            }
        }
        //row exchange in both the matrix
        for(j=0; j<n; j++) {
            tmp2=matrix[i][j];
            matrix[i][j]=matrix[p][j];
            matrix[p][j]=tmp2;
            tmp3=a[i][j];
            a[i][j]=a[p][j];
            a[p][j]=tmp3;
        }
        //dividing the row by matrix[i][i]
        tmp4=matrix[i][i];
        if(tmp4==0) {
            printf("\nMATRICE NON INVERTIBILE!!!\n");
            return NULL;
        }
        for(j=0; j<n; j++) {
            matrix[i][j]=(float)matrix[i][j]/tmp4;
            a[i][j]=(float)a[i][j]/tmp4;
        }
        //making other elements 0 in order to make the matrix matrix[][] an indentity matrix and obtaining inverse a[][] matrix
        for(q=0; q<n; q++) {
            if(q==i)
                continue;
            tmp5=matrix[q][i];
            for(j=0; j<n; j++) {
                matrix[q][j]=matrix[q][j]-(tmp5*matrix[i][j]);
                a[q][j]=a[q][j]-(tmp5*a[i][j]);
            }
        }
    }
    return a;
}

float **getLastColumn(int m, int n, float **matrix) {
    int i,j;
    float **y= allocate_mem_matrix(m,1);
    for(i=0; i<m; i++) {
        y[i][0]=matrix[i][n-1];
    }
    return y;
}

float **betaTest(int m, int n, float **Xy) {
    printf("\nCALCOLO BETA SEGNATO...\n");
    //creo columnsX per selezionare le n-1 colonne corrispondenti a X
    int columnsX=n-1;
    //prelevo Y come ultima colonna di Xy
    float **Y = getLastColumn(m, n, Xy);
    float **transposedmatr = transposeMatrix(m, columnsX, Xy);
    float **prod = multiplyMatrix(columnsX, m, transposedmatr, m, columnsX, Xy);
    float **temp = invertMatrix(columnsX, prod);
    float **temp2 = multiplyMatrix(columnsX,columnsX,temp, columnsX,m,transposedmatr);
    float **beta=multiplyMatrix(columnsX,m,temp2, m,1,Y);
    //dealloco la memoria non utilizzata
    free_mem_matrix(columnsX, transposedmatr);
    free_mem_matrix(columnsX, temp);
    free_mem_matrix(columnsX, temp2);
    free_mem_matrix(m, Y);
    return beta;
}

//**********************************************************************
// Fine seione di codce
//
// S. Marano matricola: 166521
//**********************************************************************

/*
 *
 * 	random_input
 * 	============
 *
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg.
 *
 */

float **random_input(int m, int n) {
    printf("\nGENERAZIONE MATRICE CASUALE...\n");
    int i,j;
    float x, y;
    float **a= allocate_mem_matrix(m,n);

    for(i=0; i<m; i++) {
        y = 0;
        for(j=0; j<n; j++) {
            if(j < n-1) {
                a[i][j]= frand();
            }
            else {
                a[i][j]=1.0;
                y+=frand();
            }
        }
        a[i][j]=y*(1+frand());
    }
    return a;
}

/*
 *
 * 	load_input
 * 	===========
 *
 *	Legge da file una matrice m x (n+1)
 * 	da fornire in input alla funzione linreg.
 *
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 *
 */

void* get_block(int size, int elements) {
    return _mm_malloc(elements*size,16);
}

float* alloc_matrix(int rows, int cols) {
    return (float*) get_block(sizeof(float),rows*cols);
}

float* load_input(char* filename, int *m, int *n) {
    FILE* fp;
    int rows, cols, status;

    fp = fopen(filename, "rb");
    status = fread(&cols, sizeof(int), 1, fp);
    status = fread(&rows, sizeof(int), 1, fp);
    float* Xy = alloc_matrix(rows,cols);
    status = fread(Xy, sizeof(float), rows*cols, fp);
    fclose(fp);

    *m = rows;
    *n = cols-1;
    return Xy;
}

float** to_bidimensional_matrix(int rows, int cols, float* Xy) {
    float** res=allocate_mem_matrix(rows, cols);
    int i=0, j=0;
    //conversione in matrie bidimensionale
    for(i=0; i < rows; i++) {
        for(j=0; j < cols; j++) {
            res[i][j]=Xy[(i * (cols)) +j];
        }
    }
    return res;
}

void printMatrix(int m, int n, float **matrix) {
    int i,j;
    for(i=0; i<m; i++) {
        printf("\n");
        for(j=0; j<n; j++) {
            printf(" %f", matrix[i][j]);
        }
    }
}

/*
 *
 * 	save_input
 * 	===========
 *
 *	Scrive su file una matrice m x (n+1).
 *
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 *
 */
void save_input(char* filename, float* Xy, int m, int n) {
    FILE* fp;
    int status;

    fp = fopen(filename, "wb");
    n++;
    status = fwrite(&n, sizeof(int), 1, fp);
    status = fwrite(&m, sizeof(int), 1, fp);
    status = fwrite(Xy, sizeof(float), m*n, fp);
    fclose(fp);
}


/*
 *	linreg
 * 	======
 *
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 *
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 *
 */


float **linreg(float **Xy, int m, int n) {
    printf("\nCALCOLO BETA SEGNATO...\n");
    //creo columnsX per selezionare le n-1 colonne corrispondenti a X
    int columnsX=n-1;
    //prelevo Y come ultima colonna di Xy
    float **Y = getLastColumn(m, n, Xy);
    float **transposedmatr = transposeMatrix(m, columnsX, Xy);
    float **prod = multiplyMatrix(columnsX, m, transposedmatr, m, columnsX, Xy);
    float **temp = invertMatrix(columnsX, prod);
    float **temp2 = multiplyMatrix(columnsX,columnsX,temp, columnsX,m,transposedmatr);
    float **beta=multiplyMatrix(columnsX,m,temp2, m,1,Y);
    //dealloco la memoria non utilizzata
    free_mem_matrix(columnsX, transposedmatr);
    free_mem_matrix(columnsX, temp);
    free_mem_matrix(columnsX, temp2);
    free_mem_matrix(m, Y);
    return beta;
}

/*
 *
 * 	error
 * 	=====
 *
 *	Calcola l'errore di regressione.
 *
 */
float error(float **Xy, float **beta, int m, int n) {
    int i, j;
    float err = 0, de, yp;

    for (i = 0; i < m; i++) {
        yp = 0;
        for (j = 0; j < n-1; j++)
            yp += Xy[i][j] * beta[j][0];
        de = fabs(Xy[i][n-1]-yp);
        err += (de*de);
    }
    return err/(m*n);
}



void main(int argc, char** argv) {
    int m = 1000;
    int n = 1000;
    float **Xy;
    float **beta;

    float* matrixVector;

    char* filename = "";
    int silent = 0, display = 0, fsave = 0;
    int i;

    srandom(time(NULL));

    int par = 1;
    while (par < argc) {
        if (strcmp(argv[par],"-l") == 0) {
            par++;
            if (par < argc) {
                filename = argv[par];
                par++;
            }
        } else if (strcmp(argv[par],"-r") == 0) {
            par++;
            if (par < argc) {
                m = atoi(argv[par]);
                par++;
                if (par < argc) {
                    n = atoi(argv[par]);
                    par++;
                }
            }
        } else if (strcmp(argv[par],"-f") == 0) {
            fsave = 1;
            par++;
        } else if (strcmp(argv[par],"-s") == 0) {
            silent = 1;
            par++;
        } else if (strcmp(argv[par],"-d") == 0) {
            display = 1;
            par++;
        } else
            par++;
    }

    if (!silent) {
        printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
        printf("\nParameters:\n");
        printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
        printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
        printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
        printf("\t-d : displays input and output\n");
        printf("\t-s : silent\n");

        printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
    }

    if (strlen(filename) == 0) {
        Xy = random_input(m,n);
    }
    else {
        float* matrixVector= load_input(filename, &m, &n);
        Xy = to_bidimensional_matrix(m, n+1, matrixVector);
    }
    if (!silent && display) {
        printf("\nInput augmented matrix:\n");
        printMatrix(m,n+1, Xy);
        printf("\n");
    }

    clock_t t = clock();
    beta = linreg(Xy,m,n);
    t = clock() - t;

    if (!silent)
        printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
    else
        printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);

    if (!silent && display) {
        printf("\nOutput coefficient vector:\n");
        for (i = 0; i < n-1; i++) {
            printf("%.3f ", beta[i][0]);
        }
        printf("\n");
    }

    float err = error(Xy,beta,m,n);
    if (!silent)
        printf("\nThe error is %f.\n", err);
    else
        printf("%f\n", err);

    if (strlen(filename) == 0 && fsave)
        save_input("last.mat",matrixVector,m,n);
}












