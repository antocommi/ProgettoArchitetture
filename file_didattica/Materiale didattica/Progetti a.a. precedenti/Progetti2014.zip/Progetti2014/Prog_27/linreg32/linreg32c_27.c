/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	return A;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}

/***************************************************************************
*
*                 Mio codice
*
***************************************************************************/


// Metodo per la trasposta
MATRIX trasposta(MATRIX A, int m, int n){
  
    MATRIX B= alloc_matrix(n,m);
    int i,j;

     
    for(i=0;i<m;i++)
      for(j=0;j<n;j++){
                B[m*j+i]=A[i*n+j];
}
         
return B;

}


// Metodo per il prodotto tra 2 matrici
MATRIX prodotto(MATRIX A,MATRIX B, int m1,int n1,int m2,int n2){


if(n1!=m2){
printf("\n DIMENSIONI NON COINCIDENTI!");
}
        int i, j, k;
	MATRIX C = alloc_matrix(m1,n2);
    
       for (i=0;i<m1;i++){
            for(j=0;j<n2;j++){  
                    float elem=0;
                    for(k=0;k<m2;k++){
                      elem= elem+(A[k+i*n1]*B[k*n2+j]);
}
                  C[i*n2+j]=elem; 
}
}

return C;
}





// Creiamo la matrice B | I

MATRIX creaB(MATRIX A, int n){
 int i,j;
printf("\n creaB \n");
MATRIX B=alloc_matrix(n,n*2);


for(i=0;i<n;i++){
   for(j=0;j<n*2;j++){
          if(j<n){
                 B[i*(2*n)+j]=A[i*n+j];}
          else{  int tmp=j-n; 
                 if(i==tmp){
                            B[i*(n*2)+j]=1;
                 }else{
                            B[i*(n*2)+j]=0;
                 }


              }
          }

}



return B;


}




// Primo Metodo ausiliare a Gauss
void sottraiRigheSucc(MATRIX M,int riga,int n,int m){
int i,j;
for(i=riga+1;i<m;i++){
float pivot=M[i*n*2+riga];
	for(j=riga;j<n*2;j++){
		M[i*n*2+j]=M[i*n*2+j]-pivot*M[riga*n*2+j];
}
}

}

// Secondo Metodo ausiliare a Gauss
void dividiRiga(MATRIX M,int riga, int n, float pivot){
int i;
for(i=0;i<n*2;i++){
M[riga*(2*n)+i]=M[riga*(n*2)+i]/pivot;
}

}

// Terzo metodo ausiliare a Gauss
void sottraiRiga(MATRIX M,int riga,int n){
int i,j;

for(i=0;i<riga;i++){
float pivot=M[(i)*(n*2)+riga];
for(j=0;j<n*2;j++){
		M[i*n*2+j]=M[i*n*2+j]-pivot*M[riga*n*2+j];
}
}

}



// Metodo di Gauss per l'inversa
void inverti(MATRIX A,int n){

int i,j;
for(i=0;i<n;i++){
float x=A[i*(n*2)+i];
dividiRiga(A,i,n,x);
sottraiRigheSucc(A,i,n,n);

}




for(i=n-1;i>0;i--){
  sottraiRiga(A,i,n); 
}

}

// Elimina da X la colonna Y
MATRIX ritaglia(MATRIX A,int m,int n){
	int i,j;
	MATRIX RES=alloc_matrix(m,n);

	for(i=0;i<m;i++){
  	 for(j=0;j<n;j++){
                         RES[i*n+j]=A[i*(n+1)+j];}
  
            
          }

return RES;
}



// Divide B|I che sono gestiti come un'unica matrice
MATRIX tagliaInversa(MATRIX X,int m,int n){
MATRIX INT=alloc_matrix(n,n);
int i,j;

for(i=0;i<m;i++){
for(j=0;j<n;j++){
INT[i*n+j]=X[i*n+j+(i+1)*n];

}
}

return INT;
}


// Prodotto matrice vettore
VECTOR prodottoMatriceVettore(MATRIX A,VECTOR Y,int m,int n){
int i,j;

float* beta = get_block(sizeof(float),m);
for(i=0;i<m;i++){
 float elem=0;
   for(j=0;j<n;j++){

     elem+=A[i*n+j]*Y[j];
}
beta[i]=elem;
}

return beta;
}



// Preleva il vettore Y
VECTOR leggiY(MATRIX XY,int m,int n){
  VECTOR y = get_block(sizeof(float),m);
int i,j;
for(i=0;i<m;i++)
for(j=0;j<n+1;j++){
if(j>=n){
y[i]=XY[i*(n+1)+j];
}}

return y;
}



//==============================================================================
/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX Xy, int m, int n) {
    
	
    // -------------------------------------------------
   /* Codice C 


	VECTOR Y=leggiY(Xy,m,n);
	MATRIX X=ritaglia(Xy,m,n);
	

clock_t t = clock(); 

	MATRIX XT=trasposta(X,m,n);
	MATRIX XTX=prodotto(XT,X,n,m,m,n);
	MATRIX B=creaB(XTX,n);
	inverti(B,n);
	MATRIX INT=tagliaInversa(B,n,n);
	MATRIX INT2=prodotto(INT,XT,n,n,n,m);
	VECTOR BETA=prodottoMatriceVettore(INT2,Y,n,m);

t = clock() - t;
printf("\nExecution time = %.3f seconds\n",(((float)t)/CLOCKS_PER_SEC));

free(X);
free(XT);
free(XTX); 
free(B); 
free(Xy); 
free(Y); 
free(INT);

 return BETA;

*/



    /*-------------------------------------------------
    *
    *Codice assembler!!!
    *
    */

	
   

	int i,j;
	VECTOR Y=leggiY(Xy,m,n);
	MATRIX X=ritaglia(Xy,m,n);
	int rig=m/4;	
	int col=n/4;

  
clock_t t = clock(); 
      	MATRIX Xt= alloc_matrix(n,m);
    	traspostaA(X, Xt, rig, col);
	MATRIX XtX= alloc_matrix(n,n);
	prodottoTraspostaA(Xt,Xt,XtX,col,rig);
	MATRIX I= alloc_matrix(n,n);
	inversaA(XtX,I,n,col);
	MATRIX inter=alloc_matrix(n,m);
	prodottoMatriciA(I,Xt,inter,col,col,col,rig);
	VECTOR res = get_block(sizeof(float),n);
	prodottoVettoreA(inter,Y,res,col,rig);
t = clock() - t;


printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);

    return res;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_27.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/


void main(int argc, char** argv) {
	int m =1000;
	int n =1000;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock(); 
	beta = linreg(Xy,m,n);
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
