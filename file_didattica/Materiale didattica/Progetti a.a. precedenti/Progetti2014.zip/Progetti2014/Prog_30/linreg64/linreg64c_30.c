/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 30 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386


Per generare il file eseguibile:

 nasm -f elf64 linreg64.nasm && gcc -O3 -m64 -mavx linreg64.o linreg64c.c -o linreg64c && ./linreg64c
 
 oppure
 
 ./runlinreg64


 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <immintrin.h>



/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*
int stampa = 0;
//int DEFAULT_m = 32;
//int DEFAULT_n = 24;
int DEFAULT_m = 12*128;//* 2*256*2;
int DEFAULT_n = 8*128;//* 2*256*2;

/*
 * Crea un blocco di memoria allineato a 32 byte per utilizzarlo con AVX
 */
void* get_block(int size, int elements) {
    int e = elements*size;
    return _mm_malloc(e, 32);


}

void free_block(void* p) {
    _mm_free(p);
    //    free(p);

}

MATRIX alloc_matrix(int rows, int cols) {
    return (MATRIX) get_block(sizeof (float), rows * cols);
}

void dealloc_matrix(MATRIX mat) {
    free_block(mat);
}

VECTOR alloc_vector(int elem) {
    return (VECTOR) get_block(sizeof (float), elem);
}

void dealloc_vector(VECTOR v) {
    free_block(v);
}

float frand() {
    float r = (float) rand();
    return r / RAND_MAX;
}

/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */

MATRIX random_input(int m, int n) {
    int i, j;
    MATRIX A = alloc_matrix(m, n + 1);
    if (A == NULL) {
        printf("\n<---Memoria Insufficiente (Segmentation Fault)--->\n");
        exit(1);
    }
    float x, y;
    //    float* beta = calloc(n, sizeof (float));
    VECTOR beta = alloc_vector(n);


    //genero un vettore beta casuale
    for (i = 0; i < n; i++)
        beta[i] = frand();
    //        beta[i] = i + 1;

    //            float e = frand()*0.2; //Aggiunta di errore
    for (i = 0; i < m; i++) {
        y = 0;
        for (j = 0; j < n; j++) {
            if (j < n - 1)
                x = frand();
            else
                x = 1.0;
            A[i * (n + 1) + j] = x;
            y += x * beta[j];
        }
        //        y=y*(1+frand()*e-e/2);//Aggiunta di errore
        A[i * (n + 1) + n] = y;
    }

    if (stampa == 1 || stampa == 2) {
        //stampa C
        printf("\n beta :\n");
        for (i = 0; i < n; i++) {
            printf("%f ", beta[i]);
        }
        printf("\n");
    }

    dealloc_vector(beta);
    return A;
}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {
    FILE* fp;
    int rows, cols, status;

    fp = fopen(filename, "rb");
    status = fread(&cols, sizeof (int), 1, fp);
    status = fread(&rows, sizeof (int), 1, fp);
    MATRIX Xy = alloc_matrix(rows, cols);
    status = fread(Xy, sizeof (float), rows*cols, fp);
    fclose(fp);

    *m = rows;
    *n = cols - 1;
    return Xy;
}

/*
 * 
 * 	save_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {
    FILE* fp;
    int status;

    fp = fopen(filename, "wb");
    n++;
    status = fwrite(&n, sizeof (int), 1, fp);
    status = fwrite(&m, sizeof (int), 1, fp);
    status = fwrite(Xy, sizeof (float), m*n, fp);
    fclose(fp);
}

void calculateA(MATRIX Xy, int m, int n, MATRIX A) {



    int i, j, k;

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            float t = 0;
            for (k = 0; k < m; k++) {
                t += Xy[m * i + k] * Xy[m * j + k];
                //                printf("\nA[%d,%d]+=Xy[%f] * Xy[%f]=%f    (%f)",  i, j,Xy[m * i + k],Xy[m * j + k],Xy[m * i + k] * Xy[m * j + k],t);
            }
            A[n * i + j] = t;
        }
    }

//    if (stampa == 1) {
//        //stampa A
//        printf("\nMatrix A=X'*X :");
//        for (i = 0; i < n * n; i++) {
//            if (i % (n) == 0)
//                printf("\n");
//            printf("%.6f ", A[i]);
//        }
//        printf("\n");
//    }


}

void calculateA_BLOCK(MATRIX Xy, int m, int n, MATRIX A) {

    int j, k, jj, kk, i;
    int B = 4;
    for (jj = 0; jj < n; jj += B) {//
        for (i = 0; i < n; i++) {//
            for (kk = 0; kk < m; kk += B) {

                for (j = jj; j < (jj + B < n ? jj + B : n); j += 1) {
                    float temp;
                    if (kk == 0)
                        temp = 0;
                    else
                        temp = A[n * i + j];


                    for (k = kk; k < (kk + B < m ? kk + B : m); k += 1) {
                        temp += Xy[m * i + k] * Xy[m * (j) + k];

                        //                        printf("\nA[%d,%d]+=Xy[%f] * Xy[%f]=%f=Xy[%d,%d] * Xy[%d,%d]    (%f)",  i, j,Xy[m * i + k],Xy[m * j + k],Xy[m * i + k] * Xy[m * j + k],i,k,j,k,temp);
                    }
                    A[n * i + j] = temp;

                }

            }
        }
    }

//    if (stampa == 1) {
//        //stampa A
//        printf("\nMatrix A=X'*X :");
//        for (k = 0; k < n * n; k++) {
//            if (k % (n) == 0)
//                printf("\n");
//            printf("%f ", A[k]);
//        }
//        printf("\n");
//    }


}

void calculateA_SSE_BLOCK(MATRIX Xy, int m, int n, MATRIX A) {

    int j, k, jj, kk, i;
    int B = 32;
    for (jj = 0; jj < n; jj += B) {//
        for (i = jj; i < n; i++) {//
            for (kk = 0; kk < m; kk += B) {

                for (j = jj; j < (jj + B < i + 1 ? jj + B : i + 1); j += 1) {
                    __m128 t = _mm_xor_ps(t, t);
                    float temp;
                    if (kk == 0)
                        temp = 0;
                    else
                        temp = A[n * i + j];

                    for (k = kk; k < (kk + B < m ? kk + B : m); k += 4) {

                        __m128 p1 = _mm_load_ps(&Xy[m * i + k]);
                        __m128 p2 = _mm_load_ps(&Xy[m * (j) + k]);
                        t = _mm_add_ps(t, _mm_mul_ps(p1, p2));
                    }
                    __m128 t2 = _mm_movehl_ps(t2, t);
                    t = _mm_add_ps(t, t2);
                    t2 = _mm_shuffle_ps(t, t, 0x55);
                    t = _mm_add_ps(t, t2);
                    float temp2;
                    _mm_store_ss(&temp2, t);
                    _mm_store_ss(&A[n * i + j], t);
                    A[n * i + j] = temp + temp2;

                }

            }
        }
    }

//    if (stampa == 1) {
//        //stampa A
//        printf("\nMatrix A=X'*X :");
//        for (k = 0; k < n * n; k++) {
//            if (k % (n) == 0)
//                printf("\n");
//            printf("%f ", A[k]);
//        }
//        printf("\n");
//    }


}

void calculateA_SSE_4x4(MATRIX Xy, int m, int n, MATRIX A) {

    int j, k, i;
    int B = 4;


    for (i = 0; i < n; i += B)
        for (j = 0; j < i + 1; j += B) {
            for (k = 0; k < m; k += B) {


                //A[i, j] = A[i, j] + X[i, k] * X[j,k]

                //Carico le colonne di X 
                __m128 xmm4 = _mm_load_ps(&Xy[m * j + k]);
                __m128 xmm5 = _mm_load_ps(&Xy[m * (j + 1) + k]);
                __m128 xmm6 = _mm_load_ps(&Xy[m * (j + 2) + k]);
                __m128 xmm7 = _mm_load_ps(&Xy[m * (j + 3) + k]);
                
                __m128 xmm0,xmm1,xmm2,xmm3;

                //Riga 1: 
                xmm0 = _mm_load_ps(&Xy[m * i + k]); //carico X^T 
                
                xmm1 = _mm_mul_ps(xmm0, xmm4); //mulps xmm0, xmm4
                xmm2 =  _mm_mul_ps(xmm0, xmm5); //mulps xmm1, xmm5                
                xmm1 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1
                
                xmm2 = _mm_mul_ps(xmm0, xmm6); //mulps xmm1, xmm6
                xmm3 = _mm_mul_ps(xmm0, xmm7); //mulps xmm2, xmm7
                xmm2 = _mm_hadd_ps(xmm2, xmm3); //haddps xmm1, xmm2
                
                xmm0 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1
                
                xmm3 = _mm_load_ps(&A[n * i + j]);
                xmm0 = _mm_add_ps(xmm0, xmm3); //addps xmm0, xmm3 

                _mm_store_ps(&A[n * i + j], xmm0); //movaps [A], xmm0


                //Riga 2: 
                xmm0 = _mm_load_ps(&Xy[m * (i + 1) + k]); //carico X^T
                
                xmm1 = _mm_mul_ps(xmm0, xmm4); //mulps xmm0, xmm4
                xmm2 =  _mm_mul_ps(xmm0, xmm5); //mulps xmm1, xmm5                
                xmm1 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1
                
                xmm2 = _mm_mul_ps(xmm0, xmm6); //mulps xmm1, xmm6
                xmm3 = _mm_mul_ps(xmm0, xmm7); //mulps xmm2, xmm7
                xmm2 = _mm_hadd_ps(xmm2, xmm3); //haddps xmm1, xmm2
                
                xmm0 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1

                xmm3 = _mm_load_ps(&A[n * (i + 1) + j]);
                xmm0 = _mm_add_ps(xmm0, xmm3); //addps xmm0, xmm3              

                _mm_store_ps(&A[n * (i + 1) + j], xmm0); //movaps [A], xmm0

                //Riga 3: 
                xmm0 = _mm_load_ps(&Xy[m * (i + 2) + k]); //carico X^T 
                
                xmm1 = _mm_mul_ps(xmm0, xmm4); //mulps xmm0, xmm4
                xmm2 =  _mm_mul_ps(xmm0, xmm5); //mulps xmm1, xmm5                
                xmm1 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1
                
                xmm2 = _mm_mul_ps(xmm0, xmm6); //mulps xmm1, xmm6
                xmm3 = _mm_mul_ps(xmm0, xmm7); //mulps xmm2, xmm7
                xmm2 = _mm_hadd_ps(xmm2, xmm3); //haddps xmm1, xmm2
                
                xmm0 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1

                xmm3 = _mm_load_ps(&A[n * (i + 2) + j]);
                xmm0 = _mm_add_ps(xmm0, xmm3); //addps xmm0, xmm3              

                _mm_store_ps(&A[n * (i + 2) + j], xmm0); //movaps [A], xmm0


                //X'[1,:] * X 
                xmm0 = _mm_load_ps(&Xy[m * (i + 3) + k]); //carico X^T
                
                xmm1 = _mm_mul_ps(xmm0, xmm4); //mulps xmm0, xmm4
                xmm2 =  _mm_mul_ps(xmm0, xmm5); //mulps xmm1, xmm5                
                xmm1 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1
                
                xmm2 = _mm_mul_ps(xmm0, xmm6); //mulps xmm1, xmm6
                xmm3 = _mm_mul_ps(xmm0, xmm7); //mulps xmm2, xmm7
                xmm2 = _mm_hadd_ps(xmm2, xmm3); //haddps xmm1, xmm2
                
                xmm0 = _mm_hadd_ps(xmm1, xmm2); //haddps xmm0, xmm1

                xmm3 = _mm_load_ps(&A[n * (i + 3) + j]);
                xmm0 = _mm_add_ps(xmm0, xmm3); //addps xmm0, xmm3              

                _mm_store_ps(&A[n * (i + 3) + j], xmm0); //movaps [A], xmm0
            }
        }

//    if (stampa == 1) {
//        //stampa A
//        printf("\nMatrix A=X'*X :");
//        for (k = 0; k < n * n; k++) {
//            if (k % (n) == 0)
//                printf("\n");
//            printf("%f ", A[k]);
//        }
//        printf("\n");
//    }
}

void calculateA_AVX_8x8(MATRIX Xy, int m, int n, MATRIX A) {

    
    int j, k, i;
    int B = 8;


    for (i = 0; i < n; i += B) {
        for (j = 0; j < i + 1; j += B) {
            for (k = 0; k < m; k += B) {




                //A[i, j] = A[i, j] + X[i, k] * X[j,k]

                //Carico le 8 Colonne di X
                __m256 ymm8 = _mm256_load_ps(&Xy[m * j + k]);
                __m256 ymm9 = _mm256_load_ps(&Xy[m * (j + 1) + k]);
                __m256 ymm10 = _mm256_load_ps(&Xy[m * (j + 2) + k]);
                __m256 ymm11 = _mm256_load_ps(&Xy[m * (j + 3) + k]);
                __m256 ymm12 = _mm256_load_ps(&Xy[m * (j + 4) + k]);
                __m256 ymm13 = _mm256_load_ps(&Xy[m * (j + 5) + k]);
                __m256 ymm14 = _mm256_load_ps(&Xy[m * (j + 6) + k]);
                __m256 ymm15 = _mm256_load_ps(&Xy[m * (j + 7) + k]);



                __m256 ymm0, ymm1, ymm2, ymm3, ymm4, ymm5, ymm6, ymm7;




                //Riga 1:  
                ymm0 = _mm256_load_ps(&Xy[m * i + k]); //carico X^T

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh


                ymm1 = _mm256_load_ps(&A[n * (i) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * i + j], ymm6); // [A], ymm6       



                //Riga 2: 
                ymm0 = _mm256_load_ps(&Xy[m * (i + 1) + k]); //carico X^T 

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh

                ymm1 = _mm256_load_ps(&A[n * (i + 1) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * (i + 1) + j], ymm6); // [A], ymm6  



                //Riga 3: 
                ymm0 = _mm256_load_ps(&Xy[m * (i + 2) + k]); //carico X^T  

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh

                ymm1 = _mm256_load_ps(&A[n * (i + 2) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * (i + 2) + j], ymm6); // [A], ymm6  



                //Riga 4: 
                ymm0 = _mm256_load_ps(&Xy[m * (i + 3) + k]); //carico X^T 

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh

                ymm1 = _mm256_load_ps(&A[n * (i + 3) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * (i + 3) + j], ymm6); // [A], ymm6  




                //Riga 5: 
                ymm0 = _mm256_load_ps(&Xy[m * (i + 4) + k]); //carico X^T 

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh

                ymm1 = _mm256_load_ps(&A[n * (i + 4) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * (i + 4) + j], ymm6); // [A], ymm6  



                //Riga 6: 
                ymm0 = _mm256_load_ps(&Xy[m * (i + 5) + k]); //carico X^T  

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh

                ymm1 = _mm256_load_ps(&A[n * (i + 5) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * (i + 5) + j], ymm6); // [A], ymm6  



                //Riga 7: 
                ymm0 = _mm256_load_ps(&Xy[m * (i + 6) + k]); //carico X^T 

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh

                ymm1 = _mm256_load_ps(&A[n * (i + 6) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * (i + 6) + j], ymm6); // [A], ymm6  



                //Riga8: 
                ymm0 = _mm256_load_ps(&Xy[m * (i + 7) + k]); //carico X^T 

                ymm1 = _mm256_mul_ps(ymm0, ymm8); //aa-aa-aa-aa
                ymm2 = _mm256_mul_ps(ymm0, ymm9); //bb-bb-bb-bb
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb    

                ymm3 = _mm256_mul_ps(ymm0, ymm10); //cc-cc-cc-cc
                ymm4 = _mm256_mul_ps(ymm0, ymm11); //dd-dd-dd-dd
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd    

                ymm5 = _mm256_mul_ps(ymm0, ymm12); //ee-ee-ee-ee
                ymm6 = _mm256_mul_ps(ymm0, ymm13); //ff-ff-ff-ff
                ymm4 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff   //ymm6 utilizzabile

                ymm7 = _mm256_mul_ps(ymm0, ymm14); //gg-gg-gg-gg
                ymm6 = _mm256_mul_ps(ymm0, ymm15); //hh-hh-hh
                ymm7 = _mm256_hadd_ps(ymm7, ymm6); //gg-hh-gg-hh  ymm6 utilizzabile

                ymm6 = _mm256_permute2f128_ps(ymm1, ymm4, 0x30); //aa-bb-ee-ff //48    
                ymm1 = _mm256_permute2f128_ps(ymm1, ymm4, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm1, ymm6); //aa-bb-ee-ff

                ymm6 = _mm256_permute2f128_ps(ymm2, ymm7, 0x30); //cc-dd-gg-hh
                ymm2 = _mm256_permute2f128_ps(ymm2, ymm7, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm2, ymm6); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh

                ymm1 = _mm256_load_ps(&A[n * (i + 7) + j]);
                ymm6 = _mm256_add_ps(ymm1, ymm6); //addps xmm0, xmm3   
                _mm256_store_ps(&A[n * (i + 7) + j], ymm6); // [A], ymm6  

            }

        }
    }

//    if (stampa == 1) {
//        //stampa A
//        printf("\nMatrix A=X'*X :");
//        for (k = 0; k < n * n; k++) {
//            if (k % (n) == 0)
//                printf("\n");
//            printf("%f ", A[k]);
//        }
//        printf("\n");
//    }
}

void calculateC(MATRIX Xy, int m, int n, VECTOR C) {



    int i, j;
    for (i = 0; i < n; i++) {
        float t = 0;
        for (j = 0; j < m; j++) {

            t += Xy[i * m + j] * Xy[n * m + j];
        }
        C[i] = t;
    }

//    if (stampa == 1) {
//        int i;
//        //stampa C
//        printf("\n C=X'*y :\n");
//        for (i = 0; i < n; i++) {
//            printf("%f ", C[i]);
//        }
//        printf("\n");
//
//
//    }
//
//    int l;
//    float s = 0;
//    for (l = 0; l < m; l++) {
//        s += Xy[m * n + l];
//    }
//    printf("\ncorrect: %f --  %f", s, C[n - 1]);


}

void calculateC_SSE(MATRIX Xy, int m, int n, VECTOR C) {

    //    calculateCv2_32(Xy, m, n, C); //Chiamata funzione Assembly
    int i, j;
    for (i = 0; i < n; i++) {
        __m128 t;

        t = _mm_xor_ps(t, t);
        for (j = 0; j < m; j += 4) {
            __m128 p1 = _mm_load_ps(&Xy[i * m + j]);
            __m128 p2 = _mm_load_ps(&Xy[n * m + j]);

            t = _mm_add_ps(t, _mm_mul_ps(p1, p2));
        }
        t = _mm_hadd_ps(t, t);
        t = _mm_hadd_ps(t, t);
        //        __m128 t2 = _mm_set_ps(0, 0, 0, 0);
        //        t2 = _mm_movehl_ps(t2, t);
        //        t = _mm_add_ps(t, t2);
        //        t2 = _mm_shuffle_ps(t, t, 0x55); //00-11-01-11
        //        t = _mm_add_ps(t, t2);
        _mm_store_ss(&C[i], t);

    }

    //     for (i = 0; i < n; i++) {
    //        float t = 0;
    //        for (j = 0; j < m; j++) {
    //            
    //            t += Xy[i * m + j] * Xy[n * m + j];
    //        }
    //        C[i] = t;
    //    }

    //    calculateC_32(Xy,C,m,n);//Chiamata funzione Assembly

    //    int i, j, jj, k, kk;
    //    int B = 24;
    //    for (jj = 0; jj < n; jj += B) {//righe
    //        for (kk = 0; kk < m; kk += B) {//colonne
    //
    //            //per ogni blocco jj-ii
    //            for (j = jj; j < (jj + B < n ? jj + B : n); j += 1) {//righe blocco
    //                float temp;
    //                if (kk == 0)
    //                    temp = 0;
    //                else
    //                    temp = C[j];
    //                for (k = kk; k < (kk + B < m ? kk + B : m); k += 1) {//colonne blocco
    //                    temp += Xy[m * j + k] * Xy[m * n + k];
    //                    //                    printf("\nC[%d]+=Xy[%d][%d] * C[%d]=%f*%f=%f(%f)", j, j, k, k, Xy[m * j + k], Xy[m * n + k], Xy[m * j + k] * Xy[m * n + k], temp);
    //                }
    //                C[j] = temp;
    //            }
    //        }
    //    }


//
//    if (stampa == 1) {
//        //stampa C
//        printf("\n C=X'*y :\n");
//        for (i = 0; i < n; i++) {
//            printf("%f ", C[i]);
//        }
//        printf("\n");
//
//
//    }




}
void calculateC_SSE_4x1(MATRIX Xy, int m, int n, VECTOR C) {

        //    calculateC_SSE_4x1_64(Xy, m, n, C); //Chiamata funzione Assembly

        int B = 4;
        int i, j;
        for (i = 0; i < n; i += B) {            
            for (j = 0; j < m; j += B) {

                __m128 xmm0, xmm1, xmm2, xmm3, xmm4;

                xmm0 = _mm_load_ps(&Xy[n * m + j]);

                xmm1 = _mm_load_ps(&Xy[i * m + j]);
                xmm2 = _mm_load_ps(&Xy[(i + 1) * m + j]);
                xmm3 = _mm_load_ps(&Xy[(i + 2) * m + j]);
                xmm4 = _mm_load_ps(&Xy[(i + 3) * m + j]);

                xmm1 = _mm_mul_ps(xmm1, xmm0);
                xmm2 = _mm_mul_ps(xmm2, xmm0);
                xmm3 = _mm_mul_ps(xmm3, xmm0);
                xmm4 = _mm_mul_ps(xmm4, xmm0);

                xmm1 = _mm_hadd_ps(xmm1, xmm2);
                xmm2 = _mm_hadd_ps(xmm3, xmm4);

                xmm3 = _mm_hadd_ps(xmm1, xmm2);

                xmm4 = _mm_load_ps(&C[i]);
                xmm1 = _mm_add_ps(xmm3, xmm4);

                _mm_store_ps(&C[i], xmm1);
            }

        }

    }
void calculateC_AVX(MATRIX Xy, int m, int n, VECTOR C) {

    
    int i, j;
    for (i = 0; i < n; i++) {
        __m256 t;

        t = _mm256_xor_ps(t, t);
        for (j = 0; j < m; j += 8) {
            __m256 p1 = _mm256_load_ps(&Xy[i * m + j]);
            __m256 p2 = _mm256_load_ps(&Xy[n * m + j]);

            t = _mm256_add_ps(t, _mm256_mul_ps(p1, p2));
        }
        t = _mm256_hadd_ps(t, t);
        t = _mm256_hadd_ps(t, t);
        __m256 temp3=_mm256_permute2f128_ps(t , t, 1);
        t=_mm256_add_ps(t, temp3);
        
        _mm_store_ss(&C[i], _mm256_extractf128_ps(t,0x0));

    }

   


//    if (stampa == 1) {
//        //stampa C
//        printf("\n C=X'*y :\n");
//        for (i = 0; i < n; i++) {
//            printf("%f ", C[i]);
//        }
//        printf("\n");
//
//
//    }




}
void calculateC_AVX_4x1(MATRIX Xy, int m, int n, VECTOR C) {

        //    calculateC_AVX_4x1_64(Xy, m, n, C); //Chiamata funzione Assembly

        int B = 8;
        int i, j;
        for (i = 0; i < n; i += B) {            
            for (j = 0; j < m; j += B) {

                __m256 ymm0, ymm1, ymm2, ymm3, ymm4,ymm5, ymm6, ymm7, ymm8;

                ymm0 = _mm256_load_ps(&Xy[n * m + j]);

                ymm1 = _mm256_load_ps(&Xy[i * m + j]);
                ymm2 = _mm256_load_ps(&Xy[(i + 1) * m + j]);
                ymm3 = _mm256_load_ps(&Xy[(i + 2) * m + j]);
                ymm4 = _mm256_load_ps(&Xy[(i + 3) * m + j]);
                ymm5 = _mm256_load_ps(&Xy[(i + 4) * m + j]);
                ymm6 = _mm256_load_ps(&Xy[(i + 5) * m + j]);
                ymm7 = _mm256_load_ps(&Xy[(i + 6) * m + j]);
                ymm8 = _mm256_load_ps(&Xy[(i + 7) * m + j]);

                ymm1 = _mm256_mul_ps(ymm1, ymm0);
                ymm2 = _mm256_mul_ps(ymm2, ymm0);
                ymm1 = _mm256_hadd_ps(ymm1, ymm2); //aa-bb-aa-bb
                
                ymm3 = _mm256_mul_ps(ymm3, ymm0);
                ymm4 = _mm256_mul_ps(ymm4, ymm0);
                ymm2 = _mm256_hadd_ps(ymm3, ymm4); //cc-dd-cc-dd  
                
                ymm5 = _mm256_mul_ps(ymm5, ymm0);
                ymm6 = _mm256_mul_ps(ymm6, ymm0);
                ymm3 = _mm256_hadd_ps(ymm5, ymm6); //ee-ff-ee-ff 
                
                ymm7 = _mm256_mul_ps(ymm7, ymm0);
                ymm8 = _mm256_mul_ps(ymm8, ymm0);
                ymm4 = _mm256_hadd_ps(ymm7, ymm8); //gg-hh-gg-hh 
                
                ymm5 = _mm256_permute2f128_ps(ymm1, ymm3, 0x30); //aa-bb-ee-ff //48    
                ymm6 = _mm256_permute2f128_ps(ymm1, ymm3, 0x21); //aa-bb-ee-ff //33    
                ymm1 = _mm256_add_ps(ymm5, ymm6); //aa-bb-ee-ff

                ymm7 = _mm256_permute2f128_ps(ymm2, ymm4, 0x30); //cc-dd-gg-hh
                ymm8 = _mm256_permute2f128_ps(ymm2, ymm4, 0x21); //cc-dd-gg-hh
                ymm2 = _mm256_add_ps(ymm7, ymm8); //cc-dd-gg-hh

                ymm6 = _mm256_hadd_ps(ymm1, ymm2); //ab-cd-ef-gh
                
                ymm4 = _mm256_load_ps(&C[i]);
                ymm1 = _mm256_add_ps(ymm6, ymm4);

                _mm256_store_ps(&C[i], ymm1);              
                
                
            }

        }


    }
void cholesky(MATRIX A, int n, MATRIX L) {
    //calcola gli elementi riga per riga
    int i, j, k;
    for (i = 0; i < n; i++)
        for (j = 0; j < (i + 1); j++) {
            float s = 0;
            for (k = 0; k < j; k++)
                s += L[i * n + k] * L[j * n + k];
            float d = (A[i * n + j] - s);

            if (i == j) {
                L[i * n + i] = (float) sqrt(d);
            } else {
                L[i * n + j] = (1.0 / L[j * n + j] * d);

            }
        }

//    if (stampa == 1) {
//        //stampa L
//        printf("\nMatrix L:");
//        for (i = 0; i < n * n; i++) {
//            if (i % (n) == 0)
//                printf("\n");
//            printf("%f ", L[i]);
//        }
//        printf("\n");
//    }


}

void cholesky_SSE(MATRIX A, int n, MATRIX L) {

    int i, j, k;
    for (i = 0; i < n; i++)
        for (j = 0; j < (i + 1); j++) {
            float s = 0;
            __m128 temp2;
            temp2 = _mm_xor_ps(temp2, temp2);

            for (k = 0; k < j; k++) {
                if (i < 4 || j < 4 || j - k < 4)
                    s += L[i * n + k] * L[j * n + k];
                else {
                    //                    printf("L[%d,%d]", i, j);
                    __m128 p1 = _mm_load_ps(&L[i * n + k]);
                    __m128 p2 = _mm_load_ps(&L[j * n + k]);
                    temp2 = _mm_add_ps(temp2, _mm_mul_ps(p1, p2));
                    k += 3;
                }

            }
            temp2 = _mm_hadd_ps(temp2, temp2);
            temp2 = _mm_hadd_ps(temp2, temp2);
            float t;
            _mm_store_ss(&t, temp2);
            s += t;
            if (i == j) {
                float d = (A[i * n + i] - s);

                L[i * n + j] = (float) sqrt(d);
            } else {
                L[i * n + j] = (1.0 / L[j * n + j]*(A[i * n + j] - s));

            }
        }
    //
    //    if (stampa == 1) {
    //        //stampa L
    //        printf("\nMatrix L:");
    //        for (i = 0; i < n * n; i++) {
    //            if (i % (n) == 0)
    //                printf("\n");
    //            printf("%f ", L[i]);
    //        }
    //        printf("\n");
    //    }


}


void cholesky_AVX(MATRIX A, int n, MATRIX L) {

    int i, j, k;
    for (i = 0; i < n; i++)
        for (j = 0; j < (i + 1); j++) {
            float s = 0;
            __m256 temp2;
            temp2 = _mm256_xor_ps(temp2, temp2);

            for (k = 0; k < j; k++) {
                if (i < 8 || j < 8 || j - k < 8)
                    s += L[i * n + k] * L[j * n + k];
                else {
                    //                    printf("L[%d,%d]", i, j);
                    __m256 p1 = _mm256_load_ps(&L[i * n + k]);
                    __m256 p2 = _mm256_load_ps(&L[j * n + k]);
                    temp2 = _mm256_add_ps(temp2, _mm256_mul_ps(p1, p2));
                    k += 7;
                }

            }
            temp2 = _mm256_hadd_ps(temp2, temp2);
            temp2 = _mm256_hadd_ps(temp2, temp2);
            __m256 temp3=_mm256_permute2f128_ps(temp2 , temp2 , 1);
            temp2=_mm256_add_ps(temp2, temp3);
            float t;
            _mm_store_ss(&t, _mm256_extractf128_ps(temp2,0x0));
            s += t;
            if (i == j) {
                float d = (A[i * n + i] - s);

                L[i * n + j] = (float) sqrt(d);
            } else {
                L[i * n + j] = (1.0 / L[j * n + j]*(A[i * n + j] - s));

            }
        }

//    if (stampa == 1) {
//        //stampa L
//        printf("\nMatrix L:");
//        for (i = 0; i < n * n; i++) {
//            if (i % (n) == 0)
//                printf("\n");
//            printf("%f ", L[i]);
//        }
//        printf("\n");
//    }


}

void calculateY(MATRIX L, VECTOR C, int n, VECTOR Y) {

    //forward substitution Ly=C
    int i, j;
    for (i = 0; i < n; i++) {
        Y[i] = C[i];
        for (j = 0; j < i; j++) {
            Y[i] -= L[n * i + j] * Y[j];
        }
        Y[i] /= L[n * i + i];
    }

    //    if (stampa == 1) {
    //        //stampa y
    //        printf("\n y :\n");
    //        for (i = 0; i < n; i++) {
    //            printf("%f ", y[i]);
    //        }
    //        printf("\n");
    //    }

}

void calculateY_SSE(MATRIX L, VECTOR C, int n, VECTOR Y) {

    //forward substitution Ly=C
    int i, j;
    for (i = 0; i < n; i++) {
        Y[i] = C[i];
        __m128 temp2;
        temp2 = _mm_xor_ps(temp2, temp2);
        for (j = 0; j < i; j++) {
            if (j < 4 || i - j < 4) {
                Y[i] -= L[n * i + j] * Y[j];
            } else {
                __m128 lij = _mm_load_ps(&L[i * n + j]);
                __m128 yj = _mm_load_ps(&Y[j]);
                temp2 = _mm_add_ps(temp2, _mm_mul_ps(lij, yj));
                j += 3;
            }
        }

        temp2 = _mm_hadd_ps(temp2, temp2);
        temp2 = _mm_hadd_ps(temp2, temp2);
        float t;
        _mm_store_ss(&t, temp2);
        Y[i] -= t;

        Y[i] /= L[n * i + i];
    }

    //    if (stampa == 1) {
    //        //stampa y
    //        printf("\n y :\n");
    //        for (i = 0; i < n; i++) {
    //            printf("%f ", y[i]);
    //        }
    //        printf("\n");
    //    }

}


void calculateY_AVX(MATRIX L, VECTOR C, int n, VECTOR Y) {

    //forward substitution Ly=C
    int i, j;
    for (i = 0; i < n; i++) {
        Y[i] = C[i];
        __m256 temp2;
        temp2 = _mm256_xor_ps(temp2, temp2);
        for (j = 0; j < i; j++) {
            if (j < 8 || i - j < 8) {
                Y[i] -= L[n * i + j] * Y[j];
            } else {
                __m256 lij = _mm256_load_ps(&L[i * n + j]);
                __m256 yj = _mm256_load_ps(&Y[j]);
                temp2 = _mm256_add_ps(temp2, _mm256_mul_ps(lij, yj));
                j += 7;
            }
        }

        temp2 = _mm256_hadd_ps(temp2, temp2);
        temp2 = _mm256_hadd_ps(temp2, temp2);
        __m256 temp3=_mm256_permute2f128_ps(temp2 , temp2 , 1);
        float t;
        _mm_store_ss(&t, _mm256_extractf128_ps(temp3,0x0));
        Y[i] -= t;

        Y[i] /= L[n * i + i];
    }

    //    if (stampa == 1) {
    //        //stampa y
    //        printf("\n y :\n");
    //        for (i = 0; i < n; i++) {
    //            printf("%f ", y[i]);
    //        }
    //        printf("\n");
    //    }

}


void calculateBeta(MATRIX L, VECTOR Y, int n, VECTOR b) {


    int i, j;

    //back substitution L'b=y
    for (i = n - 1; i >= 0; i--) {
        b[i] = Y[i];

        for (j = i + 1; j < n; j++) {
            b[i] -= L[n * j + i] * b[j];
        }
        b[i] /= L[n * i + i];
    }

//    if (stampa == 1 || stampa == 2) {
//        //stampa C
//        printf("\n beta :\n");
//        for (i = 0; i < n; i++) {
//            printf("%f ", b[i]);
//        }
//        printf("\n");
//    }



}

//void calculateBeta_SSE(MATRIX L, VECTOR Y, int n, VECTOR b) {
//
//
//    int i, j;
//
//    //back substitution L'b=y
//    for (i = n - 1; i >= 0; i--) {
//        b[i] = Y[i];
//        __m128 temp2;
//        temp2 = _mm_xor_ps(temp2, temp2);
//        for (j = i + 1; j < n; j++) {
//
//
//            if (i < 4 || j < 4 || n - j < 4) {
//                b[i] -= L[n * j + i] * b[j];
//            } else {
//                //                    printf("L[%d,%d]", i, j);
//                __m128 lji = _mm_loadu_ps(&L[j * n + i]);
//                __m128 bj = _mm_loadu_ps(&b[j]);
//                temp2 = _mm_add_ps(temp2, _mm_mul_ps(lji, bj));
//                j += 3;
//            }
//        }
//
//        temp2 = _mm_hadd_ps(temp2, temp2);
//        temp2 = _mm_hadd_ps(temp2, temp2);
//        float t;
//        _mm_store_ss(&t, temp2);
//        b[i] -= t;
//        b[i] /= L[n * i + i];
//    }
//
//    if (stampa == 1 || stampa == 2) {
//        //stampa C
//        printf("\n beta :\n");
//        for (i = 0; i < n; i++) {
//            printf("%f ", b[i]);
//        }
//        printf("\n");
//    }
//}

/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione  (n+1)xM in cui le prime n
 *	righe rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima riga rappresenta la variabile dipendente y;
 * 	ogni colonna contiene una osservazione (nelle prime n righe)
 * 	e l'associato valore della variabile dipendente (nell'ultima riga).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX Xy, int m, int n) {

    if (m % 4 != 0 || n % 4 != 0) {
        printf("\nSpiacente! L'algoritmo supporta solo matrici di dimensione multipla di 4.");
        exit(0);
    }

    clock_t t;
    int i;

    
    //-----------FASE 1---------CALCOLO DELLA MATRICE A----------------

 
    MATRIX A = alloc_matrix(n, n);
     if (A == NULL) {
        printf("\n<---Memoria Insufficiente (Segmentation Fault)--->\n");
        exit(1);
    }
    
///*

    //imposto a zero gli elementi di A
    for (i = 0; i < n*n; i++) A[i] = 0;


    

    //calcolo A=X'*X
    t = clock();
    if (n % 8 == 0 && m % 8 == 0)//le dimensioni sono multiple di 8
        calculateA_AVX_8x8(Xy, m, n, A);
    else
        calculateA_SSE_4x4(Xy, m, n, A);

    t = clock() - t;
    printf("\nCALCOLO DELLA MATRICE A = %.3f seconds\n", ((float) t) / CLOCKS_PER_SEC);


//    printf("m=%d  %f", m, A[n * n - 1]);


   

    
    

    //-----------FASE 2---------CALCOLO DEL VETTORE DEI TERMINI NOTI------------------------  

    VECTOR C = alloc_vector(n);
    if (C == NULL) {
        printf("\n<---Memoria Insufficiente (Segmentation Fault)--->\n");
        exit(1);
    }


    //calcolo C=X'*y
    for (i = 0; i < n; i++) C[i] = 0;
    t = clock();
    if (n % 8 == 0 && m % 8 == 0)//le dimensioni sono multiple di 8
        calculateC_AVX_4x1(Xy, m, n, C);
    else
        calculateC_SSE_4x1(Xy, m, n, C);
    
    t = clock() - t;
    //    printf("\nCALCOLO DEL VETTORE C= %.3f seconds\n", ((float) t) / CLOCKS_PER_SEC);





    //-----------FASE 3---------FATTORIZZAZIONE DI CHOLESKY------------------------


    //Calcolo la matrice triangolare tramite la decomposizione di Cholesky
    MATRIX L = alloc_matrix(n, n);
    if (L == NULL) {
        printf("\n<---Memoria Insufficiente (Segmentation Fault)--->\n");
        exit(1);
    }

    //imposto a zero gli elementi di L

    for (i = 0; i < n * n; i++) L[i] = 0;

    t = clock();
    
    if (n % 8 == 0 && m % 8 == 0)//le dimensioni sono multiple di 8
        cholesky_AVX(A, n, L);
    else
        cholesky_SSE(A, n, L);
    
    t = clock() - t;
    //    printf("\nFATTORIZZAZIONE DI CHOLESKY = %.3f seconds\n", ((float) t) / CLOCKS_PER_SEC);



    //    for (i = 0; i < n; i++) C[i] = 0;
    //    t = clock();
    //    choleskyv2(A, n, L);
    //    t = clock() - t;
    //    printf("\ncholeskyv2= %.3f seconds\n", ((float) t) / CLOCKS_PER_SEC);

    
    //Libero la memoria
    dealloc_matrix(A);



    //-----------FASE 4---------CALCOLO DEL VETTORE BETA------------------------  

    //Risolvo il sistema triangolare basso Ly=c
    VECTOR Y = alloc_vector(n);
    //imposto a zero gli elementi di Y
    for (i = 0; i < n; i++) Y[i] = 0;

    if (n % 8 == 0 && m % 8 == 0)//le dimensioni sono multiple di 8
        calculateY(L, C, n, Y);
    else
        calculateY(L, C, n, Y);
    



    //Calcolo beta risolvendo il sistema lineare basso L'b=y  

    VECTOR beta = alloc_vector(n);
    //imposto a zero gli elementi di beta
    for (i = 0; i < n; i++) beta[i] = 0;


    calculateBeta(L, Y, n, beta);

//*/
    return beta;




}

/*
 *  
 * 
 *  Dispone la matrice  Xy in Column Major Order
 *  
 *  
 */
MATRIX changeInput(MATRIX Xy, int m, int n) {

    
    MATRIX X = alloc_matrix(m, n + 1);
    if (X == NULL) {
        printf("\n<---Memoria Insufficiente (Segmentation Fault)--->\n");
        exit(1);
    }
    int i, j;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n + 1; j++) {
            X[m * j + i] = Xy[i * (n + 1) + j]; //Column Major Order            
        }
    }

    if (stampa == 1) {
        //stampa X
        printf("\nInput matrix Xy:");
        for (i = 0; i < m * (n + 1); i++) {

            if (i % (m) == 0)
                printf("\n");
            printf("%f ", X[i]);
        }
        printf("\n");
    }
    return X;

}


MATRIX changeInput2(MATRIX Xy, int m, int n) {

    int B=8;
    int mPadding = B-(m%B);
    int nPadding = B-(n%B);
    
    MATRIX X = alloc_matrix(m+mPadding, n + 1+mPadding);
    
    if (X == NULL) {
        printf("\n<---Memoria Insufficiente (Segmentation Fault)--->\n");
        exit(1);
    }
    int i, j;
    for (i = 0; i < m+mPadding; i++) {
        for (j = 0; j < n+nPadding+1 ; j++) {
            if(i<m&&j<n)
                X[(m+mPadding) * j + i] = Xy[i * (n + 1) + j]; //Column Major Order 
            else
                X[(m+mPadding) * j + i]=0;
        }
    }
    for (j = 0; j < m ; j++) {
            X[(m+mPadding) * (n+nPadding) + j] = Xy[n * (n + 1) + j]; //Column Major Order            
        }
   

    if (stampa == 1) {
        //stampa X
        printf("\nInput matrix Xy:");
        for (i = 0; i < (m+mPadding) * (n+nPadding + 1); i++) {

            if (i % (m+mPadding) == 0)
                printf("\n");
            printf("%f ", X[i]);
        }
        printf("\n");
    }
    return X;

}


/*
 * 
 * 	error(modificato)
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
    int i, j;
    float err = 0, de, yp;

    for (i = 0; i < m; i++) {
        yp = 0;
        for (j = 0; j < n; j++)
            yp += Xy[j * m + i] * beta[j]; //Column Major Order
        de = fabs(Xy[m * n + i] - yp);
        err += (de * de);
    }

    return err;
}




/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_30.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/




/*          
 *              main
 * 
 *              Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)> 
                Parameters:
                -l <file_name> : reads from disk the augmented m x (n+1) matrix
                -r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix
                -f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)
                -d : displays input and output
                -s : silent
 */
void main(int argc, char** argv) {
    int m = DEFAULT_m;
    int n = DEFAULT_n;
    MATRIX Xy;
    VECTOR beta;

    char* filename = "";
    int silent = 0, display = 0, fsave = 0;
    int i;

    //inizializzazione random
    srandom(time(NULL));


    //lettura parametri riga di comando
    int par = 1;
    while (par < argc) {
        if (strcmp(argv[par], "-l") == 0) {
            par++;
            if (par < argc) {
                filename = argv[par];
                par++;
            }
        } else if (strcmp(argv[par], "-r") == 0) {
            par++;
            if (par < argc) {
                m = atoi(argv[par]);
                par++;
                if (par < argc) {
                    n = atoi(argv[par]);
                    par++;
                }
            }
        } else if (strcmp(argv[par], "-f") == 0) {
            fsave = 1;
            par++;
        } else if (strcmp(argv[par], "-s") == 0) {
            silent = 1;
            par++;
        } else if (strcmp(argv[par], "-d") == 0) {
            display = 1;
            par++;
        } else
            par++;
    }

    if (!silent) {
        printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
        printf("\nParameters:\n");
        printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
        printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
        printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
        printf("\t-d : displays input and output\n");
        printf("\t-s : silent\n");


    }


    //genero o carico la matrice
    if (strlen(filename) == 0)
        Xy = random_input(m, n);
    else
        Xy = load_input(filename, &m, &n);

    if (!silent)
        printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);

    //stampo la matrice
    if (!silent && display) {
        printf("\nInput augmented matrix:\n");
        for (i = 0; i < m * (n + 1); i++) {
            if (i % (n + 1) == 0)
                printf("\n");
            printf("%f ", Xy[i]);
        }
        printf("\n");
    }

    //salvo la matrice
    if (strlen(filename) == 0 && fsave)
        save_input("last.mat", Xy, m, n);



    //Modifico il formato dei dati in input

    MATRIX Xy_CMO = changeInput(Xy, m, n);


     dealloc_matrix(Xy);


    


    //calcolo la soluzione
    clock_t t = clock();
    beta = linreg(Xy_CMO, m, n);
    t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/




    //stampo il tempo di esecuzione
    if (!silent)
        printf("\nExecution time = %.3f seconds\n", ((float) t) / CLOCKS_PER_SEC);
    else
        printf("%.3f\n", ((float) t) / CLOCKS_PER_SEC);


    //stampo il vettore beta
    if (!silent && display) {
        printf("\nOutput coefficient vector:\n");
        for (i = 0; i < n; i++)
            printf("%.3f ", beta[i]);
        printf("\n");
    }

    //calcolo l'errore

    float err = error(Xy_CMO, beta, m, n);

    if (!silent)
        printf("\nThe error is %f.\n", err);
    else
        printf("%f\n", err);


}


