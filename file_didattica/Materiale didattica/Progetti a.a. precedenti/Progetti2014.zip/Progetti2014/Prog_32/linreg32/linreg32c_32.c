/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici II - a.a. 2013/14
 * 
 * "Progetto di un algoritmo di "regressione lineare multivariata"
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 28 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare libc6-dev-i386:

     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 linreg32.nasm && gcc -O3 -m32 -msse linreg32.o linreg32c.c -o linreg32c && ./linreg32c
 
 oppure
 
 ./runlinreg32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX	float*
#define	VECTOR	float*


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float frand() {
	float r = (float) rand();
	return r/RAND_MAX;
}


void print_matrix(MATRIX A,int rows,int columns){
	int i,j;
	for(i=0;i<rows;i++){
		for(j=0;j<columns;j++){
			printf("%f ",A[i*(columns)+j]);
		}
		printf("\n");
	}
}

MATRIX trasposta(MATRIX A,int rows,int columns){
	int i,j;
	int br=rows/4;
	int bc=columns/4;
	MATRIX B=alloc_matrix(columns,rows);
	
	/*for( i=0;i<rows;i++){
		for( j=0;j<columns;j++){
			B[i+rows*j]=A[i*columns+j];
		}
	}*/

	trasp32(A,B,rows,columns,bc,br);
	//print_matrix(B,columns,rows);
	//printf("\n");

	return B;
}


MATRIX prod(MATRIX A,MATRIX B,int rows_a,int columns_a,int rows_b,int columns_b){
	if(columns_a!=rows_b) printf("Impossibile moltiplicare!!!\n");
	int i,j,k;
	int br=rows_a/4;
	int bc=columns_b/4;
	int brc=rows_b/4;
	MATRIX C=alloc_matrix(rows_a,columns_b);
	/*for( i=0;i<rows_a;i++){
		for( j=0;j<columns_b;j++){
			float t=0;
			for(k=0;k<rows_b;k++){
				t+=A[i*columns_a+k]*B[k*columns_b+j];
			}
			C[i*columns_b+j]=t;	
		}
	}*/
	//print_matrix(C,rows_a,columns_b);
	//printf("\n");
	
	//MATRIX D=alloc_matrix(rows_a,columns_b);

	prod32b(A,B,rows_a,columns_b,rows_b,C,br,bc,brc);

	//print_matrix(C,rows_a,columns_b);
	//printf("\n");

	return C;
}

MATRIX prod2(MATRIX A,MATRIX B,int rows_a,int columns_a,int rows_b,int columns_b){
	if(columns_a!=rows_b) printf("Impossibile moltiplicare!!!\n");
	int i,j,k;
	int br=rows_a/4;
	int bc=columns_b/4;
	int brc=rows_b/4;
	MATRIX C=alloc_matrix(rows_a,columns_b);
	for( i=0;i<rows_a;i++){
		for( j=0;j<columns_b;j++){
			float t=0;
			for(k=0;k<rows_b;k++){
				t+=A[i*columns_a+k]*B[k*columns_b+j];
			}
			C[i*columns_b+j]=t;	
		}
	}

	//print_matrix(C,rows_a,columns_b);
	//printf("\n");

	return C;
}

MATRIX inversa(MATRIX A, int rows,int columns){
	if(rows!=columns)printf("Matrice rettangolare!!!");
	else{
		int i,j,k;
		float pivot,m;

		MATRIX B=alloc_matrix(rows,columns);//matrice identità
		MATRIX C=alloc_matrix(rows,columns);

		//MATRIX D=alloc_matrix(rows,columns);//matrice identità
		//MATRIX E=alloc_matrix(rows,columns);
		for(i=0;i<rows;i++){
			for(j=0;j<rows;j++){
				//E[i*rows+j]=A[i*rows+j];
				C[i*rows+j]=A[i*rows+j];
				if(i==j) {
					B[i*rows+j]=1;
				//	D[i*rows+j]=1;
				}
				else {
					B[i*rows+j]=0;
				//	D[i*rows+j]=0;
				}
			}
		}

		for(k=0;k<rows;k++){
			pivot=C[k*rows+k];
			for(i=k+1;i<rows;i++){
				m=C[i*rows+k]/pivot;
				for(j=0;j<rows;j++){
					B[i*rows+j]-=m*B[k*rows+j];
					if(j>=k){
						C[i*rows+j]-=m*C[k*rows+j];
					}
				}
			}
		}

		/*print_matrix(C,rows,columns);
		printf("\n");
		print_matrix(B,rows,columns);
		printf("\n");

		inv32(E,D,rows);

		print_matrix(E,rows,columns);
		printf("\n");
		print_matrix(D,rows,columns);	*/

		for(i=rows-1;i>=0;i--){
			pivot=C[i*rows+i];
			for(k=0;k<rows;k++){
				m=B[i*rows+k];
				for(j=i+1;j<rows;j++){
					m-=C[i*rows+j]*B[j*rows+k];
				}
				B[i*rows+k]=m/pivot;
			}
		}

		//print_matrix(B,rows,columns);
		//printf("\n");
	
		return B;
	}
	
}


/*
 * 
 * 	random_input
 * 	============
 * 
 *	Genera in maniera casuale una matrice m x (n+1) da fornire in input
 *	alla funzione linreg. 
 * 
 */
MATRIX random_input(int m, int n) {
	int i, j;
	MATRIX A = alloc_matrix(m,n+1);
	float x, y, e;
	float* beta = calloc(n,sizeof(float));
	
	for (i = 0; i < n; i++)
		  beta[i] = frand();
	e = frand()*0.2;

	for (i = 0; i < m; i++) {
		y = 0;
		for (j = 0; j < n; j++) {
			if (j < n-1)
				x = frand();
			else
				x = 1.0;
			A[i*(n+1)+j] = x;
			y += x*beta[j];
		}
		A[i*(n+1)+n] = y*(1+frand()*e-e/2);
	}
	
	free(beta);
	
	return A;
}






/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file una matrice m x (n+1) 
 * 	da fornire in input alla funzione linreg. 
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
MATRIX load_input(char* filename, int *m, int *n) {	
	FILE* fp;
	int rows, cols, status;

	fp = fopen(filename, "rb");
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	MATRIX Xy = alloc_matrix(rows,cols);
	status = fread(Xy, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = rows;
	*n = cols-1;
	return Xy;
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Scrive su file una matrice m x (n+1).
 * 
 * 	ATTENZIONE: SI ASSUME CHE LA MATRICE SIA MEMORIZZATA NEL
 * 	FILE IN ROW-MAJOR ORDER!
 * 	I TEST FINALI VERRANNO EFFETTUATI MANTENENDO QUESTA ASSUNZIONE
 * 
 */
void save_input(char* filename, MATRIX Xy, int m, int n) {	
	FILE* fp;
	int status;
	
	fp = fopen(filename, "wb");
	n++;
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&m, sizeof(int), 1, fp);
	status = fwrite(Xy, sizeof(float), m*n, fp);
	fclose(fp);
}


/*
 *	linreg
 * 	======
 * 
 *	Xy è una matrice di dimensione m x (n+1) in cui le prime n
 *	colonne rappresentano le variabili indipendenti x1, ..., xn
 * 	e l'ultima colonna rappresenta la variabile dipendente y;
 * 	ogni riga contiene una osservazione (nelle prime n+1 colonne)
 * 	e l'associato valore della variabile dipendente (nell'ultima colonna).
 * 
 * 	L'output è un array di n colonne contenente i coefficienti
 * 	dell'iperpiano di regressione
 * 
 */
VECTOR linreg(MATRIX X,MATRIX y, int m, int n) {
    VECTOR beta = get_block(sizeof(float),n);
    
    // -------------------------------------------------
    // Inserire qui il proprio algoritmo risolutivo
    // -------------------------------------------------

	//print_matrix(Xy,m,n+1);

	int i,j;

	/*print_matrix(X,m,n);
	printf("\n");
	print_matrix(y,m,1);
	printf("\n");*/

	//MATRIX Xt=alloc_matrix(n,m);
	MATRIX Xt=trasposta(X,m,n);

	//MATRIX P=alloc_matrix(n,n);
	MATRIX P=prod(Xt,X,n,m,m,n);

	//MATRIX I=alloc_matrix(n,n);
	MATRIX I=inversa(P,n,n);

	//MATRIX Q=alloc_matrix(n,m);
	MATRIX Q=prod(I,Xt,n,n,n,m);


	beta=prod2(Q,y,n,m,m,1);
    
    //linreg32(Xy, beta, m, n); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------

    return beta;
}



/*
 * 
 * 	error
 * 	=====
 * 
 *	Calcola l'errore di regressione.
 * 
 */
float error(MATRIX Xy, VECTOR beta, int m, int n) {
	int i, j;
	float err = 0, de, yp;
	
	for (i = 0; i < m; i++) {
		yp = 0;
		for (j = 0; j < n; j++)
			yp += Xy[i*(n+1)+j] * beta[j];
		de = fabs(Xy[i*(n+1)+n]-yp);
		err += (de*de);
	}
	return err;
}

/*******************************************************************/
void save_beta(VECTOR beta, int m, int n) {	
	FILE* fp;
	int status;
	int cols = 1;
	char filename[50];
	sprintf(filename, "test%dx%d_32.beta", m, n);
	
	printf("%s\n", filename);
	
	fp = fopen(filename, "wb");
	status = fwrite(&n, sizeof(int), 1, fp);
	status = fwrite(&cols, sizeof(int), 1, fp);
	status = fwrite(beta, sizeof(float), n, fp);
	fclose(fp);
}
/*******************************************************************/


void main(int argc, char** argv) {
	int m = 8;
	int n = 8;
	MATRIX Xy;
	VECTOR beta;
	
	char* filename = "";
	int silent = 0, display = 0, fsave = 0;
	int i;
	int k,j;
	
	srandom(time(NULL));

	int par = 1;
	while (par < argc) {
		if (strcmp(argv[par],"-l") == 0) {
			par++;
			if (par < argc) {
				filename = argv[par];
				par++;
			}
		} else if (strcmp(argv[par],"-r") == 0) {
			par++;
			if (par < argc) {
				m = atoi(argv[par]);
				par++;
				if (par < argc) {
					n = atoi(argv[par]);
					par++;
				}
			}
		} else if (strcmp(argv[par],"-f") == 0) {
			fsave = 1;
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s [-l <file_name>][-r <observations(m)> <variables(n)>]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-l <file_name> : reads from disk the augmented m x (n+1) matrix\n");
		printf("\t-r <observations(m)> <variables(n)>: randomly generates a m x (n+1) matrix\n");
		printf("\t-f : writes on disk the augmented m x (n+1) matrix (creates the file last.mat)\n");
		printf("\t-d : displays input and output\n");
		printf("\t-s : silent\n");
	}
	
	if (strlen(filename) == 0)
		Xy = random_input(m,n);
	else
		Xy = load_input(filename, &m, &n);
	
	if (!silent && display) {
		printf("\nInput augmented matrix:\n");
		for (i = 0; i < m*(n+1); i++) {
			if (i % (n+1) == 0)
				printf("\n");
			printf("%f ", Xy[i]);
		}
		printf("\n");
	}

//	clock_t t = clock(); 
	MATRIX y=alloc_matrix(m,1);
	MATRIX X=alloc_matrix(m,n);

	for(k=0;k<m;k++)
		for(j=0;j<n;j++)
			X[k*n+j]=Xy[k*n+j+k];

	for(k=0;k<m;k++)
		for(j=0;j<1;j++){
			y[k]=Xy[k*(n+1)+n];
	}
	
	if (!silent)
		printf("\nSolving a regression problem with %d observations and %d variables...\n", m, n);
	clock_t t = clock(); 
	beta = linreg(X,y,m,n);
	t = clock() - t;
	/*******************************************************************/
	save_beta(beta,m,n);
	/*******************************************************************/

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nOutput coefficient vector:\n");
		for (i = 0; i < n; i++)
			printf("%.3f ", beta[i]);
		printf("\n");
	}
		
	float err = error(Xy,beta,m,n);
	if (!silent)
		printf("\nThe error is %f.\n", err);
	else
		printf("%f\n", err);

	if (strlen(filename) == 0 && fsave)
		save_input("last.mat",Xy,m,n);
}
