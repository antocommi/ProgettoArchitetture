#include <stdio.h>
#include <math.h>
#include <stdlib.h>

void transposed(float* X, float* Xt, int r, int c);
void product(float* A, float* B, float* C, int rA, int cA, int rB, int cB);
void inverseGJ(float* X, float* Xi, int r, int c);
void addIdentity(float* X, float* M, int r, int c);
void takeInverse(float* X, float* M, int r, int c);
void replaceRow(float* I, int k, int r, int c);
void extractY(float* Xy, float* Y, int r, int c);
void extractX(float* Xy, float* X, int r, int c);

void transposed(float* X, float* Xt, int r, int c){
	int j;
	for(j=0; j<r; j++){
		int i;
		for(i=0; i<c; i++){
			Xt[r*i + j] = X[c*j + i];
		}
	}
}

void product(float* A, float* B, float* C, int rA, int cA, int rB, int cB){
	int iA;
	for(iA=0; iA<rA; iA++){
		int jB;
		for(jB=0; jB<cB; jB++){
			int jA;
			for(jA=0; jA<cA; jA++){
				C[jB + cB*iA] += A[jA + cA*iA] * B[jB + cB*jA];
			}
		}
	}
}

void inverseGJ(float* X, float* M, int r, int c){
	float* I = calloc(r*c, sizeof(float));
	addIdentity(X, I, r, c);

	int k;
	int nc = c*2;
	for(k=0; k<r; k++){ //k procede lungo la diagonale principale
		if(I[k + nc*k] == 0){ //se M(k,k) = 0 sostituisci riga
			replaceRow(I, k, r, nc);
		}
		int j;
		if(I[k + nc*k] != 1){
			for(j=k+1; j<nc; j++){ //si divide la riga per M(k,k)
				I[j + nc*k] /= I[k + nc*k];
			}
			I[k + nc*k] = 1; //si rendono i pivot uguali a 1
		}

		int i;
		for(i=0; i<r; i++){ //si annullano le componenti sopra e sotto i pivot
			if(i != k){
				float n = I[k + nc*i];
				if(n!=0){
					for(j=k; j<nc; j++){
						I[j + nc*i] -= n * I[j + nc*k];
					}
				}
			}
		}
	}
	takeInverse(I, M, r, nc);
}

void addIdentity(float* X, float* M, int r, int c){
	int i;
	int k = c-1;
	for(i=0; i<r; i++){
		int j = 0; k++;
		for(j=0; j<c*2; j++){
			if(j == k){
				M[j + c*2*i] = 1;
			}
			else if(j >= c){
				M[j + c*2*i] = 0;
			}
			else{
				M[j + c*2*i] = X[j + c*i];
			}
		}
	}
}

void takeInverse(float* X, float* M, int r, int c){
	int nc = c/2;
	int i;
	for(i=0; i<r; i++){
		int j;
		for(j=nc; j<c; j++){
			M[(j-nc) + nc*i] = X[j + c*i];
		}
	}
}

void replaceRow(float* I, int k, int r, int c){
	int i;
	for(i=k; i<r; i++){
		if((k + (i+1)*c) < (r*c) && I[k + (i+1)*c] != 0){
			float n;
			int j;
			for(j=k; j<c; j++){
				n = I[j + k*c];
				I[j + k*c] = I[j + (i+1)*c];
				I[j + (i+1)*c] = n;
			}
			i = r; // esce dal ciclo appena cambia la riga
		}
		// else matrice singolare exit
	}
}

void extractY(float* Xy, float* Y, int r, int c){
	int i;
	for(i=0; i<r; i++){
		Y[i] = Xy[(c-1) + c*i];
	}
}

void extractX(float* Xy, float* X, int r, int c){
	int i;
        for(i=0; i<r; i++){
                int j;
                for(j=0; j<(c-1); j++){
                        X[j + i*(c-1)] = Xy[j + i*c];
                }
        }
}
