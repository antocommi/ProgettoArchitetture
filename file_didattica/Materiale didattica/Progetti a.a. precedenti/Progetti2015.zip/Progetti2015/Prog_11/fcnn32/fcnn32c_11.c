/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 fcnn32.nasm && gcc -O0 -m32 -msse fcnn32.o fcnn32c.c -o fcnn32c && ./fcnn32c
 
 oppure
 
 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*

typedef enum { false, true } bool;



void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 * 
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola 
 * 
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {	
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");
	
	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}
	
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);
	
	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;
	
	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {	
	FILE* fp;
	int i;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);
	
	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*cols], sizeof(float), cols, fp);
	fclose(fp);
}

extern void dist32(VECTOR x, VECTOR y, int d, float* dist_ret);
void dist(VECTOR x, VECTOR y, int d, float* dist_ret){
	float somma = 0;
	int i=0;
	for(i=0;i<d;i++){
		somma += ((*(x+i))-(*(y+i)))*((*(x+i))-(*(y+i)));
	}
	*dist_ret = sqrt(somma);
}

extern void centroids32(DATASET DS, MATRIX T,int n ,int m, int d, SUBSETID Sid);
void centroids(DATASET DS, MATRIX T,int n ,int m, int d, SUBSETID Sid){    
        DATASET G = alloc_matrix(m,d+1); // Somme parziali per calcolare il centro geometrico
        DATASET count = alloc_matrix(m,1);
        // calcolo per ogni label il centro geometrico somma / n cioè Gi/ni
        int i=0;int j=0; int k=0;
        for(i=0;i<m;i++){
		count[i] = 0;
		for(k=0;k<d;k++){
			G[i*(d+1)+k] = 0;
		}
                G[i*(d+1)+d]=i;
                for(j=0;j<n;j++){  
                        if(T[j*(d+1)+d]==i){
				for(k=0;k<d;k++){
					G[i*(d+1)+k] += T[j*(d+1)+k];// incremento
				}
                               	count[i]++;
                        }
                       
                }		

               	for(k=0;k<d;k++){
                	G[i*(d+1)+k] /= count[i];
               	}    
        }
        // fine centro geometrico

        // trovo il più vicino per ogni label , uso count per memorizare la distanza minima
        for(i=0;i<m;i++){
                bool flag = true;
                for(j=0;j<n;j++){
                        if(T[j*(d+1)+d]==i){
                                if(flag==false){
                                	float distTmp = 0.0;
					dist32(&(T[j*(d+1)]),&(G[i*(d+1)]),d,&distTmp);
					
				        if(distTmp<count[i]){
                                        	count[i]=distTmp;
						for(k=0;k<d+1;k++){
                                                       	DS[i*(d+1)+k]= T[j*(d+1)+k];      
						}
						Sid[i] = j;
                                        }//aggiorno il minimo del label m
                                }
                                else {
                                        for(k=0;k<d+1;k++){
                                              	DS[i*(d+1)+k] = T[j*(d+1)+k];      
					}
					Sid[i] = j;
                                        dist32(&(DS[i*(d+1)]),&(G[i*(d+1)]),d,&count[i]);

                                        flag=false;
                               } // il primo è il minimo
                        }
                  }
        }
 
        // G e count non mi servono più
       	dealloc_matrix(G);
       	dealloc_matrix(count);
}

extern void unisciS32(DATASET S, DATASET DS, int* Sn, int DS_dim, int d);
void unisciS(DATASET S, DATASET DS, int* Sn, int DS_dim, int d){
	int i,j = 0;
	for(i=0;i<DS_dim;i++){
		for(j=0;j<d+1;j++){
			S[((*Sn)+i)*(d+1)+j] = DS[i*(d+1)+j];
		}
	}
}

extern void unisciDS32(DATASET DS, float* p, int DS_dim, int d);
void unisciDS(DATASET DS, float* p, int DS_dim, int d){ //mette in S un solo elemento p
	int i=0;
	for(i=0;i<d+1;i++){
		DS[DS_dim*(d+1)+i] = *(p+i);
	}
}

extern void nn32 (float* p, DATASET S, int* Sn, int d, int* index_ret);
void nn (float* p, DATASET S, int* Sn, int d, int* index_ret){ //restituisce l'indice dell'elemento di s più vicino
	if(*Sn == 1){ //quando voren ha un solo elemento, in quanto nn viene chiamato anche con insieme S pari a voren
		*index_ret = 0;
	}
	else {
		int i=0;
		float minimo = 0;
		dist32(p,&(S[0]),d,&minimo);
		int index = 0;
		for(i=1;i<*Sn;i++){
			float tmp = 0;
			dist32(p,&(S[i*(d+1)]),d,&tmp);	
			if(tmp < minimo){
				minimo = tmp;
				index = i;
			}
		}

		*index_ret = index;
	}
}

extern void vor32(int indexPS, DATASET S, DATASET T, int dim_T, int d, int* Sn, SUBSETID T_index, int* dim_vor_ret, SUBSETID conteins);
void vor(int indexPS, DATASET S, DATASET T, int dim_T, int d, int* Sn, SUBSETID T_index, int* dim_vor_ret, SUBSETID conteins){ //restituisce il numero dei vor di p in T e li inserisce in T_index
	int dim_vor = 0;	
	int i=0;
	for(i=0;i<dim_T;i++){ //per ogni elemento di T
		bool contieneq = conteins[i];	// 0 false, 1 true
		if(contieneq==false){ // non contenuto in S per evitare che l'elemento stesso sia inserito in vor
			int index_S = 0;
			nn32(&T[i*(d+1)],S,Sn,d,&index_S); //indice del nn di p in S

			bool uguali = false;
			if(indexPS==index_S){
				uguali = true;
			}
			if(uguali==true){ //se p è uguale al nn(q,S), aggiungo il suo indice
				T_index[dim_vor] = i;
				dim_vor++;
			}
		}	
	}
	*dim_vor_ret = dim_vor;
}

extern void voren32(int indexPS, DATASET S, DATASET T, int dim_T, int d, int* Sn, SUBSETID vor_element, int* dim_voren, SUBSETID conteins);
void voren(int indexPS, DATASET S, DATASET T, int dim_T, int d, int* Sn, SUBSETID vor_element, int* dim_voren, SUBSETID conteins){ //restituisce il numero dei voren di p in T e inserisce l'indice in vor_element
	int dim_vor = 0;
	vor32(indexPS,S,T,dim_T,d,Sn,vor_element,&dim_vor,conteins); //indici dei vor di p in T
		
	int c = 0; //serve poichè voglio riutilizzare il vettore vor per motivi di efficienza
	int i=0;
	for(i=0;i<dim_vor;i++){ //per ogni elemento di vor di p 
		if(S[indexPS*(d+1)+d] != T[vor_element[i]*(d+1)+d]){ // vor[i] indice di q in T, vor[i]*(d+1)+d posizione label di q in T
			vor_element[c] = vor_element[i]; // label diverse e quindi lo aggiungo all'insieme
			c++;	
		} 
	}

	*dim_voren = c;
}

extern void fcnnN32(DATASET t, int n, int d, int m, SUBSETID Sid, int* Sn, SUBSETID conteins, DATASET S, DATASET DS, DATASET tmp_vor, SUBSETID voronoi);
void fcnnN(DATASET T, int n, int d, int m, SUBSETID Sid, int* Sn, SUBSETID conteins, DATASET S, DATASET DS, DATASET tmp_vor, SUBSETID voronoi) {
	int k,z=0;
	centroids32(DS,T,n,m,d,Sid);

	for(k=0;k<n;k++){
		conteins[k] = 0;	// false
	}
	for(k=0;k<m;k++){
		conteins[Sid[k]] = 1;	// true
	}

	int DS_dim = m;

	int c=m;
	while(DS_dim!=0){
		unisciS32(S, DS, Sn, DS_dim, d);
		*Sn = (*Sn)+DS_dim;
		DS_dim = 0;

		int i=0;
		for(i=0;i<(*Sn);i++){ //Per ogni elemento di S
			int dim_voren = 0;
			voren32(i,S,T,n,d,Sn,voronoi,&dim_voren,conteins);
			if(dim_voren>0){ //se non vuoto lo ricostruisco
				int j,k,z =0;
				for(j=0;j<dim_voren;j++){
					for(k=0;k<d+1;k++){
						tmp_vor[(d+1)*j+k] = T[voronoi[j]*(d+1)+k];
						z++;
					}
				}
				
				int nuovo_esempio = 0;
				
				nn32(&S[i*(d+1)],tmp_vor,&dim_voren,d,&nuovo_esempio); //indice in voren
				int index_elem = voronoi[nuovo_esempio]*(d+1); //indice esempio in T
				
				conteins[voronoi[nuovo_esempio]] = 1;

				unisciDS32(DS,&T[index_elem],DS_dim,d);
				DS_dim++;
				
				Sid[(*Sn)+DS_dim] = voronoi[nuovo_esempio];
			}
		}
	}	
}

void fcnn(DATASET T, int n, int d, int m, SUBSETID Sid, int* Sn) {
	DATASET S = alloc_matrix(n,d+1);
	DATASET DS = alloc_matrix(n,d+1);
	SUBSETID voronoi = calloc(sizeof(int),n); //conterrà ad ogni passo gli indici dei voren
	DATASET tmp_vor = alloc_matrix(n,d+1); //serve per ricostruire punti dei voren grazie agli indici presenti in voronoi
	SUBSETID contains = calloc(sizeof(int),n); // conterrà gli 0 se elemento in S, 1 altrimenti

	fcnnN(T, n, d, m, Sid, Sn, contains, S, DS, tmp_vor, voronoi);
	
	free(contains);
	dealloc_matrix(S);	
	dealloc_matrix(DS);
	dealloc_matrix(tmp_vor);
	free(voronoi);
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);
	
	clock_t t = clock();

	int Sn = 0;
	SUBSETID Sid = calloc(sizeof(int),n);
	fcnn(T, n, d, m, Sid, &Sn);
	
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.9f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.9f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}
	printf("<< sn= %d >>",Sn);

	save_output(Sid,Sn,d+1,T);
	
	return 0;
}
