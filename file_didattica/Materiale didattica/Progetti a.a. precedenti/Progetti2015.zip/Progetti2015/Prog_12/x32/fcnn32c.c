/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 fcnn32.nasm && gcc -O0 -m32 -msse fcnn32.o fcnn32c.c -o fcnn32c && ./fcnn32c
 
 oppure
 
 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 * 
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola 
 * 
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {	
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");
	
	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}
	
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);
	
	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;
	
	return T;
}

DATASET centroide(DATASET T,int n, int d, int m) {
	/* calcolo il centroide del Training set T
	 * prendendo i primi oggetti di classe diversa che incontro in T
	 * restituisce un vettore dimensione (m,d+4)
         * con la seguente caratteristica
         * (v1,......,vd,classe,riga in T del centroide,distanza,rigaminima)
         * v1,.....,vd,classe li prendo dal dataset,
         * riga in T del centroide è la posizione riga nella matrice (dataset) T
         * distanza inizialmente impostata a -1 conterrà in seguito la distanza minima trovata
         * rigaminima è la riga nella matrice in T che ha distanza minima
 
	 */
	DATASET S = alloc_matrix(m,d+4);
        int classe[m];
        int elclasse =0;
	
        int trovato=0; /* boolean */
	int x,y,rig,nr;
 	int cols = d+1;
        
        for (x=0 ; x<m;x++)
	    classe[x]=-1;
	for (rig = 1; rig <= n; rig++) {
	    nr = T[(rig*(d+1))-1];

            trovato =0;
	    for (x=0;x<m;x++) {
		if (classe[x] == nr)
		   trovato=1;
		}	
            if (trovato == 0) {
	        classe[elclasse]= nr;	
		
                for (y=0; y<cols ;y++) {

		    S[elclasse*(d+4)+y]=T[(rig-1)*cols+y];
		    }
                printf("\n"); 
                S[(elclasse+1)*(d+4)-3]= rig;
                S[(elclasse+1)*(d+4)-2]=-1;
                S[(elclasse+1)*(d+4)-1]=-1; 
	        elclasse++; 

	       }
            if (elclasse == m) {
                break; 
           	}
         
	}

	return S; 
	
}
/* fastsqrt implementazione più veloce di sqrt */

float fastsqrt(float val)  {
        union
        {
                int tmp;
                float val;
        } u;
        u.val = val;
        u.tmp -= 1<<23; /* Rimuove l'ultimo bit tmp è un'approssimazione di logbase2(val)*/
        u.tmp >>= 1;    /* divide per 2 */
        u.tmp += 1<<29; /* aggiunge 64 all'esponente: (e+127)/2 =(e/2)+63, */
        		/* che rappresenta (e/2)-64 ma noi vogliamo e/2 */
        return u.val;
}


float distanza(DATASET v1,DATASET v2, int d) {
      float dist=0;
      int y;
      for (y=0; y<d ;y++) {
	   dist += ((v1[y]-v2[y])*(v1[y]-v2[y]));
          
      }
      dist = fastsqrt(dist);
      return dist;
      
}

void save_output(SUBSETID Sid, int Sn, int d) {	
	FILE* fp;
	int i,j;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++) {
		for (j = 0; j < d+1; j++)
		    fprintf(fp, "%d\n", Sid[i*(d+1)+j]);
        }
	fclose(fp);
}



extern void fcnn32(DATASET t, int n, int d, int m, SUBSETID Sid, int* Sn);

/*
 *	fcnn
 * 	====
 * 
 *	T contiene il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
 * 	in un array lineare in row-major order
 * 
 *	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
 * 	del training set.
 * 
 * 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
 * 	al sottoinsieme S ed in Sn il numero di oggetti in S.
 * 	Si assume che gli identificatori partono da 0.
 * 
 */
SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
	SUBSETID Sid = calloc(sizeof(int),n);
	DATASET Cent;
	int i, j, x, y, rig,r,nC;
	int inS =0; /* boolean */
	int cols=d+1;
	DATASET vT;
        DATASET vS;
        float dcalc;
        
	Cent = centroide(T,n,d,m);
        
        /* vT vettore con le coordinate dell'elemento T
         * vS vettore con le coordinate dell'elemento S 
         */

        vT = alloc_matrix(d,1);
        vS = alloc_matrix(d,1);
        
	/* scorro tutta la matrice del Centroide e preparo vS */
        for (x=0; x<m ;x++) {
            
            /* inserisco le coordinate in vS*/
            for (y=0; y<d ;y++) {
		vS[y]=Cent[x*(d+4)+y];
	    }
 
            /* Avendo come riferimento un vettore vS
             * scorro il dataset (matrice) T per riempire vT */
            for (r=1; r<=n ;r++) {
            	inS=0;
                for (nC=0; nC<m ;nC++) {
            	     if (Cent[nC*(d+4)+cols] == r) {
               	        /* elemento di T che è in S */
                        inS=1;
	    	   }
		    }
            	if (inS ==0) {
		   /* elemento che si trova in T ma non in S 
                    * lo metto nel vettore vT */
                   for (y=0; y<d ;y++) {
		       vT[y]=T[(r-1)*cols+y];
		       }
                   /* calcolo la distanza tra i due vettori */
                   dcalc= distanza(vT,vS,d);
            	   if ((Cent[x*(d+4)+d+2] > dcalc) || (Cent[x*(d+4)+d+3] < 0)) {
                      /* Ho trovato una distanza minore 
		       * oppure è il primo elemento quindi aggiorno la matrice Cent 
                         con i risultati parziali */
          
               	      Cent[x*(d+4)+d+2] = dcalc;
                      Cent[x*(d+4)+d+3] = r;
                      
                      for (y=0; y<cols ;y++) {
                          
                          Sid[x*cols+y]=(r-1)*cols+y;
		          }
	    	      }
                   
	    	   }		  
            
	    } 
	}
	*Sn =m;

        //fcnn32(T, n, d, m, Sid, Sn); // Esempio di chiamata di funzione assembly
 

    return Sid;
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);
	
	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d);

	return 0;
}
