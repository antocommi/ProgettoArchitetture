/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 fcnn64.nasm && gcc -O0 -m64 -mavx fcnn64.o fcnn64c.c -o fcnn64c && ./fcnn64c
 
 oppure
 
 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>
#include <float.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,32); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 * 
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola 
 * 
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {	
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");
	
	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}
	
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);
	
	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;
	
	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {	
	FILE* fp;
	int i;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);
	
	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*cols], sizeof(float), cols, fp);
	fclose(fp);
}


void check(DATASET T,int n, int d, int* nearest){
	int i;
	for(i=0;i<n;i++){
		if(nearest[i]!=i){
			int label = l(T,d,i);
			if(label!=l(T,d,nearest[i]))
				printf("Errore \n");
		}
	}	
}
//marca in nearest gli elementi presenti in  S
void updateT(int* nearest,int* deltaS,int deltaSize){
	int i;
	for(i=0;i<deltaSize;i++)
		nearest[deltaS[i]]=deltaS[i];
}
//void initialize(int* v,int n){
//	int i;
//	for(i=0;i<n;i++)
//		v[i]=-1;
//}

//void unione(SUBSETID S,int* deltaS,int* sSize,int deltaSize){
//	int i;
//	for(i=0;i<deltaSize;i++){
//		S[*sSize+i]=deltaS[i];
//		//printf("%d ,",S[*sSize+i]);
//	}
//	*sSize+=deltaSize;
//}
float dist2(DATASET T,int d,int id1,int id2){
	if(id1==-1 || id2==-1)
		return FLT_MAX;
	float s = 0;
	float diff;
	int i;
	for(i=0;i<d;i++){
		diff=T[id1*(d+1)+i]-T[id2*(d+1)+i];
		s+=(diff*diff);
	}
	return sqrt(s);
}
int l(DATASET T, int d, int id){
	return T[id*(d+1)+d];

}
void updateDeltaS(int* deltaS,int* rep,int* S, int sSize,int* deltaSize){
	int pos = 0;
	int i;
	for(i=0;i<sSize;i++)
		if(rep[S[i]]!=-1){
			deltaS[pos]=rep[S[i]];
			pos++;
		}
	*deltaSize = pos;		
}

extern float dist(DATASET T,int d,int id1,int id2);

extern void calcolaCentroidi(DATASET T,int d,int n,MATRIX centro,float* distanze,int* centroidi);

void updateNearest(DATASET T,int d, int* nearest,int q,int* deltaS,int deltaSize,float* distT){
	int p;
	for(p=0;p<deltaSize;p++){
		float distanza = dist(T,d,deltaS[p],q);
		if(distT[q]>distanza){
			nearest[q]=deltaS[p];
			distT[q] = distanza;
		}
	}
}


//void updateNearest(DATASET T,int d, int* nearest,int q,int* deltaS,int deltaSize){
//	int p;
//	for(p=0;p<deltaSize;p++){
//		float dist1 = dist(T,d,nearest[q],q);
//		float dist2 = dist(T,d,deltaS[p],q);
//		if(dist1==dist2){
//			int label = l(T,d,nearest[q]);
//			if(label!=l(T,d,q))
//				nearest[q]=deltaS[p];
//		}else if(dist1>dist2)
//			nearest[q]=deltaS[p];
//	}
//}
extern void calcolaCentroGeo(DATASET T,int n,int m,int d,float* centro,int* occ);

int* centroids(DATASET T,int n,int m,int d){	
	int* occ = calloc(sizeof(int),m);
	//int* occ = (int*)get_block(sizeof(int),m);
	//float* centro = calloc(sizeof(float),m*d);
	MATRIX centro = alloc_matrix(m,d);
	int i;
	//for(i=0;i<d*m;i++)
	//	centro[i]=0;
	azzera(centro,d,m);
	calcolaCentroGeo(T,n,m,d,centro,occ);
	
	
	//for(i=0;i<n;i++){
	//	int classe = l(T,d,i);
	//	int c;
	//	for(c=0;c<d;c++)
	//		centro[classe*d+c]+= T[i*(d+1)+c];
	//	occ[classe]++;
	//}
	
	int c;
	//for(i=0;i<m;i++)
	//	for(c=0;c<d;c++)
	//		centro[i*d+c]/=occ[i];
	int* centroidi = calloc(sizeof(int),m);
	float* distanze = calloc(sizeof(float),m);
	for(i=0;i<m;i++)
		distanze[i]=FLT_MAX;
	calcolaCentroidi(T,d,n,centro,distanze,centroidi);
	//for(i=0;i<n;i++){
	//	int classe = l(T,d,i);
	
	//	float s = 0;
	//	for(c=0;c<d;c++){
	//		float diff=T[i*(d+1)+c]-centro[classe*d+c];
	//		s+=(diff*diff);
	//	}
	//	float dist = sqrt(s);
	//	if(dist<distanze[classe]){
	//		distanze[classe]=dist;
	//		centroidi[classe]= i;
	//	}
	//}
	dealloc_matrix(centro);
	free(distanze);
	free(occ);
	return centroidi;

}


//extern void fcnn32(DATASET t, int n, int d, int m, SUBSETID Sid, int* Sn);
extern void initialize(int* v, int n);


SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
	SUBSETID Sid = calloc(sizeof(int),n);
    
    // -------------------------------------------------
    // Codificare qui l'algoritmo risolutivo
    // -------------------------------------------------
	//int* nearest = calloc(sizeof(int),n);
	
	int* nearest = get_block(sizeof(int),n);
	//int i;
	initialize(nearest,n);
	int* deltaS = centroids(T,n,m,d);
	int i;
	int deltaSize = m;
	//int* rep = calloc(sizeof(int),n);
	int* rep = get_block(sizeof(int),n);
	float* distT = get_block(sizeof(float),n);
	initMax(distT,n);
	
	float* distN = get_block(sizeof(float),n);
	
	initMax(distN,n);
	while(deltaSize!=0){
		unione(Sid,deltaS,Sn,deltaSize);
		updateT(nearest,deltaS,deltaSize);		
		initialize(rep,n);
		initMax(distN,n);
		int q;
		int nearestQ;
		for(q=0;q<n;q++){
			if(nearest[q]!=q){ // se q è un elemento di T ma non di S
				updateNearest(T,d,nearest,q,deltaS,deltaSize,distT);
				nearestQ = nearest[q];
				if((l(T,d,q)!=l(T,d,nearestQ)) && distT[q]<distN[nearestQ]){ 
					rep[nearestQ]=q;
					distN[nearestQ]=distT[q];
				}
			
			}
			


		}
		free(deltaS);
		deltaS = calloc(sizeof(int),*Sn);
		updateDeltaS(deltaS,rep,Sid,*Sn,&deltaSize);						

	}
    	
    //fcnn32(T, n, d, m, Sid, Sn); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------
	
	check(T,n,d,nearest);
	
    	return Sid;
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);
	
	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);

	return 0;
}
