/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 fcnn64.nasm && gcc -O0 -m64 -mavx fcnn64.o fcnn64c.c -o fcnn64c && ./fcnn64c
 
 oppure
 
 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*

extern int nearestVoren(void *p, void *t, int di, void *s, int sn, int n);

extern void sum_v(void *v1, void *v2, int di);

extern float d(void *v1, void *v2, int di);

extern void div_v(void *v1, int di, float divisor);

void* get_block(int size, int nelement, int type){
	int i;
	float *res = _mm_malloc(size*nelement,32);
	switch(type){
	case 0:
		break;
	case 1:
		for(i=0;i<nelement;i++){
			res[i]=0.0;
		}
		break;
	case 2:
		for(i=0;i<nelement;i++){
			res[i]=-1.0;
		}
	}
	return res;
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols,0);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


float* padding(float *t, int nrow, int *ncolumn){
	int i, j, k = 0, newColumn, tail;
	if ((*ncolumn + 1) % 8 == 0) //se è multiplo esco
		return t;
	if ((*ncolumn + 1) < 8)
		newColumn = 8;
	else
		newColumn = ceilf((float) (*ncolumn + 1) / 8) * 8;
	float *res = get_block(sizeof(float), nrow * newColumn, 0);
	for (i = 0; i < nrow; i++) {
		for (j = 0; j < (*ncolumn); j++)
			res[k * newColumn + j] = t[i * (*ncolumn + 1) + j]; //setto gli elementi nel nuovo vettore
		res[k * newColumn + newColumn - 1] = t[i * (*ncolumn + 1) + (*ncolumn)]; //setto la classe nel nuovo vettore
		tail = newColumn - (*ncolumn) + j - 1; //coda da azzerare
		for (; j < tail; j++)
			res[k * newColumn + j] = 0;
		k++;
	}
	*(ncolumn) = newColumn - 1;
	_mm_free(t);
	return res;
}

/**
 * di sono le colonne
 */
int* centroids(float *t, int n, int di, int m, int *sn){
	int i, iclass;
	//distanza e minima distanza
	float min_d, dist;
	//da restituire
	int *s = get_block(sizeof(int), n, 0);
	//dove salvare il baricentro
	float *c = get_block(sizeof(float), m * (di + 1), 1);
	//dove salvare gli nn
	float *sbs = get_block(sizeof(float), m * 2, 2);
	//prima ci calcoliamo il baricentro
	for (i = 0; i < n; i++) {
		iclass = t[i * (di + 1) + di];
		sum_v(&c[iclass * (di + 1)], &t[i*(di+1)], di);
		//in c dove ci dovremmo avere la classe mettiamo il numero di istanze di quella classe
		c[iclass * (di + 1) + di]++;
	}
	//effettuiamo la media
	for (i = 0; i < m; i++)
		div_v(&c[i * (di + 1)], di, c[i * (di + 1) + di]);
	//troviamo gli elementi + vicini al baricentro
	for (i = 0; i < n; i++) {
		iclass = t[i * (di + 1) + di];
		min_d = sbs[iclass * 2];
		dist = d(&t[i * (di + 1)], &c[iclass * (di + 1)], di);
		if (min_d == -1.0 || dist < min_d) {
			sbs[iclass * 2] = dist;
			sbs[iclass * 2 + 1] = i;
		}
	}
	//carichiamo il centroide in s
	for (i = 0; i < m; i++) {
		s[*sn] = sbs[i * 2 + 1];
		(*sn)++;
	}
	free_block(c);
	free_block(sbs);
	return s;
}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 * 
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola 
 * 
 */
DATASET load_input(char* filename, int *n, int *di, int *m) {
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");
	
	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}
	
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);
	
	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*di = cols-1;

	T = padding(T,rows,di);
	
	return T;
}


void save_output(SUBSETID Sid, int Sn) {
	FILE* fp;
	int i;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);
}

/*
 *	fcnn
 * 	====
 * 
 *	T contiene il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
 * 	in un array lineare in row-major order
 * 
 *	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
 * 	del training set.
 * 
 * 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
 * 	al sottoinsieme S ed in Sn il numero di oggetti in S.
 * 	Si assume che gli identificatori partono da 0.
 * 
 */
SUBSETID fcnn(DATASET T, int n, int di, int m, int* Sn) {
	//Allocazione della memoria necessaria
	SUBSETID dS;
	SUBSETID S;
	int i, q_index, dS_n=0;
	VECTOR p;

	S = malloc(sizeof(int)*n);
	//size iniziale pari a zero
	*Sn = 0;

	//daltaS=centroids(T)
	dS = centroids(T, n, di, m, &dS_n);

	//while(deltaS != 0)
	while(dS_n != 0) {
		//S = S U deltaS
		for(i=0; i < dS_n; i++) {
			//aggiungiamo in maniera ordinata
			S[(*Sn)] = dS[i];
			(*Sn)++;
		}
		//deltaS = 0
		dS_n = 0;

		//foreach(p € S)
		for(i=0; i < *Sn; i++) {
			//p
			p = &T[S[i]*(di+1)];
			//il più vicino tra i miei nemici
			q_index = nearestVoren(p,T,di,S,*Sn,n);
			//se restituisce -1 ovviamente non va aggiunto a dS
			if(q_index != -1) {
				//deltaS = deltaS U nn(p,voren(p,S,T))
				dS[dS_n] = q_index;
				dS_n++;
			}
		}
	} //while
	free_block(dS);
	return S;
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int di = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &di, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(di+1); i++) {
			if (i % (di+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, di, m);
	
	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, di, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < di+1; j++)
				printf("%f ", T[Sid[i]*(di+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn);

	return 0;
}
