/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

 NASM (www.nasm.us)
 GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

 sudo apt-get install nasm
 sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

 sudo apt-get install lib32gcc-4.8-dev (o altra versione)
 sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 fcnn64.nasm && gcc -O0 -m64 -mavx fcnn64.o fcnn64c.c -o fcnn64c && ./fcnn64c
 
 oppure
 
 ./runfcnn32

 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>

/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */

#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*

void* get_block(int size, int elements) {
	return _mm_malloc(elements * size, 32);
}

void free_block(void* p) {
	_mm_free(p);
}

MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}

void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 * 
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola 
 * 
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");

	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}

	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = 0;
	for (i = 0; i < rows; i++)
	if (T[i*cols+cols-1] > *m)
	*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;

	return T;
}

void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {
	FILE* fp;
	int i;

	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
	fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);

	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
	fwrite(&T[Sid[i]*cols], sizeof(float), cols, fp);
	fclose(fp);
}

extern void fcnn32(DATASET t, int n, int d, int m, SUBSETID Sid, int* Sn);

/*
 *	fcnn
 * 	====
 * 
 *	T contiene il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
 * 	in un array lineare in row-major order
 * 
 *	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
 * 	del training set.
 * 
 * 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
 * 	al sottoinsieme S ed in Sn il numero di oggetti in S.
 * 	Si assume che gli identificatori partono da 0.
 * 
 */
SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
	SUBSETID Sid = calloc(sizeof(int),n);

	// FCNN
	MATRIX S = alloc_matrix(n,d);

	VECTOR p = calloc(sizeof(float),d);
	MATRIX voren(VECTOR p,MATRIX pVoronoi,int n,int d);

	MATRIX centroids(DATASET T, int n, int d, int m, SUBSETID Sid);
	MATRIX deltaS=centroids(T, n, d, m, Sid);

	int nd=m;												//contatore esempi in deltaS, all'inizio m esempi perchè m centroids
	//WHILE (deltaS != 0)
	while (nd>0){											//oppure deltaS[0] != 0

		//S U deltaS
		int k=0;														//indice di riga per deltaS
		int cont=0;														//conta gli esempi aggiunti in S
		int i;
		for (i=*Sn; i<n; i++){											//for parte dalla prima riga dove non ci sono esempi
			if(k<nd){													//se ci sono ancora esempi in deltaS, OPPURE (i>=*Sn && deltaS[k*(d+1)]!=0)
				int j;
				for (j=0; j<d+1; j++){
					S[i*(d+1)+j] = deltaS[k*(d+1)+j];
				}
				k++;
				cont++;
			}
		}
		*Sn=*Sn+cont;

		//deltaS = 0
		for (i=0; i<nd; i++){
			int j=0;
			for (j=0; j<d+1; j++){
				deltaS[i*(d+1)+j] = 0;
			}
		}
		nd=0;												//non ci sono più esempi in deltaS

		//FOREACH (p appartenente ad S)
		int nS=*Sn;
		MATRIX rimanenti(DATASET T,int n,int d,SUBSETID Sid, int nS);
		MATRIX R=rimanenti(T,n,d,Sid,nS);
		int h=0;																//indice di riga di S
		while(h<*Sn){															//finché ci sono altri esempi in S
			int j;
			for(j=0;j<d+1;j++){
				p[j]=S[h*(d+1)+j];												//riempio array di p contenuto in S
			}
			MATRIX voronoi(VECTOR p, MATRIX R, MATRIX S,int n,int d, int nS);
			MATRIX pVoronoi=voronoi(p,R,S,n,d,nS);									//l'insieme degli esempi nella cella di voronoi di p
			if(pVoronoi[0] != 0){												//se esistono esempi in cella di voronoi di p
				MATRIX nem_vor=voren(p,pVoronoi,n,d);							//nemici di voronoi di p

				//deltaS = deltaS U {nn(p, Voren(p,S,T)}
				if(nem_vor[0] != 0){													//se esistono nemici di voronoi
					VECTOR nearest_neighbor(VECTOR p,MATRIX nem_vor,int n,int d);
					VECTOR nV=nearest_neighbor(p,nem_vor,n,d);
					int j;
					for(j=0; j<d+1; j++){
						deltaS[nd*(d+1)+j]=nV[j];								//inserisce in deltaS i NN di p tra i Voren
					}
					nd++;
					int ricercaEsempio(VECTOR p, DATASET T, int n, int d);
					Sid[nS]=ricercaEsempio(nV,T,n,d);							//inserisce la riga in T dell'esempio in Sid
					nS++;
					free(nV);
				}
				free(nem_vor);
			}
			h++;
			free(pVoronoi);
		}//while interno
		free(R);
	}//while esterno

	free(S);
	free(p);
	free(deltaS);

	return Sid;
}//fcnn

/*
 * Funzione che calcola i centroids di T
 * Ogni volta che si calcola un centroid, si inserisce
 * la sua riga nel SUBSETID, perchè nel metodo fcnn
 * nella prima iterazione del while, tutti i centroids
 * si inseriscono nel SUB-DATASET S
 */
MATRIX centroids(DATASET T, int n, int d, int m, SUBSETID Sid) {
	MATRIX cids = alloc_matrix(m,d);							//matrice dei centroids
	VECTOR classiUsate=(float*) malloc(m*sizeof(float));		//array che memorizza le classi già usate
	VECTOR c=calloc(sizeof(float),d+1);
	int k=0;													//conta centroid calcolati e si usa come indice di classiUsate
	int i=0;													//indice di riga di T
	float classe;
	while (k < m){												//finchè non ho calcolato m centroid
		int flag = 1;											//flag che mi segnala se ho già usato quella classe
		classe=T[i*(d+1)+d];
		int j;
		for(j=0; j<k; j++) {									//itero sull'array delle classi
			if(classe == classiUsate[j]){						//se è già stato calcolato il centroid per la classe che sto visitando
				flag = 0;
			}
		}
		if (flag == 1) {										//se centroid non è stato ancora calcolato
			VECTOR cid(DATASET T,int n,int d,int i);
			c = cid(T,n,d,i);									//calcolo centroid della classe
			classiUsate[k] = classe;							//metto classe, per cui ho calcolato il centroid, in posizione k dell'array classi
			int j;
			for (j=0; j<d+1; j++){
				cids[k*(d+1)+j] = c[j];							//metto centroid in riga k della matrice cids
				int ricercaEsempio(VECTOR c, DATASET T, int n, int d);
				Sid[k]=ricercaEsempio(c,T,n,d);
			}
			k++;												//incremento k perchè ho calcolato un centroids
		}
		i++;													//vado a riga successiva di T
	}

	free(c);
	free(classiUsate);
	return cids;
}

/*
 * Calcolo centroid avendo in input l'indice (riga)
 * della prima occorrenza della classe nella matrice
 */
VECTOR cid(DATASET T, int n, int d, int r) {
	VECTOR array = calloc(sizeof(float),d+1);
	float classe = T[r*(d+1)+d];
	int cont = 0;										//conto occorrenze esempi per la classe
	array[d] = classe;

	int i;
	for (i=r; i<n; i++) {								//scorro righe matrice da r in avanti, perchè per quelle passate abbiamo già il centroid
		if (T[i*(d+1)+d] == classe) {					//se la classe dell'esempio corrente è quella per cui vogliamo calcolare centroid
			cont++;
			int j;
			for (j=0; j<d; j++) {
				array[j] += T[i*(d+1)+j];
			}
		}
	}

	//calcolo del punto geometrico
	for (i=0; i<d; i++){
		array[i] = array[i] / cont;						//somma dei punti degli esempi della classe per posizione i / #esempi di quella classe
	}

	VECTOR puntoCentroids(DATASET T, int n, int d, VECTOR array, float classe, int r);
	VECTOR c = puntoCentroids(T, n, d, array, classe, r);

	free(array);
	return c;
}

/*
 * Da centro geometrico e classe, calcola il punto più vicino
 * al centro geometrico, ovvero il centroid
 *
 * In input ho la classe per cui calcolo il centroid e
 * il centro geometrico di quella classe
 */
VECTOR puntoCentroids(DATASET T, int n, int d, VECTOR centro, float classe, int r) {
	VECTOR centroid = calloc(sizeof(float),d+1);
	VECTOR supp = calloc(sizeof(float),d);
	float minDist=0;
	centroid[d]=classe;
	int riga=r;

	int j;
	for(j=0;j<d;j++){
		supp[j]=T[r*(d+1)+j];
	}
	float distanza(VECTOR supp,VECTOR centro,int d);
	minDist=distanza(supp,centro,d);							//imposto come distanza minima iniziale la distanza rispetto al primo esempio in T

	int i;
	for(i=r+1; i<n; i++) {
		if(T[i*(d+1)+d] == classe) {
			for(j=0; j<d; j++) {
				supp[j]=T[i*(d+1)+j];
			}
		}
		float distanza(VECTOR supp,VECTOR centro,int d);
		float dist=distanza(supp,centro,d);
		if (minDist>dist){
			minDist=dist;
			riga=i;
		}
	}

	for(j=0; j<d; j++){
		centroid[j]=T[riga*(d+1)+j];
	}

	free(supp);
	return centroid;
}

/*
 * calcolo della distanza tra 2 oggetti
 */
float distanza (VECTOR x, VECTOR y, int d){
	float distanza=0;
	int i;
	for(i=0; i<d; i++) {
		distanza += pow((x[i]-y[i]),2);
	}
	return sqrt(distanza);
}

/*
 * Calcola i punti di T\S nella cella di Voronoi
 * per un punto p in S
 */
MATRIX voronoi(VECTOR p, DATASET T, DATASET S, int n, int d, int nS){
	MATRIX risultato=alloc_matrix(n,d+1);					//matrice risultato con gli esempi q nella cella di voronoi di p
	//array di supporto
	VECTOR q=calloc(sizeof(float),d+1);
	VECTOR nn=calloc(sizeof(float),d+1);
	int k=0;												//contatore per tenere traccia della riga corrente in risultato
	int nT=n-nS;

	int i;
	for (i=0;i<nT;i++){
		int j;
		for (j=0;j<d+1;j++){
			q[j]=T[i*(d+1)+j];											//riempio array con esempi in T\S
		}
		VECTOR nearest_neighbor(VECTOR q,DATASET S,int n,int d);
		nn=nearest_neighbor(q,S,nS,d);									//nearest neighbor di q in S
		int flag=1;
		int r;
		for(r=0;r<d+1;r++){
			if(nn[r] != p[r]) flag=0;
		}
		if(flag==1) {											//se p è il nearest neighbor di q, cioè q è in cella di voronoi di p
			int j;
			for (j=0;j<d+1;j++){
				risultato[k*(d+1)+j]=q[j];
			}
			k++;												//passo a riga successiva in risultato
		}//if
	}
	free(q);
	free(nn);
	return risultato;
}

/*
 * calcola i nemici di voronoi
 * dell'esempio p in input
 */
MATRIX voren (VECTOR p, DATASET T, int n, int d){
	MATRIX vor = alloc_matrix(n,d+1);
	float nnrule(VECTOR p,DATASET T,int n,int d);
	float classevicino = nnrule(p,T,n,d);									//calcolo della classe del nearest neighbor di p
	int k=0;
	int i;
	for (i=0; i<n; i++) {
		if (T[i*(d+1)+d] != classevicino) {									//oggetto corrente ha una classe diversa dal NN
			int j;
			for (j=0; j<d+1; j++){
				vor[k*(d+1)+j] = T[i*(d+1)+j];
			}
			k++;
		}
	}
	return vor;
}

/*
 * calcolo nearest neighbor dell'esempio q
 */
VECTOR nearest_neighbor (VECTOR q, DATASET T, int n, int d){
	VECTOR nn=calloc(sizeof(float),d+1);
	int nnRiga(VECTOR q,DATASET T,int n,int d);
	int riga=nnRiga(q,T,n,d);
	int j;
	for (j=0;j<d+1;j++){
		nn[j] = T[riga*(d+1)+j];
	}
	return nn;
}

/*
 * calcolo la riga del nearest neighbor dell'esempio q
 */
int nnRiga (VECTOR q, DATASET T, int n, int d){
	float minDist;
	float dist;
	int riga=0;
	VECTOR p=calloc(sizeof(float),d+1);					//vettore di supporto

	int j;
	for(j=0;j<d;j++){
		p[j]=T[j];
	}
	minDist=distanza(p,q,d);							//imposto come distanza minima iniziale la distanza rispetto al primo esempio in T

	int i;
	for (i=1; i<n; i++){
		int j;
		for (j=0; j<d; j++){
			p[j]=T[i*(d+1)+j];							//metto esempio di riga i nell'array p
		}
		dist=distanza(p,q,d);							//calcolo distanza tra esempio corrente e q
		if (dist<minDist){								//se è l'esempio più vicino aggiorno
			minDist=dist;
			riga=i;
		}
	}
	free(p);
	return riga;
}

/*
 * calcola classe del nearest neighbor
 */
float nnrule (VECTOR q, DATASET T, int n, int d){
	int riga=nnRiga(q,T,n,d);
	float classe=T[riga*(d+1)+d];
	return classe;
}

/*
 * cerca esempio nel DATASET T
 * e restituisce la sua riga
 */
int ricercaEsempio(VECTOR p, DATASET T, int n, int d){
	int i;
	for(i=0;i<n;i++){
		int j=0;
		if(p[d]==T[i*(d+1)+d]){							//verifica se le classi degli esempi confrontati corrispondano
			while(j<d){
				if(p[j] != T[i*(d+1)+j]){
					break;								//se si trova un elemento diverso vai ad esempio successivo del DATASET
				}
				j++;
				if (j == d) return i;
			}
		}
	}
	return -1;
}

/*
 * calcola il DATASET risultante dagli esempi di T
 * meno gli esempi in S
 */
MATRIX rimanenti (DATASET T, int n, int d, SUBSETID Sid, int nS){
	int nR=n-nS;
	MATRIX rim = alloc_matrix(nR,d+1);
	int k=0;												//indice di riga per rim
	int h;													//indice di riga per S
	int cont=0;												//verifica se ho già trovato tutte le righe in Sid anche in T così non si deve più fare controllo
	int flag;												//verifico se devo inserire in soluzione la riga i di T
	int i;
	for(i=0; i<nR; i++){
		flag=1;
		h=0;
		while(h<nS || cont<nS){								//finchè ci sono altri esempi in S OPPURE non ho trovato tutte le occorrenze di S in T
			if(i==Sid[h]){									//se l'esempio sulla riga i è presente anche in S, non lo aggiungo alla soluzione
				flag=0;
				cont++;
				break;										//esco dal while perché la riga i di T è in Sid e quindi vado a riga successiva in T
			}
			else {
				h++;											//vado a posizione successiva in Sid perchè la riga i di T potrebbe essere più avanti
			}
		}
		if(flag==1){											//se l'esempio sulla riga di T non è in S
			int j;
			for(j=0; j<d+1; j++){
				rim[k*(d+1)+j]=T[i*(d+1)+j];						//non ho trovato la riga i di T in Sid e quindi inserisco riga in risultato
			}
			k++;
		}
	}
	return rim;
}

int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;// numero di dimensioni di ogni esempio
	int m = 2;// numero di classi

	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
		par++;
	}

	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}

	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}

	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
			printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
	printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);

	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
	printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
	printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);

	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
			printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);

	return 0;
}
