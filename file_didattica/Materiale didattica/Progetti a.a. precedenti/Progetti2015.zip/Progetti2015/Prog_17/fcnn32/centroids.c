#include <stdlib.h>
#include <stdio.h>
#include <xmmintrin.h>


extern void asmaverage_aligned(float* matrix,int m, int d, int n, float *avg, int* count,int padding);
extern void asmdistance_unroll(float* p, float* q, int d, float* dist);

void centroids(float* matrix, int d, int m, int n,int* index,int padding){
	int i,k;
	float* media;
	media=(float*)get_block(sizeof(float),m*(d+1+padding));
	if(media==NULL){
		printf("Memoria non disponibile per la matrice 'media'!\n");
		exit(-1);
	}
	int* count;
	count=(int*) get_block(sizeof(int),m);
	if(count==NULL){
		printf("Memoria non disponibile per il vettore count!\n");
		exit(-1);
	}
	for(i=0;i<m*(d+1+padding);i++)
		media[i]=0;
	for(i=0;i<m;i++)
		count[i]=0;

	asmaverage_aligned(matrix,m,d,n,media,count,padding);

	free_block(count);
	float dtmp=0;
	float* dmin; //per ogni classe mantengo le distanze minime temporanee
	dmin=(float*) get_block(sizeof(float),m);
	if(dmin==NULL || index==NULL){
		printf("!!![centroids2()] Memoria non disponibile!\n");
		exit(-1);
	}
	else{
		
		for(i=0; i<m; i++)
			dmin[i]=-1;
		for(i=0; i<n*(d+1+padding); i+=d+1+padding){
			k=matrix[i+d];
			asmdistance_unroll(&matrix[i],&media[k*(d+1+padding)],d,&dtmp);
			if(dmin[k]==-1 || dmin[k]>dtmp){	
				dmin[k]=dtmp;
				index[k]=i/(d+1+padding);
			}
		}	
	}
	free_block(dmin);
	free_block(media);
}		
	
