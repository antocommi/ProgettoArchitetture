/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-32 + SSE
 * 
 * Sacco Ludovica, Caputo Pietro
 * 
 ****************************************************************************/
/*
 * 
 *	Le funzioni sono state scritte assumendo che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria.
 * 	Le matrici sono inoltre memorizzate per righe (row-major order).
 *
 * 
 */
 
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>
#include <float.h>

#define	MATRIX		float*
#define	VECTOR		float*
#define	DATASET		float*
#define SUBSETID	int*
#define ALIGN		4

typedef enum {false = 0,true = 1} bool;

void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


/*
 * 
 * 	load_input
 * 	===========
 *
 *	VERIFICA ALLINEAMENTO (row-major-order)
 *	Versione a 32 bit ----> fattore di allineamento align=4
 *	Versione a 64 bit ----> fattore di allineamento align=8
 *	se (d+1)<align
 *		then aggiungi padding=align-(d+1) colonne (di 0)
 *	else 
 *		aggiungi padding= align - resto((d+1)/align) colonne (di 0)
 *
 * 
 */
DATASET load_input(char* filename, int *n, int *d, int *m,int *padding) {	
	FILE* fp;
	int rows, cols, status, i,j;

	fp = fopen(filename, "rb");
	
	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}
	
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	
	int p=0;
	if(cols < ALIGN)
		p=ALIGN-cols;
	else
		if(cols%ALIGN!=0)
			p = ALIGN-(cols%ALIGN);

	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);
	if(p!=0){
		int inc=0;	
		DATASET T2 = alloc_matrix(rows,cols+p);
	
		for(i=0; i<rows*(cols+p); i=i+cols+p){
			for(j=0;j<cols;j++){
				T2[i+j]=T[i+j-inc];
			}
			for(j=cols;j<cols+p;j++){
				T2[i+j]=0;
				inc++;
			}
		}	 
		dealloc_matrix(T);
		*m = 0;
		for (i = 0; i < rows; i++)
			if (T2[i*(cols+p)+cols-1] > *m)
				*m = T2[i*(cols+p)+cols-1];
		(*m)++;
		*n = rows;
		*d = cols-1; //restituisce il numero di attributi
		*padding=p;
		return T2;
	}
	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1; //restituisce il numero di attributi
	*padding=p;
	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, int padding, DATASET T) {	
	FILE* fp;
	int i;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);
	
	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*(cols+padding)], sizeof(float), cols, fp);
	fclose(fp);
}


extern void centroids(float* matrix, int d, int m, int n, int* index,int padding);
extern bool notIn(int q, int* Sid, int dim);
extern void asmdistance_unroll(float* p, float* q, int d, float* dist);

SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn,int padding) {
	float ditemp=0;	
	int i,j,dimS,q,p;	
	int *nearest, *rep;
	float *distanceQ, *distanceRep,*classLabel;
	int row_length=(d+1+padding);

	SUBSETID Sid = (SUBSETID) get_block(sizeof(int),n);

	SUBSETID deltaS;
	int nDeltaS=m; 				        //nDeltaS = numero di elementi in deltaS (m la prima volta) 	
	deltaS=(int*) get_block(sizeof(int),nDeltaS);

	centroids(T,d,m,n,deltaS,padding);

	dimS=*Sn;					//usiamo una variabile locale che alla fine sarà modificata
	distanceQ=(float *)alloc_matrix(1,n);		//mantiene le distanze tra q appartenente a T-S e nearest[q] appartenente a deltaS
	nearest=(int *)get_block(sizeof(int),n);	//mantiene per ogni q appartenente a T-S il suo vicino più vicino in S

	rep=(int *) get_block(sizeof(int),n);		//mantiene per ogni p di S il nemico più vicino appartenente a T-S
	distanceRep=(float *)alloc_matrix(1,n);		//mantiene per ogni p di S la distanza dal suo nemico più vicino
	classLabel=(float *)alloc_matrix(1,n);		//mantiene la classe di ogni elemento q di T
	for(i=0; i<n; i++){
		nearest[i]=-1;				
		distanceQ[i]=FLT_MAX;
		classLabel[i]=T[i*row_length+d];
	}

	while(nDeltaS!=0){
		j=0;
		for(i=dimS;i<dimS+nDeltaS;i++){
			Sid[i]=deltaS[j];
			j++;
		}
		dimS+=nDeltaS;				//Sn=Sn+nDeltaS
		for(i=0; i<n; i++){
			rep[i]=-1;
			distanceRep[i]=FLT_MAX;
		}	
		for(q=0; q<n; q++){ //for each(q in T-S), la i nel for è utilizzata per scorrere T
			if( notIn(q,Sid,dimS) ){
				for(j=0; j<nDeltaS; j++){//for each(p in deltaS)
					p=deltaS[j];
					asmdistance_unroll(&T[p*row_length],&T[q*row_length],d,&ditemp);
					if(distanceQ[q]>ditemp){
						distanceQ[q]=ditemp;					
						nearest[q]=p;	
					}
				}
				if(classLabel[q]!=classLabel[nearest[q]] && distanceQ[q]<distanceRep[nearest[q]]){
					rep[nearest[q]]=q;	
					distanceRep[nearest[q]]=distanceQ[q];
				}		
			}			
		}						
		free_block(deltaS);				//svuotiamo deltaS
		deltaS=(int *)get_block(sizeof(int),dimS);	//creiamo e riempiamo il nuovo deltaS
		nDeltaS=0;	
		j=0;
		for(i=0;i<dimS;i++){	//for each (p in S)
			p=Sid[i];
			if(rep[p]!=-1){		  //if rep[p] is defined
				deltaS[j]=rep[p]; //rep[p] entra in deltaS e quindi andrà in Sid
				nDeltaS++;
				j++;
			}
		}
	}
    	free_block(deltaS);
    	free_block(rep);
	dealloc_matrix(distanceRep);
    	free_block(nearest);
	dealloc_matrix(distanceQ);
	
	*Sn=dimS;
	return Sid;
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	int padding=0;
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &d, &m, &padding);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*((d+1)+padding); i++) {
			if (i % (d+1+padding) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes, %d columns, %d padding...\n,", n, d, m, d+1, padding);
	
	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn,padding);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1+padding; j++)
				printf("%f ", T[Sid[i]*(d+1+padding)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,padding,T);
	dealloc_matrix(T);
	return 0;
}
