#include <stdlib.h>
#include <stdio.h>
typedef enum {false = 0,true = 1} bool;
bool notIn(int q, int *Sid, int dim){
	int i;	
	for(i=0; i<dim; i++)
		if(q==Sid[i])
			return false;
	return true;
}
