/****************************************************************************
 *
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 *
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 *
 * Giandemetrio Quattromani
 *
 ****************************************************************************/

/*

 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software
 installabili mediante il packaging tool del sistema
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 fcnn64.nasm && gcc -O0 -m64 -mavx fcnn64.o fcnn64c.c -o fcnn64c && ./fcnn64c

 oppure

 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 *
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere
 * 	memorizzate mediante array di array (float**).
 *
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 *
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*

typedef struct MatClassi
{
  int** mat;
  int* numElem;
} Mat_Classi;

typedef struct DistanzaClasse
{
  float* distanze;
  float* etichette;
} DistClass;

typedef struct VettoreDim
{
  int* array;
  int dim_arr;
} VettoreDim;
typedef struct Minimo
{
  float minimo;
  int pos;
} Minimo;


void* get_block(int size, int elements) {
	return _mm_malloc(elements*size,32);
}


void free_block(void* p) {
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


/*
 *
 * 	load_input
 * 	===========
 *
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 *
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola
 *
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");

	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}

	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;

	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {
	FILE* fp;
	int i;

	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);

	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*cols], sizeof(float), cols, fp);
	fclose(fp);
}



//**************METODI CREATI****************\\

float** createMfloat (int r, int c){
	float** m;
	int i,j;
	m = (float**) malloc (r*sizeof(float*));
	if(m == NULL)
	{
		printf("memoria non disponibile! \n");
		exit(-1);
	}
	else
	{
		for(i = 0; i < r; i++)
		{
			m[i] = (float*) malloc (c*sizeof(float));
			if(m[i] == NULL)
			{
				printf("memoria non disponibile! \n");
				for(j = 0; j < i; j++) {
					free(m[j]);
				}
				free(m);
				exit(-1);
			}
		}
	}
	return m;
}

int** createMint (int r, int c){
	int** m;
	int i,j;
	m = (int**) malloc (r*sizeof(int*));
	if(m == NULL)
	{
		printf("memoria non disponibile! \n");
		exit(-1);
	}
	else
	{
		for(i = 0; i < r; i++)
		{
			m[i] = (int*) malloc (c*sizeof(int));
			if(m[i] == NULL)
			{
				printf("memoria non disponibile! \n");
				for(j = 0; j < i; j++) {
					free(m[j]);
				}
				free(m);
				exit(-1);
			}
		}
	}
	return m;
}

void printArrayInt(int* array,int len){
    printf("\n");
    printf("Stampa array: \n");
    int i;
    for(i = 0; i < len; i++) {
        printf("%d ", array[i]);
        printf("\n");
    }
    printf("\n");
}

void printArrayFloat(float* array,int len){
    printf("\n");
    printf("Stampa array: \n");
    int i;
    for(i = 0; i < len; i++) {
        printf("%f ", array[i]);
        printf("\n");
    }
    printf("\n");
}

void printMatrixInt(int** matrix, int r,int c){
    int i,j;
    printf("\n Stampa matrice: \n");
    for (i=0;i<r;i++){
        for (j=0;j<c;j++){
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }

}

void printMatrixFloat(float** matrix, int r,int c){
    int i,j;
    printf("\n Stampa matrice: \n");
    for (i=0;i<r;i++){
        for (j=0;j<c;j++){
            printf("%f ", matrix[i][j]);
        }
        printf("\n");
    }

}



float euclideanDistance (float* a, float* b, int d){
//distanza tra due esempi a e b, d è invece la dimensionalità esclusa quindi l'etichetta
    ///complessità d
    float distance=0;
    int i;
    for (i=0; i<d;i++){  //ricordo che l'etichetta si trova in d+1 quindi se metto d escludo l'etichetta
       distance += pow((a[i]-b[i]),2);
    }

    return sqrt(distance);

}




int* getContaClassi (DATASET T, int n, int d, int m){
//inizializza un array di contatori per le classi a 0
///complessità m

    int* contaClasse=calloc(sizeof(int),m); //array dove memorizzo i contatori di ogni classe
    //che mi servono per creare la matrice
    int i;
    for (i=0;i<m;i++){ //inizializzo il vettore del numero degli elementi a 0
        contaClasse[i]=0;
    }

    return contaClasse;

}


Mat_Classi getMatriceClassi (DATASET T, int n, int d, int m){
    ///complessità n*(d+1)

    int* contaClasse=getContaClassi(T,n,d,m);//inizializzo i contatori delle classi a 0
    int** esempiClass=createMint(m,n);
    /*
    crea una matrice dove m è il numero di righe e n numero di colonne (max possibile)
    memorizza quindi in ogni riga la posizione nel DATASET degli elementi corrispondenti a quella classe
    */
    int i,t,j,p;

    p=0; //tengo conto del numero dell'elemento del dataset
    for (i=d+1;i<=n*(d+1);i=i+d+1){

            t=T[i-1];//sarebbe l'etichetta
            j=contaClasse[t];//posizione della matrice dove salvare
            esempiClass[t][j]=p; //riempio la matrice
            //printf("t=%d j=%d p=%d   ",t,j,p);
            contaClasse[t]=contaClasse[t]+1;
            p++;
            //printf("contaClasse[%d]=%d \n",t,contaClasse[t]);

    }

    Mat_Classi mc={esempiClass,contaClasse};


    return mc;

}

int* puntiCentrali(int** matClassi, int m, int* numElementiClassi){
///complessità m
//restituisce la posizione dell'elemento centrale di ogni classe
    int* puntiCentral=calloc(sizeof(int),m);
    int i,j,pos,centro;
    for (i=0;i<m;i++){//per ogni classe i
        pos=numElementiClassi[i]/2;//posizione dell'elemento centrale della classe
        centro=matClassi[i][pos];
        puntiCentral[i]=centro;
    }
    /*printf("PUNTI CENTRALI DELLE CLASSI\n");
    printArray(puntiCentral,m);*/
    return puntiCentral;
}


int* minDistance(float** distanzeCentr, int*numElementiClassi, int m){
///complessità n
//restituisce la posizione dell'elemento che ha distanza minima (ma !=0 per evitare se stesso)
//nella matrice delle distanze
    int* pos=calloc(sizeof(int),m);//vettore inizializzato al numero di classi
    int i,j,z;
    float min;




    for (i=0;i<m;i++){ //per ogni classe
        //min=distanzeCentr[i][0];
        //pos[i]=0;

        for (z=0;z<numElementiClassi[i]; z++){ //questo for risolve il problema della distanza=0 nei primi elementi
        //trovo una distanza diversa da zero e poi esco dal for
             if (distanzeCentr[i][z]==0){
                continue;
             }
             min=distanzeCentr[i][z];
             pos[i]=z;
             break;
        }

        z=pos[i];

        //printf("distanzeCentr[%d][0]=%f   min=%f   pos=%d   \n",i,distanzeCentr[i][0],min,pos[i]);
        for(j=z;j<numElementiClassi[i];j++){
            //printf("distanzeCentr[%d][%d]=%f   min=%f   pos=%d    \n",i,j,distanzeCentr[i][j],min,pos[i]);
            if(distanzeCentr[i][j]<min && distanzeCentr[i][j]!=0){
                min=distanzeCentr[i][j];
                pos[i]=j;
            }
        }
    }
    return pos;

}





float** distanzeCentrale (DATASET T, int m, int d, int** matClassi, int n, int* numElementiClassi){
///complessità n*d
//restituisce una matrice che rappresenta le distanze di ogni punto di una classe dal punto centrale
//di tale classe
    float** distanzeCen=createMfloat(m,n);
    int* puntiC=puntiCentrali(matClassi,m,numElementiClassi);
   // printArray(puntiC,m);

    int i,j,z,h,k;
    float istanzaTest[d];//elemento centrale della classe
    float tempor[d]; //esempio della matrice

    for (i=0;i<m;i++){//per ogni classe i
        k=puntiC[i];
        for(z=0;z<d;z++){//prelevo nel dataset gli esempi
                istanzaTest[z]=T[k*d+z]; //punto centrale della classe
        }

        for(j=0;j<numElementiClassi[i];j++){//per ogni indice j della matrice degli indici organizzati per classe
            h=matClassi[i][j];

            for(z=0;z<d;z++){//prelevo nel dataset gli esempi
                tempor[z]=T[h*d+z]; //elemento su cui calcolare la distanza

            }
            distanzeCen[i][j]=euclideanDistance(istanzaTest,tempor,d);
        }
    }


    return distanzeCen;

}




extern void centroidsN(int** esempiClass, int* nElementiClass, int* minDist, int m, int* arrayCentroids);

int* centroids(DATASET T, int n, int d, int m){ //restituisce l'indice del centroid di ogni classe
    ///complessità getMatriceClassi() + distanzeCentrale() + minDistance () + m

   /* ///Codice chiamata NASM
    Mat_Classi matrC=getMatriceClassi(T,n,d,m);
    int** esempiClass=matrC.mat;//restituisce la posizione gli esempi nel dataset per classe
    int* nElementiClass=matrC.numElem;//restituisce un array con il numero di elementi per ogni classe

    float** distanzeCen=distanzeCentrale(T,m,d,esempiClass,n,nElementiClass);

    int* minDist=minDistance(distanzeCen,nElementiClass,m);//restituisce in un array le posizioni nella matrice

    int* arrayCentroids=calloc(sizeof(int),n);//se metto m ci sono problemi

    centroidsN(esempiClass,nElementiClass,minDist,m,arrayCentroids);

    return arrayCentroids;

*/



   ///Codice tradoto in NASM
    Mat_Classi matrC=getMatriceClassi(T,n,d,m);
    int** esempiClass=matrC.mat;//restituisce la posizione gli esempi del dataset per classe
    int* nElementiClass=matrC.numElem;//restituisce un array con il numero di elementi per ogni classe

    float** distanzeCen=distanzeCentrale(T,m,d,esempiClass,n,nElementiClass);// restituisce la matrice delle...

    int* minDist=minDistance(distanzeCen,nElementiClass,m);//restituisce in un array le posizioni nella matrice

    int* arrayCentroids=calloc(sizeof(int),n);//se metto m ci sono problemi
    int i,j,l;

    for (i=0;i<m;i++){
        l=minDist[i];//posizione del centroid nella matrice delle distanze
        arrayCentroids[i]=esempiClass[i][l];//posizione del centroid nel dataset
    }

    return arrayCentroids;




}




extern void minArray(float* r, int n, int posiz);

Minimo min(float* r, int n){ //ritorna la posizione nell'array delle distanze del minimo !=0
    ///complessità iS
    float minimo;
    int pos;
    int i,j;

    for (j=0;j<n; j++){ //questo for risolve il problema della distanza=0 nei primi elementi
    //trovo una distanza diversa da zero e poi esco dal for
         if (r[j]==0){
            continue;
         }
         minimo=r[j];
         pos=j;
         break;
    }

    j=pos;

    for (i=j;i<n;i++){
        if (r[i]<minimo && r[i]!=0){
            minimo=r[i];
            pos=i;
        }
    }

    Minimo minm={minimo,pos};
    return minm;
}





float calcolaDistanza(DATASET T, int d,int q, int p){
    float istanzaP[d];
    float istanzaQ[d];
    int z;

        for (z=0;z<d;z++){
              istanzaQ[z]=T[(q+1)*(d+1)-d-1+z];
              istanzaP[z]=T[(p+1)*(d+1)-d-1+z];
        }

    return euclideanDistance(istanzaQ,istanzaP,d); //Distanza di q rispetto a p

}




int eIncluso (int qPos,int* visitati, int n){
//verifica se q fa già parte di S e ritorna 1(incluso) o -1(non incluso)
// qPos sarebbe l'elemento del dataset T
///complessità temporale trascurabile

    int verifica=-1;//false

    if(visitati[qPos]==1){
        verifica=1;//true
    }

    return verifica;

}


void inizializzaArray (int *array, int len){//non usato
    ///complessità len
    int i;
    for (i=0;i<len;i++){
        array[i]=0;
    }

}



extern void fcnn64(DATASET t, int n, int d, int m, SUBSETID Sid, int* Sn);

/*
 *	fcnn
 * 	====
 *
 *	T contiene il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
 * 	in un array lineare in row-major order
 *
 *	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
 * 	del training set.
 *
 * 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
 * 	al sottoinsieme S ed in Sn il numero di oggetti in S.
 * 	Si assume che gli identificatori partono da 0.
 *
 */
SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
	SUBSETID Sid = calloc(sizeof(int),n);


     int visitati [n];//tengo conto degli elementi di T che fanno già parte di S, metto 1 se visitato

    int i,j,k;
    int nearestT[n];//=calloc(sizeof(int),n);//posizione del vicino più prossimo di etichetta diversa
    float distancesT[n];//=calloc(sizeof(float),n);//distanza del vicino più prossimo con etichetta diversa
    int rep[n];
    for(j=0;j<n;j++){
            nearestT[j]=-1;
            distancesT[j]=0;
            visitati[j]=0;
    }


    int* dS=centroids(T,n,d,m);


    int idS=m;
    int iS=*Sn;



    int dim;

    while(idS>0){//fintantochè il num di elementi in dS è >0

        for (i=iS;i<iS+idS;i++){
            Sid[i]=dS[i-iS];//MERGE
            visitati[dS[i-iS]]=1;//CONTA VISITA
        }
        iS=iS+idS;


        for(j=0;j<n;j++){
            rep[j]=-1;
        }





        float temp;
        for (j=0;j<n;j++){//per ogni q (non in S) calcolo la distanza da ogni elemento di S

            if(eIncluso(j,visitati,n)==-1){// se q non fa già parte di S (quindi esclude dal calcolo le righe della matrice che corrispondono gli elementi q del dataset inclusi in Sid)

                for (k=0;k<idS;k++){//aggiungo le nuove distanze alla matrice

                    temp=calcolaDistanza(T,d,j,dS[k]);
                    if(distancesT[j]==0){
                        distancesT[j]=temp;
                        nearestT[j]=dS[k];//posizione nel dataset
                    }else if (temp<distancesT[j]){
                        distancesT[j]=temp;
                        nearestT[j]=dS[k];//posizione nel dataset
                    }
                }

                float etichettaQ=T[((j+1)*(d+1))-1];
                float etichettaNearQ=T[((nearestT[j]+1)*(d+1))-1];
                if (etichettaQ!=etichettaNearQ && rep[nearestT[j]]==-1){
                     rep[nearestT[j]]=j;
                }else if(etichettaQ!=etichettaNearQ && distancesT[j] < calcolaDistanza(T,d,nearestT[j],rep[nearestT[j]]+1)){
                     rep[nearestT[j]]=j;
                }


            }

        }

           //printArrayFloat(distancesT,n);
           // printArrayInt(rep,n);

            dim=0;
            for (i=0;i<n;i++){
                if (rep[i]!=-1){
                    dS[dim]=rep[i];
                    dim++;
                }

            }
            idS=dim;


    }

     *Sn=iS;

    // -------------------------------------------------
    // Codificare qui l'algoritmo risolutivo
    // -------------------------------------------------

    //fcnn64(T, n, d, m, Sid, Sn); // Esempio di chiamata di funzione assembly

    // -------------------------------------------------

    return Sid;
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi

	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}

	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}

	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}

	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);

	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);

	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);

	return 0;
}
