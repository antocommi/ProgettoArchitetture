/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 fcnn64.nasm && gcc -O0 -m64 -mavx fcnn64.o fcnn64c.c -o fcnn64c && ./fcnn64c
 
 oppure
 
 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>
#include <stdint.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,32); 
}

float* get_zero_block_float(int size, int elements) {
	float* result = _mm_malloc(elements*size, 32);
	int i;
	for (i = 0; i < elements; i++){
		result[i] = 0.0;
	}
	return result;
}

int* get_zero_block_int(int size, int elements) {
	int* result = _mm_malloc(elements*size, 32);
	int i;
	for (i = 0; i < elements; i++){
		result[i] = 0;
	}
	return result;
}

void free_block(void* p) {
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX)get_block(sizeof(float), rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}

/*
 * Usiamo il padding per mantenere le strutture dati allineate.
 * La variabile ci dice quindi di quante colonne extra ha bisogno il dataset per far in modo che la sua dimensione sia multiplo di 4.
 * I cicli andranno quindi da 0 a d (o d+1) ma per passare alla riga successiva si sommerà d+1+padding.
 */
int padding;

/*
*
* 	load_input
* 	===========
*
*	Legge da file il training set codificato come una matrice di n righe
* 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
* 	in un array lineare in row-major order
*
* 	Codifica del file:
* 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
* 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
* 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola
*
*/
DATASET load_input(char* filename, int *n, int *d, int *m) {
	FILE* fp;
	int rows, cols, status, i, j;

	fp = fopen(filename, "rb");

	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}

	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	
	// Calcolo il padding a partire da cols (cioè d+1)
	padding = roundUp(cols, 4) - cols;
	DATASET T = alloc_matrix(rows, cols+padding);
	// Modifico il caricamento del file per tenere conto del padding
	// status = fread(T, sizeof(float), rows*cols, fp);
	for (i = 0 ; i < rows*(cols+padding); i+=cols+padding){
		// Per ogni riga leggo cols elementi
		// Sembra che non sia necessario mettere gli altri elementi a 0
		status = fread(&T[i], sizeof(float), cols, fp);
	}
	
	
	fclose(fp);

	*m = 0;
	for (i = 0; i < rows; i++){
		if (T[(i*(cols+padding))+(cols-1)] > *m){			
			*m = T[(i*(cols+padding))+(cols-1)];			
		}
	}
	(*m)++;
	*n = rows;
	*d = cols - 1;

	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {	
	FILE* fp;
	int i;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);
	
	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*(cols+padding)], sizeof(float), cols, fp);
	fclose(fp);
}

// Funzioni di utilità

/*
 * Calcola il più vicino multiplo di multiple a numToRound, usato per calcolare il valore di d dopo il padding.
 */
int roundUp(int numToRound, int multiple) 
{
   return (numToRound + multiple - 1) & ~(multiple - 1);
}

void printPoint(float* point, int size){
	int i;
	printf("(");
	for (i = 0; i < size; i++){
		printf("%f", point[i]);
		if (i < size - 1){
			printf(", ");
		}
	}
	printf(")\n");
}

/*
 * Concatena due array (non controlla se ci sono o meno duplicati).
 * result deve avere dimensione parti a a1size+a2size.
 */
void joinArrays(float* a1, float* a2, float* result, size_t a1size, size_t a2size){
	memcpy(result,          a1, a1size * sizeof(float)); // copia i primi a1size elementi da a1
	memcpy(result + a1size, a2, a2size * sizeof(float)); // copia i primi a2size elementi da a2, scrivendo da result+a1size per non sovrascrivere gli altri
}

/*
 * Restituisce 1 se p e q sono lo stesso punto, e cioè se hanno le stesse coordinate.
 */
int isSamePointC(float* p, float* q, int d){
	// Per confrontare i due punti confronto le loro componenti, e cioè gli elementi da 0 a d-1
	int i;
	for (i = 0; i < d; i++){
		if (p[i] != q[i]) {
			return 0;
		}
	}
	return 1;
}
// Fine funzioni di utilità

// Implementazione delle funzioni

extern void distance(float* source, float* destination, int dimensions, float* result);
extern void barycenterSums(DATASET T, float* tempPoints, int d);
// extern void barycenterDivs(int* classElements, float* tempPoints, int d, int m);
extern void barycenterDivs(int* classElements, float* tempPoints, int d, int m, int padding);
// extern void barycenterDivsParallel(int* classElements, float* tempPoints, int d, int m);
extern int isSamePoint(float* p, float* q, int d);

/*
* Calcola la distanza euclidea tra due punti n-dimensionali come radice della somma tra le differenze delle componenti
*/
void distanceC(float* source, float* destination, int dimensions, float* result){
	// la formula per la distanza è sqrt(sum((source-destination)^2, dimensions)))
	int i;
	for (i = 0; i < dimensions; i++){
		// Scorro tutte le dimensioni
		*result += powf(source[i] - destination[i], 2);
	}
	*result = sqrtf(*result);
}

/*
 * Aggiunge il punto corrente, data la classe, alla somma dei punti tempPoints.
 * I due array vengono ricevuti come puntatori all'offset corretto.
 * tempPoints punterà già a tempPoints[class] mentre T a T[i]
 * In questo modo evitiamo calcoli relativi agli indirizzi e possiamo considerare solo la parte del vettore che ci serve.
 */
void barycenterSumsC(DATASET T, float* tempPoints, int d){	
	int j;
	for (j = 0; j < d; j++){
		// Scorro d-1 elementi perchè il d c'è la classe e a me servono solo gli esempi	
		// printf("tempPoints[%d] + T[%d] = %f + %f = %f\n", j, j, tempPoints[j], T[j], tempPoints[j]+T[j]);
		tempPoints[j] += T[j];
	}
}

/*
 * Completa il calcolo dei baricentri dividendo ogni riga di tempPoints per il numero di elementi
 * presenti nella classe corrispondente.
 */
void barycenterDivsC(int* classElements, float* tempPoints, int d, int m, int padding){
	int current = 0;
	int i,j;
	for (i = 0; i < m*(d+1+padding); i+= d+1+padding){
		// Scorro le righe di tempPoints e divido ogni cella della riga per classElements[i]
		for (j = 0; j < d; j++){
			tempPoints[i+j] /= classElements[current];
		}
		current += 1;
	}
}

/*
 * Calcola il baricentro per ogni classe.
 * Scorro il dataset e, per ogni riga, incremento il contatore relativo alla classe e sommo le componenti con quelle salvate in tempPoints.
 * In questo modo, finito di scorrere il dataset, mi basta prendere ogni riga di tempPoints e dividerla per il contatore associato alla classe.
 */
void barycentersC(DATASET T, int n, int d, int m, float* tempPoints, int* classElements){
	// Contatori usati per scorrere riga/colonna tra i vari dati
	int i;
	// Inizio a scorrere il dataset
	// Vado avanti di d+1 in modo da scorrere una riga per volta
	for (i = 0; i < n*(d + 1 + padding); i += d + 1 + padding) {
		// Adesso che sono sulla riga i avrò in posizione T[i+j] gli elementi della riga
		// In T[i+d] avrò invece le classi
		// Incremento il contatore della classe
		int class = (int)T[i + d];
		classElements[class] += 1;
		// Sommo i d-1 elementi di questo esempio con i rispettivi elementi di tempPoints
		barycenterSums(&T[i], &tempPoints[class*(d+1+padding)], d);
	}
	// Terminato il calcolo delle somme passo a calcolare i baricentri dividendo tempPoints[m][d] per classElements[m]
	// Con d >= 4 conviene usare la versione che esegue i calcoli con 4 registri per volta
	// TODO: con 4 non si nota alcuna differenza di velocità, strano
	// if (d < 4){
		barycenterDivsNew(classElements, tempPoints, d, m, padding);
	// } else {
		// barycenterDivsC(classElements, tempPoints, d, m);
	// }	
}

/*
* Calcoliamo i centroidi a partire dal calcolo del baricentro per ogni classe.
* Per calcolare il baricentro scorro il DATASET e, per ogni riga, aggiungo alla somma della classe e ne incremento il contatore.
* In questo modo, scorrendo una volta sola il DATASET, ho il numero di elementi e la loro somma per ogni classe.
* Per calcolare il baricentro mi basterà eseguire una semplice divisione
*/
float* centroids(DATASET T, int n, int d, int m, SUBSETID Sid){
	// Creo le strutture dati di supporto di cui avrò bisogno
	// Array contenente il contatore per gli elementi di ogni classe (inizializzo così perchè mi serve tutto a 0)
	int* classElements = get_zero_block_int(sizeof(int), m);
	
	// Array 2D contenente le somme temporanee per gli elementi di ogni classe (gli elementi sono d-dimensionali quindi d colonne)
	// tempPoints sarà anche il risultato una volta che ogni cella [m][d] verrà divisa per classElements[m]
	float* tempPoints = get_zero_block_float(sizeof(float), m*(d+1+padding));

	// Array che contiene la distanza migliore del centroide per ogni classe (inizializzo a +inf perchè ci serve il minimo)
	float* centroidsDistances = get_block(sizeof(float), m);

	// Array che contiene un centroide per riga (uno per classe, d-dimensionale)	
	float* result = get_block(sizeof(float), m*(d+1+padding));

	// Contatori usati per scorrere riga/colonna tra i vari dati
	int i, k;

	// Calcolo i baricentri
	barycentersC(T, n, d, m, tempPoints, classElements);

	// Adesso che abbiamo i baricentri per ogni classe devo calcolare il centroide come
	// il punto più vicino, tra quelli di una classe, al suo baricentro.
	// Mantengo quindi un array dei centroidi e, per ogni punto, vedo se la sua distanza è minore di quella del centroide corrente.
	// In questo caso aggiorno sia il centroide che la distanza.

	// Inizializzo l'array delle distanze con un valore enorme
	for (i = 0; i < m; i++){
		centroidsDistances[i] = HUGE_VALF;
	}

	// Scorro il dataset per calcolare le distanze
	for (i = 0; i < n*(d + 1 + padding); i += d + 1 + padding) {
		// Recupero la classe dell'esempio corrente
		int class = (int)T[i + d];
		// Calcolo la distanza dal baricentro (il baricentro si trova in tempPoints[class]
		// Con &T[i] dovremmo inviare solo la parte di T che inizia da i
		float tempDistance = 0;	
		distance(&tempPoints[class*(d+1+padding)], &T[i], d, &tempDistance);
		// Ora che ho la distanze vedo se è minore di quella in centroidsDistances[class] e, in caso, aggiorno
		if (tempDistance < centroidsDistances[class]){
			// Ho trovato un nuovo punto a distanza minore, candidato per essere il centroide
			centroidsDistances[class] = tempDistance;
			// Aggiorno il punto (compresa classe)
			memcpy(&result[class*(d+1+padding)], &T[i], (d+1+padding)*sizeof(float));	
			// Aggiorno anche S			
			// Divido per d+1+padding perchè l'indice della riga si trova in quella posizione, visto che il passo di i è i+=d+1+padding
			Sid[class] = i/(d+1+padding); // L'indice corrente fa parte della soluzione
		}
	}

	// Pulisco la memoria prima di uscire
	free_block(classElements);
	free_block(tempPoints);
	free_block(centroidsDistances);
	return result;
}

/*
 * Restituisce il punto p, definito come il punto più vicino a q nel dataset.
 * Dobbiamo scorrere quindi tutto il dataset e trovare il punto con distanza minore.
 * In result inserisco anche la classe oltre alle coordinate!
 */
float* nn(DATASET T, int n, int d, float* q, SUBSETID ids, int* elementIndex){
	int i;
	float* result = malloc(sizeof(float) * (d+1+padding));
	float bestDistance = HUGE_VALF;
	// Scorro il dataset per calcolare le distanze
	for (i = 0; i < n*(d + 1 + padding); i += d + 1 + padding) {
		// Calcolo la distanza dal punto q
		// Con &T[i] dovremmo inviare solo la parte di T che inizia da i
		// Recupero la classe dell'esempio corrente
		int class = (int)T[i + d];
		float tempDistance = 0;		
		distance(q, &T[i], d, &tempDistance);
		// Ora che ho la distanze vedo se è minore di quella in centroidsDistances[class] e, in caso, aggiorno
		if (tempDistance < bestDistance){
			// Ho trovato un nuovo punto a distanza minore, candidato per essere il centroide
			bestDistance = tempDistance;
			// Aggiorno il punto
			memcpy(result, &T[i], (d+1)*sizeof(float));
			// Aggiorno anche elementIndex con il nuovo elemento trovato
			*elementIndex = ids[i/(d+1+padding)];
		}
	}
	return result;
}

/*
 * In questo caso calcolo nn senza aggiornare l'indice dell'elemento trovato.
 * In nn(p, voren(..)) infatti non ci serve tenere traccia dell'indice del putno trovato.
 * Evitiamo così di dover tenere traccia degli indici in S.
 * E' importante notare che T contiene anche le classi!
 */
float* nn_noindex(DATASET T, int n, int d, float* q){
	int i;
	float* result = malloc(sizeof(float) * (d+1+padding));
	float bestDistance = HUGE_VALF;
	// Scorro il dataset per calcolare le distanze
	for (i = 0; i < n * (d+1+padding); i += d + 1 + padding) {
		// Calcolo la distanza dal punto q
		// Con &T[i] dovremmo inviare solo la parte di T che inizia da i
		// Recupero la classe dell'esempio corrente		
		float tempDistance = 0;		
		// printf("q = %lu, T[i] = %lu, tempDistance = %lu\n", (uintptr_t)&q, (uintptr_t)&T[i], (uintptr_t)&tempDistance);
		distance(q, &T[i], d, &tempDistance);
		// Ora che ho la distanze vedo se è minore di quella in centroidsDistances[class] e, in caso, aggiorno
		if (tempDistance < bestDistance){
			// Ho trovato un nuovo punto a distanza minore, candidato per essere il centroide
			bestDistance = tempDistance;
			// Aggiorno il punto
			memcpy(result, &T[i], (d+1)*sizeof(float));		
		}
	}
	return result;
}

/*
 * Restituisce un insieme di esempi appartenenti a vor(p,S,T) ma con classe diversa da quella dell'esempio p.
 * Scorro quindi il dataset T e verifico, per ogni riga, se l'esempio è nn(p,T) e NN(p, T) != classe(p).
 * S ha lo stesso formato di T, quindi coordinate punto + classe per un totale di d colonne
 */
float* voren(DATASET T, int nT, DATASET S, int nS, int d, float* p, SUBSETID indexes, int* resultSize){
	// Inizializzo il risultato con dimensione pari al dataset
	float* result = get_block(sizeof(float), nT*(d+1+padding));
	// Indice del prossimo elemento da scrivere in result.
	int resultIndex = 0;
	// Scorro T
	int i;
	// Classe di p
	int pClass = p[d];
	
	for (i = 0; i < nT * (d + 1 + padding); i += d+1+padding){
		// Il punto q si trova in posizione i dentro T
		float* q = &T[i];
		int qClass = (int) T[i+d];
		
		// Calcolo il nn(q, S)
		float* nnPoint = nn_noindex(S, nS, d, q);	
				
		// Ora verifico se questo punto è uguale a p e se ha classe diversa da q.
		// Se le due condizioni dovessero essere verificate allora q va aggiunto al risultato.	
		if (isSamePointC(p, nnPoint, d) && pClass != qClass){
			// nn ma classe diversa, ho trovato un voren!
			// Aggiungo q a result e i ad indexes
			memcpy(&result[resultIndex], q, (d+1+padding)*sizeof(float));
			resultIndex += (d+1+padding);
			indexes[*resultSize] = i/(d+1+padding);			
			*resultSize += 1;
		}	

	free_block(nnPoint);		
	
	}	
	// Adesso restituisco a partire da resultIndex
	result = (float*) realloc(result, resultIndex * sizeof(float));	
	return result;
}
// Fine implementazione delle funzioni

/*
*	fcnn
* 	====
*
*	T contiene il training set codificato come una matrice di n righe
* 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
* 	in un array lineare in row-major order
*
*	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
* 	del training set.
*
* 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
* 	al sottoinsieme S ed in Sn il numero di oggetti in S.
* 	Si assume che gli identificatori partono da 0.
*
*/
SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
	// Sid contiene il risultato dell'esecuzione dell'algoritmo
	// SUBSETID è quindi un array che contiene gli indici delle righe di T che fanno parte del sottoinsieme da restituire
	SUBSETID Sid = calloc(sizeof(int), n);

	// -------------------------------------------------
	// Codificare qui l'algoritmo risolutivo
	// -------------------------------------------------
	//fcnn32(T, n, d, m, Sid, Sn); // Esempio di chiamata di funzione assembly
	// ---------------------------------------------
	int i, currentSelement = m;
	
	// S è l'insieme parziale che contiene il subset di T
	DATASET S = calloc(sizeof(int), 1); // = get_zero_block_float(sizeof(int), n*(d+1+padding));	
	
	// Numero di elementi presenti in deltaS ed in S. 
	// Inizialmente deltaS contiene un numero pari al numero delle classi perchè è il risultato di centroids.
	// S invece inizialmente è vuoto.
	int deltaSelements = m, sElements = 0, SidElements = m;
	
	// deltaS è l'insieme che conterrà i centroids e i voren. E' una array di dimensioni m*d e contiene m elementi 
	// Viene inizializzato con i centroids.
	// Centroids contemporaneamente si occupa di aggiornare Sid, in modo da avere gli indici già pronti per il risultato.
	float* deltaS = centroids(T, n, d, m, Sid);
	
	// exit(0);
	// int execs = 0;
	while (deltaSelements != 0){
		// S = S U DS		
		int tmpSelements = (deltaSelements + sElements)*(d+1+padding);
		DATASET tmpS = get_zero_block_float(sizeof(int), tmpSelements);
		joinArrays(S, deltaS, tmpS, (sElements*(d+1+padding)), (deltaSelements*(d+1+padding)));
		
		free_block(S);
		
		S = tmpS;
		sElements = tmpSelements/(d+1+padding);
		
		// DS = {}
		deltaS = realloc(deltaS, 0);
		deltaSelements = 0;
		
		// Controlliamo se vengono aggiunti dei punti a DS in questa iterazione
		// Se non ne vengono aggiunti allora l'algoritmo termina perchè abbiamo visitato tutto ciò che potevamo.
		int addedPoints = 0;

		// for each (p in S)
		for (i = 0; i < sElements; i++) {
			// p è il punto che parte, in S, dall'offset i
			float* p = &S[i*(d+1+padding)];
			
			SUBSETID tmpIndexes = calloc(sizeof(int), n);
			int tmpIndexElements = 0;
			// Voren(p, S, T)
			float* vorens = voren(T, n, S, sElements, d, p, tmpIndexes, &tmpIndexElements);
			
			if (tmpIndexElements == 0) {
				// Se non ho voren per questo punto allora passo al prossimo
				continue;
			}
			
			// nn
			int nnIndex; // Indice del punto restituito da nn	
			float* nnRes = nn(vorens, tmpIndexElements, d, p, tmpIndexes, &nnIndex);
			int nnClass = nnRes[d];

			// Aggiorno DS e Sid
			Sid[SidElements] = nnIndex;			
			SidElements += 1;			
			int tmpDeltaSsize = (deltaSelements*(d+1+padding)) + (d+1+padding);
			float* tmpDeltaS = get_block(sizeof(float), tmpDeltaSsize);
			joinArrays(nnRes, deltaS, tmpDeltaS, d+1+padding, (deltaSelements*(d+1+padding)));
			
			free_block(deltaS);
			free_block(nnRes);
			free_block(tmpIndexes);
			
			deltaS = tmpDeltaS;				
			deltaSelements = tmpDeltaSsize/(d+1+padding);
			
			// Segnalo che ho aggiunto un punto a DS
			addedPoints += 1;
		}
		
		// Controllo se è necessario continuare l'algoritmo
		if (addedPoints == 0){
			break;
		}
		// execs += 1;
		// printf("Execs: %d (%d elements)\n", execs, deltaSelements);
	}
	// Aggiorno la dimensione del risultato
	*Sn = SidElements;
	return Sid;
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi

	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		}
		else if (strcmp(argv[par], "-s") == 0) {
			silent = 1;
			par++;
		}
		else if (strcmp(argv[par], "-d") == 0) {
			display = 1;
			par++;
		}
		else
			par++;
	}

	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}

	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}
	
	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset (%d padding):\n", padding);
		for (i = 0; i < n*(d + 1 + padding); i++) {
			if (i % (d + 1 + padding) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);

	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t) / CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t) / CLOCKS_PER_SEC);

	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d + 1; j++)
				printf("%f ", T[Sid[i] * (d + 1 + padding) + j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);
	
	return 0;
}
