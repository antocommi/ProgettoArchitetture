/*	Classe fcnn1.h
*
*	inserisco un flag per conoscere se DS è vuoto
*	distanza implementata in nasm
*	evito le inizializzazioni dopo le calloc (per rep e nearest)
*	seconda riscrittura del metodo distanza_nasm
*
*	miglioramento metodo centroide
*
*	abbiamo switchato i for, in preparazione al cache blocking
*	cache blockin effettuato
*
*/

#include <stdio.h>
#include <stdlib.h>

#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*

typedef int bool;
#define true 1
#define false 0

void aggiornaDS_fcnn1(int* DS, int* rep, int* chosen, int* Sn, int n, bool* DS_vuoto);
int* centroide_fcnn1(DATASET T, int n, int d, int m, int* Sn);
bool in(int* Array, int p);
extern int distanza_nasm(float* T, int p1, int p2, int d, int p3, int p4);
extern float dist_cent(float* T, int p1, float* centroid, int p2, int d);


SUBSETID fcnn_fcnn1(DATASET T, int n, int d, int m, int* Sn){
	/*	T è una matrice n*(d+1) ridotta a una dimensione, d+1 perchè l'ultimo elemento indica la classe.
	*	d indica le dimensioni
	*	m è il numero delle classi
	*	Sn è un array di un elemento  Sn[0] è uguale alla length di S
	*/

	*Sn = 0;  	//lunghezza dell'array finale (verrà incrementato per ogni elemento aggiunto)

	int* nearest = (int*) calloc(n,sizeof(int));		
	//considero 0 valore non definito e gli indici partiranno da 1 fino a n 	==>	invece di id ho id+1
	/*	Il valore in posizione i, indica l'id del punto più vicino al punto i-esimo.
	*/
	int i;
		
	int* chosen = (int*) calloc(n,sizeof(int));
	/*	Bit set.
	*	
	*/

	//DS sarà sempre di lunghezza pari a chosen
	int* DS = (int*) calloc(n,sizeof(int));
	
	int* DS_id = centroide_fcnn1(T,n,d,m,Sn);

	bool DS_vuoto = false;	// flag per il controllo se DS è vuoto

	//devo settare in DS i bit relativi agli id trovati in centroide
	for(i=0; i<m; i++){
		int id = DS_id[i];
		DS[id] = 1;
	}//for

	if(DS_id != NULL){
		free(DS_id);
	}

	int r=65536/(d+1);		// per il cache blocking	65536 invece dei vecchi 524288
	int num_blocchi = n/r;	
	int resto = n%r;
	while( !DS_vuoto ){


		//UNIONE DS con S, semplice OR bit a bit
		for(i=0; i<n; i++){
			if(DS[i]==1)
				chosen[i] = 1;
		}
		DS_vuoto = true;

		int* rep = (int*) calloc(n,sizeof(int));
		//considero 0 valore non definito e gli indici partiranno da 1 fino a n 	==>	invece di id ho id+1
		/*	I rappresentanti dei punti finora scelti.
		*	Troviamo i più vicini dei punti fuori S (punti q).
		*	Memorizziamo nella q-esima posizione di nearest (2a riga di vor) il punto minimo p trovato.
		*	Scorriamo l'array nearest alla ricerca della posizione q-esima in cui il punto p
		*	ha una distanza più piccola rispetto a q.
		*	Il punto q-esimo trovato è il rappresentante per p (q va in posizione p-esima in rep).
		*/

		int p,q,k;
		for(k=0; k<num_blocchi; k++){

			int limite_blocco_corr = (k+1)*r;
			for(p=0; p<n; p++){
				if(DS[p]==1){
				
					for(q=k*r; q<limite_blocco_corr; q++){
			
						if(chosen[q]==0){	// q non è in chosen
							int nearest_q = nearest[q];	// così accediamo una sola volta in memoria e amen
						
							// p è in DS
							if(nearest_q==0 || distanza_nasm(T,nearest_q-1,q,d,p,q)){
								nearest[q] = p+1;
								nearest_q = p+1;
							}
						}//if(!q_in_S)

					}//for(q)
				}//if(p_in_DS)
			}//for(p)

		}//for(k)

		int kmax = (k*r);
		int limite_resto = kmax+resto;
		if(resto != 0){
			for(p=0; p<n; p++){
				if(DS[p]==1){
					for(q=kmax; q<limite_resto; q++){
				
						if(chosen[q]==0){	// q non è in chosen
							int nearest_q = nearest[q];	// così accediamo una sola volta in memoria e amen
						
							// p è in DS
							if(nearest_q==0 || distanza_nasm(T,nearest_q-1,q,d,p,q)){
								nearest[q] = p+1;
								nearest_q = p+1;
							}
						}//if(!q_in_S)

					}//for(q)
				}//if(p_in_DS)
			}//for(p)
		}//if

		for(q=0; q<n; q++){
			if(chosen[q]==0){
				int nearest_q = nearest[q];

				int l_q = T[d+(d+1)*q];	
				int l_nearest_q = T[d+(d+1)*(nearest_q-1)];
				int rep_nearest_q = rep[nearest_q-1];		// evito più accessi in memoria
				if( (l_q != l_nearest_q) && ( rep_nearest_q == 0 ||
							distanza_nasm(T,nearest_q-1,rep_nearest_q-1,d,nearest_q-1,q)) ){
					rep[nearest_q-1] = q+1;
					rep_nearest_q = q+1;
				}//if
			}
		}//for(q)

		
		if(DS != NULL){
			free(DS);
		}
		DS = (int*) calloc(n, sizeof(int));

		aggiornaDS_fcnn1(DS, rep, chosen, Sn, n, &DS_vuoto);

		if(rep != NULL){
			free(rep);
		}

	}//while
	

	SUBSETID S = (int*) malloc(*Sn*sizeof(int));
	int c=0;
	//estrapolo gli indici da chosen e li inserisco in S
	int p;
	for(p=0; p<n; p++){
		if(chosen[p]==1){	// p è in chosen
			S[c]=p;
			c++;
		}//if
	}//for
	

	if(DS != NULL){
		free(DS);
	}
	if(chosen != NULL){
		free(chosen);
	}
	if(nearest != NULL){
		free(nearest);
	}
	
	return S;

	
}//fcnn()

int* centroide_fcnn1(DATASET T, int n, int d, int m, int* Sn){
	/*	Restituisce un array con gli ID dei punti prescelti come seed.
	*	L'array restituito sarà grande m, perché dobbiamo scegliere un punto per ogni classe.
	*/

	float* centroid = (float*) calloc(m*(d+1), sizeof(float));
		// in centroid ho le coordinate dei punti (la media)
	int i,j;
	for(j=0; j<n;j++){
		int c = T[d+(d+1)*j];	//classe
		for(i=0; i<d; i++){
			centroid[i+c*(d+1)]+=T[i+(d+1)*j];
		}//for
		centroid[d+c*(d+1)]++;
	}//for
	
	for(i=0; i<m;i++){
		int c = centroid[d+i*(d+1)];	//#somme
		if(c!=0){	// anche se non ha senso mettere una classe in input e poi non è presente nessun punto di quella classe
			for(j=0; j<d;j++){
				centroid[j+i*(d+1)] = centroid[j+i*(d+1)]/c;
			}//for	
		}
	}//for

	float* distanze = (float*) calloc(m, sizeof(float));
	// in distanze[i] ho la distanza minima del punto scelto, rispetto al centroide ideale, correntemente trovata per la classe i-esima
	// distanze[i] = 0	==>	distanze[i] = indefinito	evito l'inizializzazione

	int* id = (int*) malloc(m*sizeof(int));
	//TODO e se per una classe non viene scelto alcun punto? ho un numero indefinito in id[classe_non_scelta]

	for(i=0; i<n; i++){
		int cls_i = T[d+(d+1)*i];

		float dis = dist_cent(T,i,centroid,cls_i,d);
		
		if( distanze[cls_i] == 0 || distanze[cls_i] > dis){
			if(distanze[cls_i] == 0){	//abbiamo un centroide di una nuova classe
				*Sn += 1;
			}
			distanze[cls_i] = dis;
			id[cls_i] = i;
		}//if

	}//for

	if(distanze != NULL){
		free(distanze);
	}

	if(centroid != NULL){
		free(centroid);
	}
	
	return id;
	
}//centroide()


void aggiornaDS_fcnn1(int* DS, int* rep, int* chosen, int* Sn, int n, bool* DS_vuoto){

	int p;
	for(p=0; p<n; p++){

		if(chosen[p] == 1){		// p è in chosen
			int rep_p = rep[p];
			if(rep_p != 0){
				DS[rep_p-1] = 1;
				*Sn += 1;
				*DS_vuoto = false;
			}//if
		}//if

	}//for


}//aggiornaDS()
