/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-32 + SSE
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf32 fcnn32.nasm && gcc -O0 -m32 -msse fcnn32.o fcnn32c.c -o fcnn32c && ./fcnn32c
 
 oppure
 
 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define	SUBSETID	int*
#define P			16


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,16); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


extern void clearBitarrayAssembly32_4(int* array,int dim,int valore);
extern void unionBitarrayAssembly32_4(int* array1,int* array2,int dim,int valore);
extern void clearArrayAssembly32_4(int* arrayNearest,int* arrayRep, int n,int valore);
extern void euclideanDistanceAssembly32_4(float* T, int i, int j, int k, int z, int d,float* val0,float* val1);
extern void euclideanDistanceAssemblyParallel32_4(float* T,int i,int p1,int p2,int p3 ,int p4, int z,int d, float* val0, float* val1, float* val2, float* val3,float* val4);


/* ------------- METODI PER LA GESTIONE DEI BITARRAY -------------------------------*/


void printBitarray(int* array, int dim){
	int i;
	int real_dim = (dim/32)+1;
	for (i = 0; i < dim; i += 1){
		printf(" %d ",getValue(array,i));		
	}

}

//ritorna il valore del k-esimo bit

int getValue(int array[],int k){
	int i = k/32;
    int pos = k%32;

    unsigned int flag = 1;  // flag = 0000.....00001

    flag = flag << pos;     // flag = 0000...010...000   (shifted k positions)

    if ( array[i] & flag )      // Test the bit at the k-th position in array[i]
         return 1;
    else
         return 0;
		
}


//imposta il bit in posizione k a 0.

void disactiveBit(int array[],int k){
	int i = k/32;
    int pos = k%32;

    unsigned int flag = 1;  // flag = 0000.....00001

    flag = flag << pos;     // flag = 0000...010...000   (shifted k positions)
    flag = ~flag;           // flag = 1111...101..111

    array[i] = array[i] & flag;     // RESET the bit at the k-th position in array[i]
}


//imposta il bit in posizione k a 1.

void activeBit(int array[],int k){
	int i = k/32;
    int pos = k%32;

    unsigned int flag = 1;   // flag = 0000.....00001

    flag = flag << pos;      // flag = 0000...010...000   (shifted k positions)

    array[i] = array[i] | flag;      // Set the bit at the k-th position in array[i]
    
}


//fa l'unione di due bitarray

void unionBitarray(int* A1,int* A2, int dim){
	
	int valore=dim/P;
	unionBitarrayAssembly32_4(A2,A1,dim,valore);

}


//azzera un bitarray

void clearBitarray(int* array, int dim){

	int valore=dim/P;
	clearBitarrayAssembly32_4(array,dim,valore);
	
	
}


//pone indefiniti i valori di rep

void undefineArray(int* S, int n, int* rep){
	
	int i;
	for (i = 0; i < n; i++){
		if(getValue(S,i) == 1)
			rep[i] = -1;
	}
}




/*-----------------------------------------------------------------------------------*/


/*------------ METODI PER LA GESTIONE DI "NORMALI" ARRAY ----------------------------*/


//pone a -1 tutti i valori dell'array

void clearArray(int* arrayNearest,int* arrayRep, int n){

	int i;
	int valore=n/P;
	clearArrayAssembly32_4(arrayNearest,arrayRep,n,valore);
}


//pone indefiniti i valori di rep

void undefineArrayIbrid(int* ibridS,int dimS,int* rep){
	int i;
	for(i=0;i<dimS;i++){
		rep[ibridS[i]]=-1;
	}
}


//fa l'unione fra deltaS e S, restituisce la nuova grandezza di S

int unionIbridarray(int* ibridDeltaS,int* ibridS,int dimDeltaS,int dimS){
	int i;
	for(i=0;i<dimDeltaS;i++){
		ibridS[dimS]=ibridDeltaS[i];
		dimS++;
	}
	
	return dimS;
}

void printArray(int* array, int dim){
	int i;
	for (i = 0; i < dim; i += 1){
		printf(" %d ",array[i]);		
	}

}


/*-----------------------------------------------------------------------------------*/


/*--------- PORZIONI DI ALGORITMO --------------------------------------------------*/


void averangePositionsCalculation(float* matrix, int n, int d, int m, float* averangePositions){
     
     //ogni riga i di questa matrice conterr� la media aritmetica di tutti gli 
     //esempi che appartengono a quella classe i.
     //in d+1 sar� contenuta la somma del numero di esempi esaminati.
    
	int i,j;
	int classeAttuale;
	float divisore;
	
	
	
	//pongo la matrice creata con coefficenti uguale a zero.
	
	for(i=0;i<m;i++){
		for(j=0;j<d+1;j++){
			averangePositions[i*(d+1)+j]=0;
		}
	}
	
         
	for(i=0;i<n;i++){
		
		//prendo il valore della classe di appartenenza e modifico il
		//valore da tipo float a tipo int in modo da poterlo usare cone indice
		//per la matrice averangePositions.
		
		classeAttuale=(int)matrix[i*(d+1)+d];
		
		//ora faccio la media aritmetica.
		
		for(j=0;j<d;j++){          
			averangePositions[classeAttuale*(d+1)+j]=averangePositions[classeAttuale*(d+1)+j]+matrix[i*(d+1)+j];
		}
		
		//incremento il numero di esempi esaminati per quel tipo di classe
		
		averangePositions[classeAttuale*(d+1)+j]++;
    }
    
    for(i=0;i<m;i++){
		divisore=averangePositions[i*(d+1)+d];
		if(divisore==0){
			for(j=0;j<d;j++){
				averangePositions[i*(d+1)+j]=0;
			}
		}
		else{
			for(j=0;j<d;j++){
				averangePositions[i*(d+1)+j]=averangePositions[i*(d+1)+j]/divisore;
			}
		}  
    }                                 
}


//calcola l'indice del centroide, cio� il pi� vicino esempio alla "posizione media" della classe
 
int nearestNeighborAverange(float* set,float* averangePositions,int n,int d,int class){

	// set = in questo caso � l'intero dataset	
	// n = numero di esempi (quindi numero di righe di set)
	// d = numero dimensioni (quindi numero colonne)
	// class = classe a cui stiamo trovando il centroide, il nearest nighbor della sua "posizione media" 
	
	int k; // indice scorrimento righe dataset
	float distance;
	int z; //indice scorrimento colonne dataset
	int nn = -1;
	float minDist = -1.0;

	

	for(k = 0; k<n; k++){ //scorro il dataset
		if((int)set[k*(d+1)+d] == class){ //se l'esempio fa parte della classe da controllare...

			//... calcolo distanza euclidea dalla "posizione media"...	
			
			distance = 0;
			for (z = 0; z<d; z++){
				distance = distance + pow(set[k*(d+1)+z]-averangePositions[class*(d+1)+z],2);
			}	
			distance = sqrt(distance);
		

			//... controllo se � il piu' vicino
	
			if(distance < minDist || minDist == -1.0){
				minDist = distance;
				nn = k;
			}	
		}	

	}

	return nn;
	

}


//calcola i centroidi

int centroids(float* set, int n, int d, int m, int* ibridDeltaS, int* deltaS){

	float* averangePositions = alloc_matrix(m,d+1);
	averangePositionsCalculation(set,n,d,m,averangePositions); //trova le posizioni medie
	int i; //indice classe corrente
	int centroid_index;
	int dim = 0;
	
	
	for(i = 0; i<m; i++){ //scansiono tutte le classi
          centroid_index = nearestNeighborAverange(set,averangePositions,n,d,i);
		  activeBit(deltaS,(int) centroid_index); //attiva il bit che rappresenta il centroide
		  ibridDeltaS[dim] = centroid_index;
		  dim++;
	}
	

	return dim;

}



/*-----------------------------------------------------------------------------------*/


/*-------------------------------- METODI ACCESSORI ---------------------------------*/


//ritorna 1 se le classi di appartenenza sono uguali, 0 altrimenti

int sameClass(float* set, int i, int j, int d) {
	if(set[i*(d+1)+d] == set[j*(d+1)+d])
		return 1;
	else
		return 0;
}


//il metodo seguente calcola la distanza Euclidea e richiama la funzione assembly
// restituisce 0 se è minore il valore (k-z) calcolato, 1 se è maggione e 2 se sono uguali.

//i e j sono gli indici usati per calzolare il primo valore e, k e z sono usati per calcolare il secondo valore.


int euclideanDistance(DATASET T, int i, int j, int k, int z, int d){
  
	float distanceOne = 0;
    float distanceTwo = 0;	

	euclideanDistanceAssembly32_4(T, i, j, k, z, d,&distanceOne,&distanceTwo);
	


    // questo metodo riceve i,j,k,z.
    // questi valori sono tutti degli indici e calcoleremo la distanza fra loro.
    
    // prima di tutto calcoliamo la distanza fra i e j e fra k e z.
	
	distanceOne=sqrt(distanceOne);
	distanceTwo=sqrt(distanceTwo);
	
	if(distanceOne<distanceTwo){
    	return 1;
    }
	if(distanceOne==distanceTwo){
		return 2;
	}
    return 0;


}

//effettua l'euclideanDistance in maniera parallela richiamando una funzione assembly che svolge la seguente operazione.

//questo metodo riceve 5 parametri
//la i viene usata per calcolare la distanza attuale, le p vengono usate per calcolare le distanze di 4 nuovi parametri. 
//dopo aver calcolato la distanza di ognuno di questi, si fa il confronto tra loro e viene preso il valore più piccolo.

//questo metodo è chiamato Parallel perchè calcola 4 operazioni in maniera parallela, in poche parole sono le p.
//il parametro z rappresenta l'esempio attuale e d non è altro che la dimensione che viene usata per la scansione della 
//matrice.

//questo metodo restituisce 0 nel caso in cui non bisogna fare nulla, mentre restituisce un numero da 10 a 13 se il valore minimo è tra i parametri di p passati.

int euclideanDistanceParallel(DATASET T, int i, int p, int p2, int p3, int p4, int z, int d){

    int q;
	//distanza attuale nearest
    float distanceOne = 0;
	//distanza con p
    float distanceTwo = 0;
	//distanza con p2	
	float distanceThree = 0;
	//distanza con p3	
	float distanceFour = 0;
	//distanza con p4	
	float distanceFive = 0;
    
   	float minimo;
	int returnVal;

	euclideanDistanceAssemblyParallel32_4(T, i, p, p2, p3, p4, z, d, &distanceOne, &distanceTwo, &distanceThree, &distanceFour, &distanceFive);
	
	distanceOne=sqrt(distanceOne);
	distanceTwo=sqrt(distanceTwo);
	distanceThree=sqrt(distanceThree);
	distanceFour=sqrt(distanceFour);
	distanceFive=sqrt(distanceFive);
	
	minimo=distanceTwo;
	returnVal=10;
	if(minimo>distanceThree){
		minimo=distanceThree;
		returnVal=11;
	}
	if(minimo>distanceFour){
		minimo=distanceFour;
		returnVal=12;
	}
	if(minimo>distanceFive){
		minimo=distanceFive;
		returnVal=13;
	}
	if(minimo<distanceOne){
		return returnVal;
	}
	return 0;
}

//anche questo è chiamato parallel perchè riceve e calcola 4 operazioni in maniera parallela.

//questo metodo richiama i metodi euclideanDistance e euclideanDistanceParallel, questa operazione viene effettuata
//perchè nel caso il valore di nearest[q]=-1 (indefinito), gli viene assegnato il primo valore di p e poi vengono
//calcolati gli altri valori medi in maniera singola e non in maniera parallela.

// nel caso non vale -1 viene usato il metodo parallelo.

void controlNearestParallel(DATASET T,int n, int d, int m, int q, int p, int p2,int p3,int p4, int* nearest){

	int valore;
     
     // se nearest[q] vale -1 significa che � indefinito
     
	if(nearest[q]==-1){
		nearest[q]=p;
		if(euclideanDistance(T,nearest[q],q,p2,q,d)==0){
			nearest[q]=p2;
		}
		if(euclideanDistance(T,nearest[q],q,p3,q,d)==0){
			nearest[q]=p3;
		}
		if(euclideanDistance(T,nearest[q],q,p4,q,d)==0){
			nearest[q]=p4;
		}		
    }
    else{
		valore=euclideanDistanceParallel(T,nearest[q],p,p2,p3,p4,q,d);
		//sara 10 se devo modificare nearest[q] con p	
		if(valore==10){    	
			nearest[q]=p;                                                                                      
        }
		//sara 11 e devo modificare nearest[q] con p2 
		if(valore==11){
			nearest[q]=p2;
		}
		//sara 12 e devo modificare nearest[q] con p3 
		if(valore==12){
			nearest[q]=p3;
		}
		//sara 13 e devo modificare nearest[q] con p4 
		if(valore==13){
			nearest[q]=p4;
		}  
     }
     
}

//stesso metodo di sopra solo che non ha la possibilità di fare operazioni parallele.

//questi due metodi vengono richiamati per vedere se bisogna effettuare l'operazione nearest[q]=p


void controlNearest(DATASET T,int n, int d, int m, int q, int p, int* nearest){
     
     
     
     // se nearest[q] vale -1 significa che � indefinito
     
     if(nearest[q]==-1){
          nearest[q]=p;
     }
     else{
          if(euclideanDistance(T,nearest[q],q,p,q,d)==0){
               nearest[q]=p;                                                                                      
          }
     }
     
}

//valuta la condizione se bisogna inserire il valore a rep[nearest[q]]

void controlRep(DATASET T, int n, int d, int m, int q, int* nearest, int* rep){

     //se nearest[q] vale -1 non esiste rep[-1] quindi non faccio nulla
     
     // nearestQ conterr� il valore nearest[q], faccio questo perch� uso molto
     // spesso il valore di nearestQ in questo metodo.
     
     
     
     int nearestQ=nearest[q];
     if(nearestQ!=-1){	
          if(sameClass(T,q,nearestQ,d)==0){
               if(rep[nearestQ]==-1){
                    rep[nearestQ]=q; 
               }
               else{
                    if(euclideanDistance(T,nearestQ,q,nearestQ,rep[nearestQ],d)==1){
                         rep[nearestQ]=q;
                    }
               }
          }
     }
     

}

/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 * 
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola 
 * 
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {	
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");
	
	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}
	
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);
	
	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;
	
	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {	
	FILE* fp;
	int i;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);
	
	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*cols], sizeof(float), cols, fp);
	fclose(fp);
}


//extern void fcnn32(DATASET t, int n, int d, int m, SUBSETID Sid, int* Sn);

/*
 *	fcnn
 * 	====
 * 
 *	T contiene il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
 * 	in un array lineare in row-major order
 * 
 *	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
 * 	del training set.
 * 
 * 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
 * 	al sottoinsieme S ed in Sn il numero di oggetti in S.
 * 	Si assume che gli identificatori partono da 0.
 * 
 */
SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
	SUBSETID Sid = calloc(sizeof(int),n);			//sottoinsieme S contenente indici da restituire a fine programma 
  
    int* nearest = calloc(sizeof(int),n);			//array dei vicini
	
	int* rep= calloc(sizeof(int),n); 				//array dei nemici
    
    int* S = calloc(sizeof(int),(n/32)+1); 		//BITARRAY S
    	
    int* deltaS = calloc(sizeof(int),(n/32)+1); 	//BITARRAY deltaS (inizialmente contenente i centroidi)
    
    int* ibridDeltaS = calloc(sizeof(int),(4*m));	//"NORMAL ARRAY" deltaS
    
    int* ibridS = calloc(sizeof(int),(4*m));		//"NORMAL ARRAY" S
    int dimDeltaS = centroids(T,n,d,m,ibridDeltaS,deltaS);  
    int dimS = 0;   
    int q,p;
	int i;	
    
    /* VARIABILI AUSILIARIE */
    int ibridIteration=0;
    int temp;

	//usati nel parallelismo per il calcolo dell'euclideanDistance 
	int pAttuale1;
	int pAttuale2;
	int pAttuale3;
	
	//usati per parallelizare il calcolo di T-S,
	int qAttuale1;
	int qAttuale2;
	int qAttuale3;
    
    //azzero gli array per evitare che contengano valori spuri
    	    
    clearArray(nearest,rep,n);    
    clearBitarray(S,(n/32+1));
    
    /* CICLO "NORMAL ARRAY" */

    while(ibridIteration < 3 && dimDeltaS!=0){ 
				
		//unione di S e DeltaS
		
        unionBitarray(deltaS,S,(n/32)+1);		
		
        dimS= unionIbridarray(ibridDeltaS,ibridS,dimDeltaS,dimS);
         
         
        //rep = undefined
         
        undefineArrayIbrid(ibridS,dimS,rep);  
        
        //for (q appartenente a T-S), cioè non appartiene a S
        
		//svolgo in parallelo 4 q e per ogni q calcolo in parallelo 4 p

		//la tecnica usata: siccome i valori di q possono non essere consecutivi, cerco prima 4 valore di q e dopo 
		//averli trovati richiama controlNearest 4 volte e ognuna di questa chiamata viene effettuata con 4 valori di p

		qAttuale1=-1;
		qAttuale2=-1;
		qAttuale3=-1;

        for (q = 0; q<n; q++){
       
         	if(getValue(S,q) == 0 ){
         		if(qAttuale1!=-1){
					if(qAttuale2!=-1){
						if(qAttuale3!=-1){
							for(p=0;dimDeltaS-p>3;p=p+4){
								controlNearestParallel(T, n, d, m, qAttuale1, ibridDeltaS[p],ibridDeltaS[p+1],ibridDeltaS[p+2],ibridDeltaS[p+3], nearest);
								controlNearestParallel(T, n, d, m, qAttuale2, ibridDeltaS[p],ibridDeltaS[p+1],ibridDeltaS[p+2],ibridDeltaS[p+3], nearest);
								controlNearestParallel(T, n, d, m, qAttuale3, ibridDeltaS[p],ibridDeltaS[p+1],ibridDeltaS[p+2],ibridDeltaS[p+3], nearest);
								controlNearestParallel(T, n, d, m, q, ibridDeltaS[p],ibridDeltaS[p+1],ibridDeltaS[p+2],ibridDeltaS[p+3], nearest);
								
							}
							while(p<dimDeltaS){

								controlNearest(T, n, d, m, qAttuale1, ibridDeltaS[p], nearest);
								controlNearest(T, n, d, m, qAttuale2, ibridDeltaS[p], nearest);
								controlNearest(T, n, d, m, qAttuale3, ibridDeltaS[p], nearest);
								controlNearest(T, n, d, m, q, ibridDeltaS[p], nearest);				
								p++;
							}
							
							controlRep(T, n, d, m, qAttuale1, nearest, rep);
							controlRep(T, n, d, m, qAttuale2, nearest, rep);
							controlRep(T, n, d, m, qAttuale3, nearest, rep);
							controlRep(T, n, d, m, q, nearest, rep);
								
							qAttuale1=-1;
							qAttuale2=-1;
							qAttuale3=-1;
         				}
						else{
							qAttuale3=q;
						}
					}
					else{
						qAttuale2=q;
					}
				}
				else{
					qAttuale1=q;
				}
			}
         	
        }

		//i calcoli seguenti vengono effettuati se non ci sono 4 q e quindi non si può usare la tecnica di parallelizzazione.

        if(qAttuale1!=-1){ 		
			for(p=0;dimDeltaS-p>3;p=p+4){
					
				controlNearestParallel(T, n, d, m, qAttuale1, ibridDeltaS[p],ibridDeltaS[p+1],ibridDeltaS[p+2],ibridDeltaS[p+3], nearest);

			}
			while(p<dimDeltaS){

				controlNearest(T, n, d, m, qAttuale1, ibridDeltaS[p], nearest);				
				p++;
			}
				
			controlRep(T, n, d, m, qAttuale1, nearest, rep);
				
         					
		}
        if(qAttuale2!=-1){ 		
			for(p=0;dimDeltaS-p>3;p=p+4){
					
				controlNearestParallel(T, n, d, m, qAttuale2, ibridDeltaS[p],ibridDeltaS[p+1],ibridDeltaS[p+2],ibridDeltaS[p+3], nearest);

			}
			while(p<dimDeltaS){

				controlNearest(T, n, d, m, qAttuale2, ibridDeltaS[p], nearest);				
				p++;
			}
				
			controlRep(T, n, d, m, qAttuale2, nearest, rep);
				
         					
		}	
		
        if(qAttuale3!=-1){ 		
			for(p=0;dimDeltaS-p>3;p=p+4){
					
				controlNearestParallel(T, n, d, m, qAttuale3, ibridDeltaS[p],ibridDeltaS[p+1],ibridDeltaS[p+2],ibridDeltaS[p+3], nearest);

			}
			while(p<dimDeltaS){

				controlNearest(T, n, d, m, qAttuale3, ibridDeltaS[p], nearest);				
				p++;
			}
				
			controlRep(T, n, d, m, qAttuale3, nearest, rep);
				
   				
		}	
			
		
		// DeltaS = 0
		
		dimDeltaS = 0;
		clearBitarray(deltaS,(n/32)+1);
		
		for(p=0;p<dimS;p++){
			temp=rep[ibridS[p]];
			if(temp!=-1){
				ibridDeltaS[dimDeltaS]=temp;
				dimDeltaS++;
				activeBit(deltaS,temp);
				
			}
		}

        ibridIteration++;
    }
    
	
	/* CICLO BITARRAY */
	
	//da qui in poi dimDeltaS la usiamo come una booleana, cioè vale zero se DeltaS non ha più elementi.
	
	while(dimDeltaS!=0){
	
		ibridIteration++; //da eliminare, variabile solo per controllo
		
		//unione di S e DeltaS
		
		
		
		unionBitarray(deltaS,S,(n/32)+1);
	
		
		//rep = undefined
		
		//viene usata la stessa tecnica che è presente nell'ibrido con qualche leggera differenza (ciccio)

		undefineArray(S,n,rep);
		pAttuale1=-1;
		pAttuale2=-1;
		pAttuale3=-1;
		
		qAttuale1=-1;
		qAttuale2=-1;
		qAttuale3=-1;		
	
		for (q = 0; q < n; q++){
         	if(getValue(S,q) == 0){
				if(qAttuale1!=-1){
					if(qAttuale2!=-1){
						if(qAttuale3!=-1){
							for(p = 0;p<n;p++){
								if(getValue(deltaS,p)==1){

									if(pAttuale1!=-1){
										if(pAttuale2!=-1){
											if(pAttuale3!=-1){
												controlNearestParallel(T, n, d, m, qAttuale1, pAttuale1, pAttuale2, pAttuale3, p, nearest);
												controlNearestParallel(T, n, d, m, qAttuale2, pAttuale1, pAttuale2, pAttuale3, p, nearest);
												controlNearestParallel(T, n, d, m, qAttuale3, pAttuale1, pAttuale2, pAttuale3, p, nearest);
												controlNearestParallel(T, n, d, m, q, pAttuale1, pAttuale2, pAttuale3, p, nearest);
												pAttuale1=-1;
												pAttuale2=-1;
												pAttuale3=-1;
											}
											else{
												pAttuale3=p;
											}
										}
										else{
											pAttuale2=p;
										}
									}
									else{
										pAttuale1=p;
									}
					
								}
							}
							if(pAttuale1!=-1){
								controlNearest(T, n, d, m, qAttuale1, pAttuale1, nearest);
								controlNearest(T, n, d, m, qAttuale2, pAttuale1, nearest);
								controlNearest(T, n, d, m, qAttuale3, pAttuale1, nearest);
								controlNearest(T, n, d, m, q, pAttuale1, nearest);
								pAttuale1=-1;
							}
							if(pAttuale2!=-1){
								controlNearest(T, n, d, m, qAttuale1, pAttuale2, nearest);
								controlNearest(T, n, d, m, qAttuale2, pAttuale2, nearest);
								controlNearest(T, n, d, m, qAttuale3, pAttuale2, nearest);
								controlNearest(T, n, d, m, q, pAttuale2, nearest);
								pAttuale2=-1;
							}
							if(pAttuale3!=-1){
								controlNearest(T, n, d, m, qAttuale1, pAttuale3, nearest);
								controlNearest(T, n, d, m, qAttuale2, pAttuale3, nearest);
								controlNearest(T, n, d, m, qAttuale3, pAttuale3, nearest);
								controlNearest(T, n, d, m, q, pAttuale3, nearest);
								pAttuale3=-1;
							}
				
							controlRep(T, n, d, m, qAttuale1, nearest, rep);
							controlRep(T, n, d, m, qAttuale2, nearest, rep);
							controlRep(T, n, d, m, qAttuale3, nearest, rep);
							controlRep(T, n, d, m, q, nearest, rep);
				
							qAttuale1=-1;
							qAttuale2=-1;
							qAttuale3=-1;
						}
						else{
							qAttuale3=q;		
						}
					}
					else{
						qAttuale2=q;
					}
				}
				else{
					qAttuale1=q;
				}
			}
		}

        if(qAttuale1!=-1){ 		
			for(p = 0;p<n;p++){
				if(getValue(deltaS,p)==1){

					if(pAttuale1!=-1){
						if(pAttuale2!=-1){
							if(pAttuale3!=-1){
								controlNearestParallel(T, n, d, m, qAttuale1, pAttuale1, pAttuale2, pAttuale3, p, nearest);
								
								pAttuale1=-1;
								pAttuale2=-1;
								pAttuale3=-1;
							}
							else{
								pAttuale3=p;
							}
						}
						else{
							pAttuale2=p;
						}
					}
					else{
						pAttuale1=p;
					}
					
				}
			}
			if(pAttuale1!=-1){
				controlNearest(T, n, d, m, qAttuale1, pAttuale1, nearest);
				pAttuale1=-1;
			}
			if(pAttuale2!=-1){
				controlNearest(T, n, d, m, qAttuale1, pAttuale2, nearest);
				pAttuale2=-1;
			}
			if(pAttuale3!=-1){
				controlNearest(T, n, d, m, qAttuale1, pAttuale3, nearest);
				pAttuale3=-1;
			}
		
			controlRep(T, n, d, m, qAttuale1, nearest, rep);
				
			qAttuale1=-1;	
         					
		}

        if(qAttuale2!=-1){ 		
			for(p = 0;p<n;p++){
				if(getValue(deltaS,p)==1){

					if(pAttuale1!=-1){
						if(pAttuale2!=-1){
							if(pAttuale3!=-1){
								controlNearestParallel(T, n, d, m, qAttuale2, pAttuale1, pAttuale2, pAttuale3, p, nearest);
								
								pAttuale1=-1;
								pAttuale2=-1;
								pAttuale3=-1;
							}
							else{
								pAttuale3=p;
							}
						}
						else{
							pAttuale2=p;
						}
					}
					else{
						pAttuale1=p;
					}
					
				}
			}
			if(pAttuale1!=-1){
				controlNearest(T, n, d, m, qAttuale2, pAttuale1, nearest);
				pAttuale1=-1;
			}
			if(pAttuale2!=-1){
				controlNearest(T, n, d, m, qAttuale2, pAttuale2, nearest);
				pAttuale2=-1;
			}
			if(pAttuale3!=-1){
				controlNearest(T, n, d, m, qAttuale2, pAttuale3, nearest);
				pAttuale3=-1;
			}
		
			controlRep(T, n, d, m, qAttuale2, nearest, rep);
				
			qAttuale2=-1;	
         					
		}

        if(qAttuale3!=-1){ 		
			for(p = 0;p<n;p++){
				if(getValue(deltaS,p)==1){

					if(pAttuale1!=-1){
						if(pAttuale2!=-1){
							if(pAttuale3!=-1){
								controlNearestParallel(T, n, d, m, qAttuale3, pAttuale1, pAttuale2, pAttuale3, p, nearest);
								
								pAttuale1=-1;
								pAttuale2=-1;
								pAttuale3=-1;
							}
							else{
								pAttuale3=p;
							}
						}
						else{
							pAttuale2=p;
						}
					}
					else{
						pAttuale1=p;
					}
					
				}
			}
			if(pAttuale1!=-1){
				controlNearest(T, n, d, m, qAttuale3, pAttuale1, nearest);
				pAttuale1=-1;
			}
			if(pAttuale2!=-1){
				controlNearest(T, n, d, m, qAttuale3, pAttuale2, nearest);
				pAttuale2=-1;
			}
			if(pAttuale3!=-1){
				controlNearest(T, n, d, m, qAttuale3, pAttuale3, nearest);
				pAttuale3=-1;
			}
		
			controlRep(T, n, d, m, qAttuale3, nearest, rep);
				
			qAttuale3=-1;	
         					
		}
		
		// DeltaS = 0
		dimDeltaS = 0;
		clearBitarray(deltaS,(n/32)+1);

		
		for(p=0;p<n;p++){
			if(getValue(S,p)==1){
				temp=rep[p];
				if(temp!=-1){
					activeBit(deltaS,temp);
					dimDeltaS=1;
				}
			}
		}
		

	} 
	
	/* FINE CICLO*/
    
    //carico il bitarray S sul array Sid
    
    p = 0; //p diventa indice per aggiungere gli elementi in Sid, così da evitare il bisogno di creare una nuova variabile

    for (i = 0; i < n; i++){
    	if(getValue(S,i) == 1){
    		Sid[p] = i;
    		p++;
    		++*Sn;
    		
    	}    		
    }   
    
    
    /* STAMPE DI CONTROLLO */
    
    printf("\nNUMERO CLASSI: %d\n",m);
    printf("\nNUMERO ESEMPI: %d\n",n);
    printf("\nELEMENTI TROVATI: %d\n",*Sn);
    printf("\n#IBRID ITERATION: %d \n",ibridIteration); 
   	
   	return Sid;
}


int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);
	
	clock_t t = clock();
	int Sn = 0;

	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);

	return 0;
}
