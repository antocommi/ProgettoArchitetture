/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 18 aprile 2014
 * 
 ****************************************************************************/

/*
 
 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software 
 installabili mediante il packaging tool del sistema 
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 fcnn64.nasm && gcc -O0 -m64 -mavx fcnn64.o fcnn64c.c -o fcnn64c && ./fcnn64c
 
 oppure
 
 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>


/*
 * 
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate 
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere 
 * 	memorizzate mediante array di array (float**).
 * 
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 * 
 */

#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*

#define POINT           float*
#define UNDEFINED       -1


extern void init64_5(int *v, int n);
void centroids(DATASET T, int n, int d, int m,  int *deltaSid, int *deltaSn);
void step1(DATASET T, int n, int d, int m, float *centr, int *pointsPerClass, float *nn, int *nnID);
extern void incrPPC64_5(int *ppc, int d, int label);
extern void sumCentroids64_5(DATASET T, float *centr, int pointID, int d, int label);
extern void divideCentroids64_5(float *centr, int *pointsPerClass, int k);
void step2(DATASET T, int n, int d, POINT virtualCentroid, POINT currentCentroid, POINT candidateCentroid, float *centr, float *nn, int *nnID);
extern void fill64_5(float *v1, int off1,  float *v2, int off2, int k);
extern void add64_5(SUBSETID Sid, int *Sn, SUBSETID deltaSid, int deltaSn);
extern void initRep64_5(SUBSETID Sid, int *Sn, int *rep);
void update(MATRIX T, int n, int d, SUBSETID Sid, int *Sn, SUBSETID deltaSid, int deltaSn, int *nearest, int *rep, POINT p1, POINT p2, POINT p3);
int search(SUBSETID Sid, int *Sn, int pointID);
void updateNearest(DATASET T, int d, SUBSETID deltaSid, int deltaSn, int *nearest, int q, POINT p1, POINT p2, POINT p3);
void updateRep(DATASET T, int d, int *nearest, int *rep, int q, POINT p1, POINT p2, POINT p3);
extern void extract64_5(DATASET T, int d, int pointID, float *p);
extern void dist64_5(float *p, float *q, int d, float *retVal);
void addEnemies(SUBSETID Sid, int *Sn, SUBSETID deltaSid, int *deltaSn, int *rep);


void* get_block(int size, int elements) { 
	return _mm_malloc(elements*size,32); 
}


void free_block(void* p) { 
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


/*
 * 
 * 	load_input
 * 	===========
 * 
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 * 
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola 
 * 
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {	
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");
	
	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}
	
	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);
	
	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;
	
	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {	
	FILE* fp;
	int i;
	
	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);
	
	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*cols], sizeof(float), cols, fp);
	fclose(fp);
}

/*
 *	fcnn
 * 	====
 * 
 *	T contiene il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
 * 	in un array lineare in row-major order
 * 
 *	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
 * 	del training set.
 * 
 * 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
 * 	al sottoinsieme S ed in Sn il numero di oggetti in S.
 * 	Si assume che gli identificatori partono da 0.
 * 
 */
SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
  SUBSETID Sid = (int *) get_block(sizeof(int), n);  // (int*)

  int *deltaSid = get_block(sizeof(int), n);  // (int*)
  int deltaSn = 0;
  
  int *nearest = get_block(sizeof(int), n);
  int *rep = get_block(sizeof(int), n);
  
  init64_5(nearest, n);
  init64_5(rep, n);

  centroids(T, n, d, m, deltaSid, &deltaSn);

  POINT p1 = (POINT) get_block(sizeof(float), d);  // (float*)
  POINT p2 = (POINT) get_block(sizeof(float), d);  // (float*)
  POINT p3 = (POINT) get_block(sizeof(float), d);  // (float*)

  while (deltaSn != 0) {
    add64_5(Sid, Sn, deltaSid, deltaSn);
    initRep64_5(Sid, Sn, rep);
    update(T, n, d, Sid, Sn, deltaSid, deltaSn, nearest, rep, p1, p2, p3);
    addEnemies(Sid, Sn, deltaSid, &deltaSn, rep);
  }

  free_block(p3);
  free_block(p2);
  free_block(p1);
  free_block(rep);
  free_block(nearest);
  free_block(deltaSid);

  return Sid;
}

//void init64_5(int *v, int n) {
//  int i;
//  for (i = 0; i < n; i++) {
//    v[i] = UNDEFINED;
//  }
//}

void centroids(DATASET T, int n, int d, int m,  SUBSETID deltaSid, int *deltaSn) {
  float *centr = (float *) get_block(sizeof(float), m * d);
  int *pointsPerClass = (int *) get_block(sizeof(int), m * d);
  float *nn = calloc(sizeof(float), m * d);
  int *nnID = get_block(sizeof(int), m);

  init64_5(nnID, m);

  // step 1. calculate virtual centroids
  step1(T, n, d, m, centr, pointsPerClass, nn, nnID);

  // step 2. calculate actual centroids
  POINT virtualCentroid = (POINT) get_block(sizeof(float), d);
  POINT currentCentroid = (POINT) get_block(sizeof(float), d);
  POINT candidateCentroid = (POINT) get_block(sizeof(float), d);

  step2(T, n, d, virtualCentroid, currentCentroid, candidateCentroid, centr, nn, nnID);

  // step 3. add centroids to deltaSid
  add64_5(deltaSid, deltaSn, nnID, m);

  free_block(candidateCentroid);
  free_block(currentCentroid);
  free_block(virtualCentroid);

  free_block(nnID);
  free(nn);
  free_block(pointsPerClass);
  free_block(centr);
}

void step1(DATASET T, int n, int d, int m, float *centr, int *pointsPerClass, float *nn, int *nnID) {
  // step 1. calculate virtual centroids
  int i;
  for (i = 0; i < n; i++) {
    int label = T[i * (d + 1) + d];
    incrPPC64_5(pointsPerClass, d, label);

    if (nnID[label] == UNDEFINED) {
      fill64_5(nn, label * d, T, i * (d + 1), d);
      nnID[label] = i;
    }

    sumCentroids64_5(T, centr, i, d, label);
  }
  divideCentroids64_5(centr, pointsPerClass, m * d);
}

//void incrPPC64_5(int *ppc, int d, int label) {
//  int j;
//  for (j = 0; j < d; j++) {
//    ppc[(label * d) + j]++;
//  }
//}

//void sumCentroids64_5(DATASET T, float *centr, int pointID, int d, int label) {
//  int j;
//  for (j = 0; j < d; j++) {
//    centr[label * d + j] += T[pointID * (d + 1) + j];
//  }
//}

//void divideCentroids64_5(float *centr, int *pointsPerClass, int k) {
//  int j;
//  for (j = 0; j < k; j++) {
//    centr[j] /= pointsPerClass[j];
//  }
//}

void step2(DATASET T, int n, int d, POINT virtualCentroid, POINT currentCentroid, POINT candidateCentroid, float *centr, float *nn, int *nnID) {
  int lastLabel = -1;
  int i, j;
  for (i = 0; i < n; i++) {
    int label = T[i * (d + 1) + d];
    
    extract64_5(T, d, i, candidateCentroid);
    if (label != lastLabel){
      fill64_5(virtualCentroid, 0, centr, label * d, d);
      fill64_5(currentCentroid, 0, nn, label * d, d);
    }

    float distCurrVirtual = 0.0;
    dist64_5(currentCentroid, virtualCentroid, d, &distCurrVirtual);
    float distCandVirtual = 0.0;
    dist64_5(candidateCentroid, virtualCentroid, d, &distCandVirtual);
    if (distCandVirtual < distCurrVirtual) {
      fill64_5(nn, label * d, candidateCentroid, 0, d);
      nnID[label] = i;
    }
  }
}

//void fill64_5(float *v1, int off1, float *v2, int off2, int k) {
//  int j = 0;
//  for (j = 0; j < k; j++) {
//    v1[off1 + j] = v2[off2 + j];
//  }
//}

//void add64_5(SUBSETID Sid, int *Sn, SUBSETID deltaSid, int deltaSn) {
//  int i;
//  for (i = 0; i < deltaSn; i++) {
//    Sid[*Sn] = deltaSid[i];
//    (*Sn)++;
//  }
//}

//void initRep64_5(SUBSETID Sid, int *Sn, int *rep) {
//  int i, p;
//  for (i = 0; i < *Sn; i++) {
//    p = Sid[i];
//    rep[p] = -1;
//  }
//}

void update(MATRIX T, int n, int d, SUBSETID Sid, int *Sn, SUBSETID deltaSid, int deltaSn, int *nearest, int *rep, POINT p1, POINT p2, POINT p3) {
  int q;
  for (q = 0; q < n; q++) {
    int qInTS = search(Sid, Sn, q);
    
    if (qInTS) {
      updateNearest(T, d, deltaSid, deltaSn, nearest, q, p1, p2, p3);
      updateRep(T, d, nearest, rep, q, p1, p2, p3);
    }
  }
}

int search(SUBSETID Sid, int *Sn, int pointID) {
  int j, qInTS = 1;
  for (j = 0; (j < *Sn) && (qInTS); j++) {
    if (Sid[j] == pointID) {
      qInTS = 0;
    }
  }
  return qInTS;
}

void updateNearest(DATASET T, int d, SUBSETID deltaSid, int deltaSn, int *nearest, int q, POINT p1, POINT p2, POINT p3) {
  int j, p;
  for (j = 0; j < deltaSn; j++) {
    p = deltaSid[j];
    if (nearest[q] == UNDEFINED) {
      nearest[q] = p;
    }
    int nearQ = nearest[q];
    
    extract64_5(T, d, nearQ, p1);
    extract64_5(T, d, q, p2);
    extract64_5(T, d, p, p3);
    
    float dist1 = 0.0;
    dist64_5(p1, p2, d, &dist1);  // nearQ, Q
    float dist2 = 0.0;
    dist64_5(p3, p2, d, &dist2);  // P, Q
   if (dist1 > dist2) {
      nearest[q] = p;
   }
  }
}

void updateRep(DATASET T, int d, int *nearest, int *rep, int q, POINT p1, POINT p2, POINT p3) {
  int nearQ = nearest[q];
  int repNearQ = rep[nearQ];
  
  int labelQ = T[q * (d + 1) + d];
  int labelNearQ = T[nearQ * (d + 1) + d];
  int cond1 = (labelQ != labelNearQ);

  if (repNearQ == UNDEFINED) {
    if (cond1) {
      rep[nearQ] = q;
    }
  } else {
    extract64_5(T, d, nearQ, p1);
    extract64_5(T, d, q, p2);
    extract64_5(T, d, repNearQ, p3);
    
    float dist1 = 0.0;
    dist64_5(p1, p2, d, &dist1);
    float dist2 = 0.0;
    dist64_5(p1, p3, d, &dist2);
    int cond2 = (dist1 < dist2);
    if (cond1 && cond2) {
      rep[nearQ] = q;
    }
  }
}

//void extract64_5(DATASET T, int d, int pointID, float *p) {
//  int i = (d + 1) * pointID;
//  int j;
//  for (j = 0; j < d; j++) {
//    p[j] = T[i + j];
//  }
//}

//void dist64_5(float *p, float *q, int d, float *retVal) {
//  float sum = 0;
//  int i;
//  for (i = 0; i < d; i++) {
//    sum += ((p[i] - q[i]) * (p[i] - q[i]));
//  }
//  (*retVal) = sqrt(sum);
//}

void addEnemies(SUBSETID Sid, int *Sn, SUBSETID deltaSid, int *deltaSn, int *rep) {
  *deltaSn = 0;
  int i, p;
  for (i = 0; i < *Sn; i++) {
    p = Sid[i];
    if (rep[p] != UNDEFINED) {
      deltaSid[*deltaSn] = rep[p];
      (*deltaSn)++;
    }
  }
}

int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);
	
	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);

	return 0;
}
