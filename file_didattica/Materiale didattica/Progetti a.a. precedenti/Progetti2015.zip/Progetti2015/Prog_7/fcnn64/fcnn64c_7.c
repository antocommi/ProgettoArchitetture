/****************************************************************************
 * 
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 * 
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 * 
 * Fabrizio Angiulli, 18 aprile 2015
 * 
 ****************************************************************************/
#include "prof64.h"
#include "funzioni64.h"

SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
	/* Memorizzare il vicino[q] e nemico[ vicino[q] ] */
	int* vicino = (int*)_mm_malloc(n*sizeof(int), 32);
	int* nemico = (int*)_mm_malloc(n*sizeof(int), 32);
	
	/* Memorizzare le distanze calcolate tra vicino[q] e q */
	float* distanzaVicino = (float*) _mm_malloc(n*sizeof(float), 32);
	float* distanzaNemico = (float*) _mm_malloc(n*sizeof(float), 32);
	
	/* Strutture utilizzate per l'algoritmo fcnn */
	SUBSETID Sid = (SUBSETID) _mm_malloc(n*sizeof(int), 32);
	 SUBSETID id = (SUBSETID) _mm_malloc(n*sizeof(int), 32);
	
	//- Fornisce gli inidice più vicini al Centroide C - Codice Nasm
	SUBSETID dS = (SUBSETID) _mm_malloc(n*sizeof(int), 32);
	calcolaCentroide(T, n, m, d, dS);  int dimDS = m;
	
	/* Inizializza gli array */
	mm_init_null64(vicino, n);//- Inizializza a -1 - Codice Nasm
	mm_init_null64(nemico, n);//- Inizializza a -1 - Codice Nasm
	    mm_init_zero64(id, n);//- Inizializza a  0 - Codice Nasm
    
   	while( dimDS > 0 ){
   	
   		/* Determina l'insieme Unione tra S e DS, restituendo il numero di elementi presenti in S */
	    	unione(Sid, Sn, dS, dimDS, id);//- Codice C [UNROLL]
	    	
	    	int q = 0;
	    	for(; q < n; q++){
	    	
	    		/* Chiedi ad id se il punto Q non appartiene ad S */
	    		if(!id[q]){
	    			/* Punto Q prelevato da S-T */
	    			float* Q = T+q*(d+1);
	    			int p = 0; 
	    			
	    			/* Verifico che sia definito un vicino di Q */
				if(vicino[q] == -1){ p = 1; vicino[q] = dS[0]; }
					
	    			/* Calcolo la distanza tra il vicino[q] e q */	
				int indiceVicinoQ = vicino[q];
				float distanzaVicinoQ =  distanza64(T+indiceVicinoQ*(d+1), Q, d);//- Codice Nasm
				
				
				for(; p < dimDS-3; p+=4){ /* UNROLLING */
					int indice1 = dS[p], indice2 = dS[p+1], indice3 = dS[p+2], indice4 = dS[p+3];
					float* dSP1 = T+indice1*(d+1);
					float* dSP2 = T+indice2*(d+1);
					float* dSP3 = T+indice3*(d+1);
					float* dSP4 = T+indice4*(d+1);
					
					/* Calcolo la distanza tra il p e q */	
					 float distanzaPQ = distanza64(dSP1, Q, d);//- Codice Nasm
					float distanzaPQ1 = distanza64(dSP2, Q, d);//- Codice Nasm
					float distanzaPQ2 = distanza64(dSP3, Q, d);//- Codice Nasm
					float distanzaPQ3 = distanza64(dSP4, Q, d);//- Codice Nasm
					
					/* Verifico se il punto più vicino a Q il vicino[q] o */
					if(distanzaVicinoQ >  distanzaPQ){
					
						/* Aggiorna il vicino di Q e ricorda la distanza che hai calcolato */
						indiceVicinoQ = indice1;
						distanzaVicinoQ = distanzaPQ;
					}
					if(distanzaVicinoQ >  distanzaPQ1){
					
						/* Aggiorna il vicino di Q e ricorda la distanza che hai calcolato */
						indiceVicinoQ = indice2;
						distanzaVicinoQ = distanzaPQ1;
					}
					if(distanzaVicinoQ >  distanzaPQ2){
					
						/* Aggiorna il vicino di Q e ricorda la distanza che hai calcolato */
						indiceVicinoQ = indice3;
						distanzaVicinoQ = distanzaPQ2;
					}
					if(distanzaVicinoQ >  distanzaPQ3){
					
						/* Aggiorna il vicino di Q e ricorda la distanza che hai calcolato */
						indiceVicinoQ = indice4;
						distanzaVicinoQ = distanzaPQ3;
					}
				}//for
				for(; p < dimDS; p++){
				
					int indice = dS[p];
					float* dSP = T+indice*(d+1);
					
					/* Calcolo la distanza tra il p e q */	
					float distanzaPQ = distanza64(dSP, Q, d);//- Codice Nasm
					
					/* Verifico se il punto più vicino a Q il vicino[q] o */
					if(distanzaVicinoQ >  distanzaPQ){
					
						/* Aggiorna il vicino di Q e ricorda la distanza che hai calcolato */
						indiceVicinoQ = indice;
						distanzaVicinoQ = distanzaPQ;
					}
				}//for
				
				distanzaVicino[indiceVicinoQ] = distanzaVicinoQ;
				vicino[q] = indiceVicinoQ;
				
				/* Iterazione su DS ultimata. Verifico che il vicino di Q sia un amico o un nemico */
				
				/* Verifico l'etichetta di Q e del suo vicino */
				if(Q[d] != (T+indiceVicinoQ*(d+1))[d]){
					/* Il vicino di Q è un nemico perchè etichetta diversa da quella di Q */

					/* E' la prima volta che trovo questo nemico? */
					if(nemico[indiceVicinoQ] == -1){
						nemico[indiceVicinoQ] = q;
						distanzaNemico[indiceVicinoQ] = distanza64(
							T+indiceVicinoQ*(d+1), T+nemico[indiceVicinoQ]*(d+1) , d);
					}else{
						
						if(distanzaVicinoQ < distanzaNemico[indiceVicinoQ]){
								nemico[indiceVicinoQ] = q; 
								distanzaNemico[indiceVicinoQ] = distanza64(
							T+indiceVicinoQ*(d+1), T+nemico[indiceVicinoQ]*(d+1) , d);
						}
					}//if-else
				}//if
	    		}//if
	    	}//for
	    	
	    	/* Popola DS in base al numero dei nemici che sono stati trovati */
	    	dimDS = popolaDS(Sid, Sn, dS, nemico); //- Codice C
     }//while
     
    /* Libera memoria utilizzata */ 
    _mm_free(distanzaVicino); _mm_free(nemico); _mm_free(id); _mm_free(vicino); 
    
    return Sid;
}//fcnn64

int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi
	
	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}
	
	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}
	
	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}	
	
	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);
	
	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);
		
	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);

	return 0;
}
