#ifndef __FUNZIONI_64_H__
#define __FUNZIONI_64_H__

#include "prof64.h"
/* Funzione in NASM implementate x86-64 + AVX *******************************/
	/* Calcola della Distanza Euclidea */
	extern float distanza64(float*, float*, int);
	
	/* Funzioni di Utilità per per calcolare il Centroide C */
	extern  void somma64(float*, DATASET, int, int, float*);
	extern  void media64(float*, int, int, float*);
	
	/* Inizializza memoria allocata */
	extern  void mm_init_null64(void*, int);
	extern  void mm_init_zero64(void*, int);
	
/****************************************************************************/

/* Prototipo di Funzioni implementate in C *******************************/
	void	unione(SUBSETID, int*, SUBSETID, int, SUBSETID);
	int 	popolaDS(SUBSETID, int*, SUBSETID, int*);
	void 	calcolaCentroide(DATASET, int, int, int, SUBSETID);
	int 	nearCentroide(DATASET, int, float*, int, int, int);
/****************************************************************************/

void unione(SUBSETID Sid, int* Sn, SUBSETID dS, int dimDS, SUBSETID id){
	int i = 0;
	
	for(i = 0; i < dimDS-3; i += 4, *Sn += 4){
		int indice1 = dS[i], indice2 = dS[i+1], indice3 = dS[i+2], indice4 = dS[i+3];
		
		    id[ indice1 ] = 1;    Sid[*Sn] = indice1; 
		  id[ indice2 ] = 1; 	Sid[*Sn+1] = indice2; 
		  id[ indice3 ] = 1;	Sid[*Sn+2] = indice3;
		  id[ indice4 ] = 1; 	Sid[*Sn+3] = indice4;
	}//for
	
	for( ; i < dimDS; i++, (*Sn)++){ 
		int indice = dS[i];
		id[ indice ] = 1; Sid[*Sn] = indice; 
	}
}//unione

int popolaDS(SUBSETID Sid, int* Sn, SUBSETID dS, int* rep){
	int dimDS = 0, p = 0;
	
	for(; p < *Sn-3; p+=4){
		int indice1 = Sid[p], indice2 = Sid[p+1], indice3 = Sid[p+2], indice4 = Sid[p+3];
		
		if(rep[indice1] != -1){ dS[dimDS] = rep[indice1]; dimDS++; rep[indice1] = -1; }
		if(rep[indice2] != -1){ dS[dimDS] = rep[indice2]; dimDS++; rep[indice2] = -1; }
		if(rep[indice3] != -1){ dS[dimDS] = rep[indice3]; dimDS++; rep[indice3] = -1; }
		if(rep[indice4] != -1){ dS[dimDS] = rep[indice4]; dimDS++; rep[indice4] = -1; }
	}
	for(; p < *Sn; p++){
		int indice = Sid[p];
		if(rep[indice] != -1){ dS[dimDS] = rep[indice]; dimDS++; rep[indice] = -1; }
	}
		
	return dimDS;
}

void calcolaCentroide(DATASET T, int n, int m, int d, SUBSETID dS){
 	float* C = (float*)_mm_malloc((m*d)*sizeof(float), 32);
 	mm_init_zero64(C, (m*d));//- nasm
 	
	int i = 0;
 	float* v = (float*)_mm_malloc(m*sizeof(float), 32);
 	mm_init_zero64(v, m);//- nasm
 	
 	somma64(C, T, n, d, v);//- nasm
 	//unrolling
 	for(; i < m-3; i += 4){
 		    media64(C, i, d, v);   dS[i] = nearCentroide(T, n, C, i, d, v[i]);
 		  media64(C, i+1, d, v); dS[i+1] = nearCentroide(T, n, C, i+1, d, v[i+1]);
 		  media64(C, i+2, d, v); dS[i+2] = nearCentroide(T, n, C, i+2, d, v[i+2]); 
 		  media64(C, i+3, d, v); dS[i+3] = nearCentroide(T, n, C, i+3, d, v[i+3]);
 	}
	for( ; i < m; i++ ){
		media64(C, i, d, v);//- nasm
		dS[i] = nearCentroide(T, n, C, i, d, v[i]);
	}//for
}//calcolaCentroide

int nearCentroide(DATASET T, int n, float* C, int classe, int d, int x){
	int i = 0, pos = -1;

	for(; pos == -1; i++)
		if( (T+i*(d+1))[d] == classe ){ pos = i; } 
	i++; x--;
	float distMinima = distanza64((T+i*(d+1)), C+classe*d, d);
	
	for(; i < n && x > 0; i++){
 		if((T+i*(d+1))[d] == classe){
			float minCorr = distanza64(T+i*(d+1),  C+classe*d, d);
			if( minCorr < distMinima ){
				distMinima = minCorr;
				pos = i;
			}//if
			x--;
		}//if
	}//for
	return pos;
}//near
#endif
