/****************************************************************************
 *
 * CdL Magistrale in Ingegneria Informatica
 * Corso di Calcolatori Elettronici 2 - a.a. 2014/15
 *
 * Progetto di un algoritmo di Nearest Neighbor Condensation
 * in linguaggio assembly x86-64 + AVX
 *
 * Fabrizio Angiulli, 18 aprile 2014
 *
 ****************************************************************************/

/*

 Software necessario per l'esecuzione:

     NASM (www.nasm.us)
     GCC (gcc.gnu.org)

 entrambi sono disponibili come pacchetti software
 installabili mediante il packaging tool del sistema
 operativo; per esempio, su Ubuntu, mediante i comandi:

     sudo apt-get install nasm
     sudo apt-get install gcc

 potrebbe essere necessario installare le seguenti librerie:

     sudo apt-get install lib32gcc-4.8-dev (o altra versione)
     sudo apt-get install libc6-dev-i386

 Per generare il file eseguibile:

 nasm -f elf64 fcnn64.nasm && gcc -O0 -m64 -mavx fcnn64.o fcnn64c.c -o fcnn64c && ./fcnn64c

 oppure

 ./runfcnn32

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <xmmintrin.h>
#include <float.h>

/*
 *
 *	Le funzioni sono state scritte assumento che le matrici siano memorizzate
 * 	mediante un array (float*), in modo da occupare un unico blocco
 * 	di memoria, ma a scelta del candidato possono essere
 * 	memorizzate mediante array di array (float**).
 *
 * 	In entrambi i casi il candidato dovrà inoltre scegliere se memorizzare le
 * 	matrici per righe (row-major order) o per colonne (column major-order).
 *
 * 	L'assunzione corrente è che le matrici siano in row-major order.
 *
 */


#define	MATRIX		float*
#define	VECTOR		float*

#define	DATASET		float*
#define SUBSETID	int*

#define N					3

typedef enum { false = 0 , true } bool;

void* get_block(int size, int elements) {
	return _mm_malloc(elements*size,32);
}


void free_block(void* p) {
	_mm_free(p);
}


MATRIX alloc_matrix(int rows, int cols) {
	return (MATRIX) get_block(sizeof(float),rows*cols);
}


void dealloc_matrix(MATRIX mat) {
	free_block(mat);
}


/*
 *
 * 	load_input
 * 	===========
 *
 *	Legge da file il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, e lo memorizza
 * 	in un array lineare in row-major order
 *
 * 	Codifica del file:
 * 	primi 4 byte: numero di colonne (d+1) --> numero intero in complemento a due
 * 	4 byte successivi: numero di righe (n) --> numero intero in complemento a due
 * 	n*(d+1)*4 byte successivi: training set T in row-major order --> numeri floating-point a precisione singola
 *
 */
DATASET load_input(char* filename, int *n, int *d, int *m) {
	FILE* fp;
	int rows, cols, status, i;

	fp = fopen(filename, "rb");

	if (fp == NULL) {
		printf("Bad dataset file name!\n");
		exit(0);
	}

	status = fread(&cols, sizeof(int), 1, fp);
	status = fread(&rows, sizeof(int), 1, fp);
	DATASET T = alloc_matrix(rows,cols);
	status = fread(T, sizeof(float), rows*cols, fp);
	fclose(fp);

	*m = 0;
	for (i = 0; i < rows; i++)
		if (T[i*cols+cols-1] > *m)
			*m = T[i*cols+cols-1];
	(*m)++;
	*n = rows;
	*d = cols-1;

	return T;
}


void save_output(SUBSETID Sid, int Sn, int cols, DATASET T) {
	FILE* fp;
	int i;

	fp = fopen("subset.txt", "w");
	for (i = 0; i < Sn; i++)
		fprintf(fp, "%d\n", Sid[i]);
	fclose(fp);

	fp = fopen("subset.dataset", "w");
	fwrite(&cols, sizeof(int), 1, fp);
	fwrite(&Sn, sizeof(int), 1, fp);
	for (i = 0; i < Sn; i++)
		fwrite(&T[Sid[i]*cols], sizeof(float), cols, fp);
	fclose(fp);
}

extern void initVector(int* v, int dim);
extern void initDistanceVector(float* v, int dim);
extern float getLabel(int i, DATASET T, int d);
extern int mergeVector(SUBSETID Sid, int sizeSid, SUBSETID dS, int sizeDS);
extern int mergeVectorIf(SUBSETID dS, int sizedS, int* rep, int sizeRep);
extern bool	eisIn( int q, SUBSETID s, int sizeS);
extern float distance(int p, int q, DATASET T, int d);
extern void initTwoVector(SUBSETID intV, float* floV, int m);
extern void initRespClass( DATASET T, int n, int m, float* rC, int d);
extern void computeCentroid(DATASET T, int d, int i, float occ, float* center, int j);
extern int extNearestPointIndex(DATASET T, int n, float* center, float label, int m, int d, int raw);

SUBSETID centroids(DATASET T, int n, int d, int m){
	int i, j;
	float	occ;
	SUBSETID ris = get_block(sizeof(int), n);
	float* respClass = get_block(sizeof(float), m);
	initTwoVector( ris, respClass, m);
	float* center = calloc(sizeof(float), d * m);
	initRespClass( T, n, m, respClass, d);
	for ( j = 0; j < m; j++){
		occ = 0.0;
		for ( i = 0; i < n; i++){
			if (T[i*(d+1)+d] == respClass[j]){
				occ += 1.0;
				computeCentroid(T,d,i,occ,center,j);
			}
		}
		ris[j] = extNearestPointIndex( T, n, center, respClass[j], m, d, j);
	}
	free_block(respClass);
	free(center);
	return ris;
}


/*
 *	fcnn
 * 	====
 *
 *	T contiene il training set codificato come una matrice di n righe
 * 	e (d+1) colonne, con l'etichetta nell'ultima colonna, memorizzata
 * 	in un array lineare in row-major order
 *
 *	Se lo si ritiene opportuno, è possibile cambiare la codifica in memoria
 * 	del training set.
 *
 * 	Restituisce in Sid gli identificatori degli esempi di T che appartengono
 * 	al sottoinsieme S ed in Sn il numero di oggetti in S.
 * 	Si assume che gli identificatori partono da 0.
 *
 */

SUBSETID fcnn(DATASET T, int n, int d, int m, int* Sn) {
  SUBSETID Sid = get_block(sizeof(int),n);
  int p, q, indice;
  int* nearest = get_block(sizeof(int), n);
  int* rep = get_block(sizeof(int), n);
  initVector(nearest, n);
  int sizeSid = 0;
  SUBSETID dS = centroids( T, n, d, m);
  int sizeDS = m;
	int ds1, ds2, ds3, ds4;
  float temp, distanza;
	float distanza1, distanza2, distanza3, distanza4;
  float* nearDist = calloc(sizeof(float),n);
  float* repDist = get_block(sizeof(float),n);
  while ( sizeDS != 0 ){
  	sizeSid = mergeVector(Sid, sizeSid, dS, sizeDS);
    initVector(rep, n);
    initDistanceVector(repDist,n);
    for ( q = 0; q < n; q++){
    	if ( !eisIn(q, Sid, sizeSid) ){
      	if( nearDist[q] == 0.0 )
          nearDist[q] = distance( nearest[q], q, T, d);
        distanza = nearDist[q];
        indice = nearest[q];
        for ( p = 0; p < sizeDS - N; p+=4){
        	ds1 = dS[p]; ds2 = dS[p+1]; ds3 = dS[p+2]; ds4 = dS[p+3];
          distanza1 = distance(ds1, q, T, d);
          distanza2 = distance(ds2, q, T, d);
          distanza3 = distance(ds3, q, T, d);
          distanza4 = distance(ds4, q, T, d);
          if( distanza > distanza1 ){
            indice = ds1;
            distanza = distanza1;
          }
          if( distanza > distanza2 ){
            indice = ds2;
            distanza = distanza2;
          }
          if( distanza > distanza3 ){
            indice = ds3;
            distanza = distanza3;
          }
          if( distanza > distanza4 ){
            indice = ds4;
            distanza = distanza4;
          }
        }
        while(p < sizeDS){
          temp = distance(dS[p], q, T, d);
          if( distanza > temp ){
            indice = dS[p];
            distanza = temp;
        	}
          p++;
        }
        nearest[q] = indice;
        nearDist[q] = distanza;
        if ( getLabel(q, T, d) != getLabel(indice, T, d) ){
        	if (repDist[indice] == FLT_MAX)
          	repDist[indice] = distance(indice, rep[indice], T, d);
          if ( distanza <  repDist[indice] ){
            rep[indice] = q;
            repDist[indice] = distanza;
          }
        }
      }
    }
    sizeDS = 0;
    sizeDS = mergeVectorIf(dS, sizeDS, rep, n);
	}

  printf("\nNumero di elementi finale = %d\n ",sizeSid);//test

  free_block(repDist);
  free(nearDist);
  free_block(nearest);
  free_block(dS);
  free_block(rep);

  *Sn = sizeSid;

  return Sid;
 }

int main(int argc, char** argv) {
	DATASET T;
	int n = 10;		// numero di esempi del training set
	int d = 2;		// numero di dimensioni di ogni esempio
	int m = 2;		// numero di classi

	char* filename = "";
	int silent = 0, display = 0;
	int i, j;

	int par = 1;
	while (par < argc) {
		if (par == 1) {
			filename = argv[par];
			par++;
		} else if (strcmp(argv[par],"-s") == 0) {
			silent = 1;
			par++;
		} else if (strcmp(argv[par],"-d") == 0) {
			display = 1;
			par++;
		} else
			par++;
	}

	if (!silent) {
		printf("Usage: %s <file_name> [-d][-s]\n", argv[0]);
		printf("\nParameters:\n");
		printf("\t-d : displays both input and output\n");
		printf("\t-s : silent\n");
		printf("\n");
	}

	if (strlen(filename) == 0) {
		printf("Missing dataset file name!\n");
		exit(0);
	}

	T = load_input(filename, &n, &d, &m);

	if (!silent && display) {
		printf("\nInput dataset:\n");
		for (i = 0; i < n*(d+1); i++) {
			if (i % (d+1) == 0)
				printf("\n");
			printf("%f ", T[i]);
		}
		printf("\n\n");
	}

	if (!silent)
		printf("Executing FCNN: %d examples, %d attributes, %d classes...\n", n, d, m);

	clock_t t = clock();
	int Sn = 0;
	SUBSETID Sid = fcnn(T, n, d, m, &Sn);
	t = clock() - t;

	if (!silent)
		printf("\nExecution time = %.3f seconds\n", ((float)t)/CLOCKS_PER_SEC);
	else
		printf("%.3f\n", ((float)t)/CLOCKS_PER_SEC);

	if (!silent && display) {
		printf("\nCondensed dataset:\n");
		for (i = 0; i < Sn; i++) {
			for (j = 0; j < d+1; j++)
				printf("%f ", T[Sid[i]*(d+1)+j]);
			printf("\n");
		}
	}

	save_output(Sid,Sn,d+1,T);

	return 0;
}
